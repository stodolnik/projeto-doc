import { Controller, Post, Body, Headers, Patch, HttpStatus, Response } from '@nestjs/common'
import { PurchaseInvoicesRequest } from './interfaces/controller';
import { PurchaseInvoicesInternationalService } from './purchase-invoices-international.service'
import { ApiImplicitHeader } from '@nestjs/swagger';

@Controller('purchase-invoices-international')
export class PurchaseInvoicesInternationalController {

  constructor(private readonly purchaseInvoicesInternationalService: PurchaseInvoicesInternationalService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: PurchaseInvoicesRequest, @Headers('token') token) {
    try {
      return this.purchaseInvoicesInternationalService.create(body);
    } catch (err) {
      throw err;
    }
  }
}
