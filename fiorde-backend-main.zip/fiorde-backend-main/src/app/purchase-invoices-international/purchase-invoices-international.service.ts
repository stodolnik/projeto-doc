import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { HanaBusinessPartnersService } from '../../b1/hana/business-partners/business-partners.service';
import { HanaPurchaseInvoiceService } from '../../b1/hana/purchase-invoice/purchase-invoice.service';
import { PurchaseInvoicesModel } from './interfaces/service/index';
import { HanaProjectsService } from '../../b1/hana/projects/projects.service';
import { HanaBranchService } from '../../b1/hana/branch/branch.service';
import { Mapper, Invoices, DeliveryDraft } from './interfaces/service';
import { HanaSkillService } from '../../b1/hana/skill/skill.service';
import { HanaModelService } from '../../b1/hana/model/model.service';
import { HanaItemsService } from '../../b1/hana/items/items.service';
import { PurchaseInvoicesRequest } from './interfaces/controller';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { ConfigService } from '../../config/config.service';
import { PartnerService } from '../partner/partner.service';
import { DraftService } from '../draft/draft.service';
import { response } from '../../core/http/http.service';
import * as _ from 'lodash';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class PurchaseInvoicesInternationalService {
  constructor(
    private readonly configService: ConfigService,
    private readonly hanaBusinessPartnesService: HanaBusinessPartnersService,
    private readonly hanaPurchaseInvoiceService: HanaPurchaseInvoiceService,
    private readonly hanaProjectsService: HanaProjectsService,
    private readonly hanaBranchService: HanaBranchService,
    private readonly hanaSkillService: HanaSkillService,
    private readonly hanaModelService: HanaModelService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaItemsService: HanaItemsService,
    private readonly partnerService: PartnerService,
    private readonly draftService: DraftService,
    private readonly hanaLogService: HanaLogService
  ) { }

  private readonly defaultConfig = this.configService.companyConfig();

  private taxDa = 0;

  async create(data: PurchaseInvoicesRequest) {
    try {
      let result = [];
      const invoices = Mapper.FromList(data.purchase);

      for (const invoice of invoices) {

        try {

          await this.validateInvoiceForInsert(invoice);

          const document = await this.resolveInvoice(invoice);

          const endpoint = `${Endpoints.PurchaseInvoices}`;
          document.U_FiordeIntegratedId = "b63c21df-f569-4279-be53-a27fb75b86e0";
          const res = await this.serviceLayerService.post(endpoint, document, { credentials: this.defaultConfig, retries: 3 });

          const _response = await response(res);

          if (!_response.error && _response.data) {

            this.createDI(invoice, _response.data);
            const log = this.objectmodelLog(invoice.invoicesModel.NumAtCard || '', data, JSON.stringify(_response.data), 'Sucesso');
            await this.hanaLogService.insertLog(log);
            result.push({ error: null, id: invoice.invoicesModel.NumAtCard, docNum: _response.data.DocNum });

          } else {

            throw {
              error: {
                code: 'PI001',
                message: _response.error.innerMessage,
                innerMessage: _response.error.innerMessage
              },
              id: invoice.invoicesModel.NumAtCard
            }

          }
        }
        catch (err) {
          console.log('EXCEPTION: ', err);
          throw new HttpException([{ ...err }], _.get(err, 'error').code == 401 ? HttpStatus.UNAUTHORIZED : HttpStatus.UNPROCESSABLE_ENTITY);
        }
      }

      return result;

    } catch (err) {
      const log = this.objectmodelLog(err.id || '', data, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw err;
    }
  }

  async resolveInvoice(doc: Invoices): Promise<PurchaseInvoicesModel> {

    try {
      const { data: customerData } = await this.hanaBusinessPartnesService.getById(doc.invoicesModel.CardCode);

      if (customerData && customerData.length == 0) {

        await this.partnerService.create(doc.partner);

      }

      const { data: branchData } = await this.hanaBranchService.getByCnpj(doc.invoicesModel.BPL_IDAssignedToInvoice);
      const { data: modelData } = await this.hanaModelService.getModelId(doc.invoicesModel.SequenceModel);

      doc.invoicesModel.BPL_IDAssignedToInvoice = branchData[0].id;
      doc.invoicesModel.SequenceModel = _.first(modelData).AbsEntry;

      let sumDA = 0;

      doc.invoicesModel.DocumentAdditionalExpenses.forEach(d => {
        if (d.ExpenseCode == 5 || d.ExpenseCode == 6)
          sumDA += d.LineTotal;
      });

      let qtdItens = _.sum(_.map(doc.invoicesModel.DocumentLines, d => d.Quantity));

      let sumDAUnit = sumDA / qtdItens;

      this.taxDa = sumDAUnit;

      for (const line of doc.invoicesModel.DocumentLines) {

        // line.UnitPrice = line.UnitPrice - sumDAUnit;

        // const { data: taxData, error: taxError } = await this.hanaPurchaseInvoiceService.getTax(line.U_PercentIPI);

        // if (_.isEmpty(taxData)) {
        //   throw {
        //     error: {
        //       code: 'IPI404',
        //       message: 'Percent IPI not found.',
        //       innerMessage: 'Percent IPI not found.',
        //     },
        //     id: doc.invoicesModel.NumAtCard
        //   }
        // }

        // line.Usage = taxData[0].usage;
        // line.TaxCode = taxData[0].taxId;

        delete line.U_PercentIPI;

        line.WarehouseCode == '' ? delete (line.WarehouseCode) : line.WarehouseCode
      }
      console.log(JSON.stringify(doc.invoicesModel))
      return doc.invoicesModel;
    } catch (error) {
      throw error;
    }

  }

  async UpdateIVAST(doc: Invoices, invoice: PurchaseInvoicesModel): Promise<void> {
    try {
      const documentLines = doc.invoicesModel.DocumentLines;

      for (let line = 0; line < documentLines.length; line++) {

        if (documentLines[line].U_B1SYS_IVAST) {

          const ipi = documentLines[line].Quantity * documentLines[line].UnitPrice;

          const { error: updateError } = await this.hanaPurchaseInvoiceService.updateIVAST(invoice.DocEntry, line, ipi);

          if (updateError) {

            throw {
              error: {
                code: 'IVAST001',
                message: 'Update IVAST failed.',
                innerMessage: updateError.innerMessage
              },
              id: doc.invoicesModel.NumAtCard
            }
          }
        }

      }
    } catch (err) {
      throw err;
    }
  }



  async createDI(doc: Invoices, invoice: PurchaseInvoicesModel): Promise<void> {
    try {
      for (let i = 0; i < doc.diData.length; i++) {
        const { data: branchData } = await this.hanaBranchService.getByCnpjCompany(doc.invoicesModel.BPL_IDAssignedToInvoice);
        const {data:idFilial} =  await this.hanaSkillService.getByCompany(branchData[0].id)
        doc.diData[i].companyId =  idFilial[0].ID;
        doc.diData[i].objtype = 18;
        doc.diData[i].lineNum = i.toString();
        doc.diData[i].docNum = invoice.DocEntry;
      //  doc.diData[i].typeDoc = 'NE';
      //  doc.diData[i].key = 'NE' + invoice.DocEntry;
        doc.diData[i].purchasersCNPJ.replace(/[^\d]+/g, '');

        if (doc.diAdditional.length > 0) {

          doc.diAdditional[i].SuppCode = doc.invoicesModel.CardCode;
          doc.diAdditional[i].PurchaseId = 0;
          doc.diAdditional[i].nDraw = ''; 

          
      //    doc.diAdditional[i].diKey = doc.diData[i].key;
        }

        const { error: diError } = await this.hanaSkillService.insertDIData(doc.diData[i]);

        if (diError) {

          throw {
            error: {
              code: 'DI001',
              message: 'DI insertion returned an exception.',
              innerMessage: diError.innerMessage
            },
            id: doc.invoicesModel.NumAtCard
          }
        }

        const { error: diAdditionalError } = await this.hanaSkillService.insertDIAdditional(doc.diAdditional[i]);

        if (diAdditionalError) {

          throw {
            error: {
              code: 'DI002',
              message: 'DI additional insertion returned an exception.',
              innerMessage: diAdditionalError.innerMessage
            },
            id: doc.invoicesModel.NumAtCard
          }
        }
      }
    } catch (err) {
      throw err;
    }
  }

  async createDeliveryDraft(doc: Invoices, tax: number) {
    try {
      const draft = DeliveryDraft(doc.invoicesModel);

      const { data: partnerCode } = await this.hanaBusinessPartnesService.getByCnpj(doc.diData[0].purchasersCNPJ, 'C');

      if (partnerCode && partnerCode.length > 0) {
        draft.CardCode = partnerCode[0].CardCode;

        await this.draftService.create(draft, tax);

      } else {

        throw {
          error: {
            code: 'DI010',
            message: 'Supplier code not found. ',
            innerMessage: 'Supplier code found.'
          },
          id: doc.invoicesModel.NumAtCard
        }
      }
    } catch (err) {
      throw err;
    }
  }

  async validateInvoiceForInsert(doc: Invoices): Promise<void> {
    try {


      //validates if the project exists
      if (!_.isEmpty(_.get(doc, 'invoicesModel.Project'))) {

        const { data: projectData } = await this.hanaProjectsService.getById(doc.invoicesModel.Project);

        if (projectData && projectData.length == 0) {
          throw {
            error: {
              code: 'PRJC001',
              message: 'Project not exists.',
              innerMessage: 'Project not exists.'
            },
            id: doc.invoicesModel.NumAtCard
          }
        }
      }

      const { data: partnerCodeClient } = await this.hanaBusinessPartnesService.getByCnpj(doc.diData[0].purchasersCNPJ, 'C');

      console.log('partnerCodeClient: ', partnerCodeClient);
      
      if (!partnerCodeClient || partnerCodeClient.length == 0) {
        const { data: partnerCodeSupplier } = await this.hanaBusinessPartnesService.getByCnpj(doc.diData[0].purchasersCNPJ, 'S');

        console.log('partnerCodeSupplier: ', partnerCodeSupplier);

        if (!partnerCodeSupplier || partnerCodeSupplier.length == 0) {
          throw {
            error: {
              code: 'DI010',
              message: `Purchase CNPJ ${doc.diData[0].purchasersCNPJ} not found.`,
              innerMessage: `Purchase CNPJ ${doc.diData[0].purchasersCNPJ} not found.`
            },
            id: doc.invoicesModel.NumAtCard
          }
        }

        await this.partnerService.createClientBySupplier(partnerCodeSupplier[0].CardCode);
        
      }

      //validates if the model exists
      const { data: modelData } = await this.hanaModelService.getModelId(doc.invoicesModel.SequenceModel);

      if (modelData && modelData.length == 0) {
        throw {
          error: {
            code: 'PI005',
            message: 'Model not exists.',
            innerMessage: 'Model not exists.'
          },
          id: doc.invoicesModel.NumAtCard
        }
      }

      //validates if the items exists
      for (const line of doc.invoicesModel.DocumentLines) {

        const { data: itemData } = await this.hanaItemsService.getById(line.ItemCode);

        if (itemData && itemData.length == 0) {
          throw {
            error: {
              code: 'ITM002',
              message: 'Item not found.',
              innerMessage: 'Item not found.'
            },
            id: doc.invoicesModel.NumAtCard
          }
        }

        if (_.isEmpty(line.U_PercentIPI)) {
          throw {
            error: {
              code: 'ITM002',
              message: 'Percent IPI is required.',
              innerMessage: 'Percent IPI is required.'
            },
            id: doc.invoicesModel.NumAtCard
          }
        }

      }


      //validates required fields in di
      for (let i = 0; i < doc.diData.length; i++) {

        if (!doc.diAdditional[i].NumberSeq || !doc.diAdditional[i].Number) {
          throw {
            error: {
              code: 'DI003',
              message: 'Additional number and Sequence is required.',
              innerMessage: 'Additional number and Sequence is required.'
            },
            id: doc.invoicesModel.NumAtCard
          }
        }
      }

      //validates maximum length
      if (doc.invoicesModel.Comments && doc.invoicesModel.Comments.length > 250) {
        throw {
          error: {
            code: 'STO001',
            message: 'Comments - Maximum length of 250 characters.',
            innerMessage: 'Comments - Maximum length of 250 characters.'
          },
          id: doc.invoicesModel.NumAtCard
        }
      }
    } catch (err) {
      throw err;
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Nota-Compra`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }

}

