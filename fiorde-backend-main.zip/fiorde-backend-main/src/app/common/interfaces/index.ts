import { ApiModelProperty } from "@nestjs/swagger";
import { HttpServiceError } from "src/b1/core/http/interfaces";

export class ExtraField {

  code: string;

  value: string;
}

