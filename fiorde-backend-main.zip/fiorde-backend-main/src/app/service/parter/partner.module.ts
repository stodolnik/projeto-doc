import { Module } from '@nestjs/common';
import { PartnerService } from './partner.service';
import { LogModule } from '../Log/log.module'
import { HanaBusinessPartnersModule } from '../../../b1/hana/business-partners/business-partners.module';
import { FiordeLoginModule } from '../../../fiorde/login/login.module';
import { LogModule as LogModuleHana } from '../../../b1/hana/log/log.module';
import { FiordePartnerModule } from '../../../fiorde/partner/partner.module';

@Module({
  imports: [HanaBusinessPartnersModule, FiordeLoginModule, FiordePartnerModule , LogModule , LogModuleHana],
  providers: [PartnerService],
  exports: [PartnerService]
})
export class ServicePartnerModule { }
