import { Injectable } from '@nestjs/common';
import { HanaBusinessPartnersService } from '../../../b1/hana/business-partners/business-partners.service';
import { FiordeLoginService } from '../../../fiorde/login/login.service';
import { FiordePartnerService } from '../../../fiorde/partner/partner.service';
import { Log } from '../Log/log.service';
import { Mapper } from './interfaces/index';
import { HanaLogService } from '../../../b1/hana/log/log.service';
import { ModelLog } from '../../../b1/hana/log/interfaces/index';
import { CronExpression, Cron, Timeout } from "@nestjs/schedule";
import * as _ from 'lodash';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';
import { Console } from 'console';


@Injectable()
export class PartnerService {

  constructor(
    private readonly hanaBusinessPartnersService: HanaBusinessPartnersService,
    private readonly fiordeLoginService: FiordeLoginService,
    private readonly hanaLogService: HanaLogService,
    private readonly log : Log,
    private readonly fiordePartnerService: FiordePartnerService) {

  }

  @Cron(CronExpression.EVERY_30_MINUTES)
  // @Timeout(0)
  async main() {
    
    try {

      const { data: pendingPartner } = await this.hanaBusinessPartnersService.getPendingPartners();
      await this.log.createLog(`-------------------------------------------------------------------`);
      await this.log.createLog(`Starting partner service`);
      if (!_.isEmpty(pendingPartner)) {
        await this.log.createLog(`-------------------------------------------------------------------`);
        await this.log.createLog(`Starting partner service`);
        const { data: login } = await this.fiordeLoginService.login();
        
        const partners = Mapper.FromList(pendingPartner);
        
        
        
        for (const partner of partners) {
          try {
            await this.log.createLog(JSON.stringify(partner));
            let email = await this.hanaBusinessPartnersService.getPendingContatoPartners(partner.cardCode);
            //const emails = 
            const emailsArrays = email.data.map((email) => email.E_MailL) ;
            const emailsString = emailsArrays.join(', ');
            partner.emails.emailAddress = emailsString
            console.log(JSON.stringify(partner));
            const { data: insert, error: insertError } = await this.fiordePartnerService.insert(partner, login);
            await this.log.createLog(`return - ${insert}`);
            console.log(`return - ${insert}`);
            await this.hanaBusinessPartnersService.updateIntegrationField(partner.cardCode);
            const log = this.objectmodelLog(partner.cardCode , partner, insert ? JSON.stringify(insert) : insert ,'Sucesso')
            console.log(log);
            await this.hanaLogService.insertLog(log)
            await this.hanaLogService.updateLogPartner("Integrado com Sucesso no Sysfiorde" , partner.cardCode
            , "CardCode" , "OCRD")
            console.log("Integrado com Sucesso no Sysfiorde" , partner.cardCode
            , "CardCode" , "OCRD");
          } catch (err) {
            await this.log.createLog(`return error - ${JSON.stringify(err.response.data)}`);
            console.log(`return error - ${JSON.stringify(err.response.data)}`);
            const log = this.objectmodelLog(partner.cardCode, partner ,JSON.stringify(err.response.data), 'Erro')
            console.log(log);
            await this.hanaBusinessPartnersService.updateRetryField(partner.cardCode);
            await this.hanaLogService.insertLog(log)
            if (err.response.data.status >= 400 && err.response.data.status < 500){
              await this.hanaLogService.updateLogPartner("Campos obrigatórios do Sysfiorde inválidos, favor verificar o cadastro" , partner.cardCode
              , "CardCode" , "OCRD")
              console.log("Campos obrigatórios do Sysfiorde inválidos, favor verificar o cadastro" , partner.cardCode
              , "CardCode" , "OCRD")
            }else if (err.response.data.status > 500){
              await this.hanaLogService.updateLogPartner("Falha ao conectar ao servidor Sysfiorde" , partner.cardCode
              , "CardCode" , "OCRD")
              console.log("Falha ao conectar ao servidor Sysfiorde" , partner.cardCode
              , "CardCode" , "OCRD")
            }else{
              await this.hanaLogService.updateLogPartner("Favor procurar o suporte Alfa" , partner.cardCode
              , "CardCode" , "OCRD")
              console.log("Favor procurar o suporte Alfa" , partner.cardCode
              , "CardCode" , "OCRD")
            }
          }

        }
      }
    } catch (err) {
      await this.log.createLog(`error - ${err}`);
    }
  }

  objectmodelLog(documentId: string , document: object , response: string  , status: string ){
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: response,
      U_PARAMETROS: '',
      U_TYPE: 'Envio-Parceiro',
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }

	// async createLog(text: string): Promise<void>{
  //   const day = dayjs().format('DD-MM-YYYY')
  //   const dateTime = dayjs().format()
  //   const nameArq = `/alfa/logs/fiorde-service-log-STG-${day}.txt`
  //    fs.writeFileSync(
  //       `${nameArq}`,
  //       `${text} - ${dateTime} \r\n`,
  //       {flag:'a+'}
  //       );		
  //   }
}