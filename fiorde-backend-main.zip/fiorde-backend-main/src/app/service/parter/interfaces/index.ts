import { ContactEmployees, PendingPartner } from '../../../../b1/hana/business-partners/interfaces/index';

const FromList = (bp: PendingPartner[]): Partner[] => {
  return bp.map(p => {

    let partner: Partner = {
      cardCode: p.cardCode,
      cardCNPJ: p.cardCNPJ,
      cardType: p.cardType,
      cardName: p.cardName,
      cardForeignName: p.cardForeignName,
      phone1: p.phone1,
      phone2: p.phone2,
      cellular: p.cellular,
      fax: p.fax,
      emails:{
        emailAddress: p.emailAddress
      },
      website: p.website,
      freeText: p.freeText,
      singlePayment: p.singlePayment,
      address: {
        street: p.street,
        number: p.number,
        complement: p.complement,
        neighborhood: p.neighborhood,
        zipCode: p.zipCode,
        city: p.city,
        state: p.state,
        country: p.country
      },
      group: {
        code: String(p.groupCode),
        description: p.groupName
      }
    }
    return partner

  });
}


export const Mapper = {
  FromList
};

export interface PartnerAddress {
  street: string,
  number: number,
  complement: string,
  zipCode: string,
  city: string,
  state: string,
  country: string,
  neighborhood: string
}

export interface Group {
  code: string,
  description: string
}

export interface Partner {
  cardCode: string,
  cardCNPJ: string,
  cardType: string,
  cardName: string,
  cardForeignName: string,
  phone1: string,
  phone2: string,
  cellular: string,
  fax: string,
  emails: PartnerContactEmployees,
  website: string,
  freeText: string,
  group: Group,
  singlePayment: string,
  address: PartnerAddress
}

export interface PartnerContactEmployees{
  emailAddress: string;
}
