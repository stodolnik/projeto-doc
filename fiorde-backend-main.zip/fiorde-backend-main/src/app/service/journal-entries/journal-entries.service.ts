import { Injectable } from '@nestjs/common';
import { HanaJournalEntriesService } from '../../../b1/hana/journal-entries/journal-entries.service';
import { FiordeLoginService } from '../../../fiorde/login/login.service';
import { FiordeJournalEntriesService } from '../../../fiorde/journal-entries/journal-entries.service';
import { CronExpression, Cron, Timeout } from "@nestjs/schedule";
import { Log } from '../Log/log.service';
import { HanaLogService } from '../../../b1/hana/log/log.service';
import { ModelLog } from '../../../b1/hana/log/interfaces/index';
import * as _ from 'lodash';
import { threadId } from 'worker_threads';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';


@Injectable()
export class JournalEntriesService {

  constructor(
    private readonly hanaJournalEntriesService: HanaJournalEntriesService,
    private readonly fiordeLoginService: FiordeLoginService,
    private readonly hanaLogService: HanaLogService,
    private readonly log : Log,
    private readonly fiordeJournal: FiordeJournalEntriesService) {

  }

  @Cron(CronExpression.EVERY_MINUTE)
  @Timeout(0)
  async main() {
    
    try {

      const { data : JournalEntries  } = await this.hanaJournalEntriesService.NoIntegrated();
      await this.log.createLog(`-------------------------------------------------------------------`);
      await this.log.createLog(`Starting Journal Entries service`);

      if (!_.isEmpty(JournalEntries)) {
        await this.log.createLog(`-------------------------------------------------------------------`);
        await this.log.createLog(`Starting Journal Entries service`);
        const { data: login } = await this.fiordeLoginService.login();
        
        for (const journalEntrie of JournalEntries) {
          try {
            await this.log.createLog(JSON.stringify(journalEntrie));
            const { data: insert, error: insertError } = await this.fiordeJournal.insert(journalEntrie, login);
            await this.log.createLog(`return - ${insert}`);
            await this.hanaJournalEntriesService.updateIntegrationField(journalEntrie.id);
            const log = this.objectmodelLog(journalEntrie.id , journalEntrie, insert ? JSON.stringify(insert) : insert ,'Sucesso')
            await this.hanaLogService.insertLog(log)
            await this.hanaLogService.updateLogPartner("Integrado com Sucesso no Sysfiorde" , journalEntrie.id
            , "Number" , "OJDT")
          } catch (err) {
            await this.log.createLog(`error:' , ${JSON.stringify(err.response.data)} , 'id :' , ${journalEntrie.id}`);
            let retrie = Number(journalEntrie["Retrie"] ) + 1;
            await this.hanaJournalEntriesService.updateIntegrationRetrie(journalEntrie.id , retrie);
            const log = this.objectmodelLog(journalEntrie.id, journalEntrie ,JSON.stringify(err.response.data), 'Erro')
            await this.hanaLogService.insertLog(log)
            if (err.response.data.status >= 400 && err.response.data.status < 500){
              await this.hanaLogService.updateLogPartner("Rejeitado pelo Sysfiorde, favor verificar o Lançamento Contábil" , journalEntrie.id
              , "Number" , "OJDT")
            }else if (err.response.data.status > 500){
              await this.hanaLogService.updateLogPartner("Falha ao conectar ao servidor Sysfiorde" , journalEntrie.id
              , "Number" , "OJDT")
            }else{
              await this.hanaLogService.updateLogPartner("Favor procurar o suporte Alfa" , journalEntrie.id
              , "Number" , "OJDT")
            }
            
          }

        }
      }
    } catch (err) {
      await this.log.createLog(`error- ${err}`);
    }
  }

  objectmodelLog(documentId: string , document: object , response: string  , status: string ){
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document['id']).replace(/\\/g, ''),
      U_OBJETORESPONSE: response,
      U_PARAMETROS: String(document['id']),
      U_TYPE: 'Envio-Estorno',
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }
}