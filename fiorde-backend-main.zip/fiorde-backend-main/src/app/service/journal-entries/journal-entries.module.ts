import { Module } from '@nestjs/common';
import { JournalEntriesService } from './journal-entries.service';
import { HanaBusinessPartnersModule } from '../../../b1/hana/journal-entries/journal-entries.module';
import { FiordeLoginModule } from '../../../fiorde/login/login.module';
import { LogModule as LogModuleHana } from '../../../b1/hana/log/log.module';
import { JournalEntriesModule } from '../../../fiorde/journal-entries/journal-entries.module';
import { LogModule } from '../Log/log.module'

@Module({
  imports: [HanaBusinessPartnersModule, FiordeLoginModule, JournalEntriesModule , LogModule , LogModuleHana],
  providers: [JournalEntriesService],
  exports: [JournalEntriesService]
})
export class ServiceJournalEntriesModule { }
