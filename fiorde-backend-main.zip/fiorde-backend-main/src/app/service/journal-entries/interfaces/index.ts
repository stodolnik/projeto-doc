export interface JournalEntries {
  id: string
}

