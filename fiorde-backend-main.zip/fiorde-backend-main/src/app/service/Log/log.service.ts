import { Injectable } from '@nestjs/common';
import { CronExpression, Cron, Timeout } from "@nestjs/schedule";
import * as _ from 'lodash';
import * as dayjs from 'dayjs';
import * as fs from 'fs';
import { HanaLogService } from '../../../b1/hana/log/log.service';
import { ConfigService } from '../../../config/config.service';


@Injectable()
export class Log {

  constructor(
    private readonly hanaLogService: HanaLogService,
    private readonly configService: ConfigService,
    ) {}

    private readonly defaultConfig = this.configService.companyConfig();  

  async createLog(text: string){
    try{
      const day = dayjs().format('DD-MM-YYYY')     
      const dateTime = dayjs().format()
      const nameArq = `/alfa/logs/fiorde-service-log-${this.defaultConfig.CompanyDB}-${day}.txt`
       fs.writeFileSync(
          `${nameArq}`,
          `${text} - ${dateTime} \r\n`,
          {flag:'a+'}
        );	

    } catch (err){
      console.log(err)
    }
  }

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  @Timeout(0)
  async deleteFile(){
    const yesterday = dayjs().subtract(1, 'day').format('DD-MM-YYYY');
    const nameYArq = `/alfa/logs/fiorde-service-log-${this.defaultConfig.CompanyDB}-${yesterday}.txt`
    const file = fs.statSync(`${nameYArq}`);
    if (file){
      fs.unlinkSync(`${nameYArq}`);
    }

  }

  @Cron(CronExpression.EVERY_DAY_AT_4AM)
  // @Timeout(0)
  async deleteLogs() {
     await this.hanaLogService.deleteLog();    
  }


}