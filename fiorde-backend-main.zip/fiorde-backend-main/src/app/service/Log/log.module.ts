import { Module } from '@nestjs/common';
import { Log } from './log.service';
import { LogModule as LogModuleHana } from '../../../b1/hana/log/log.module';
import { ConfigModule } from '../../../config/config.module';

@Module({
  imports: [LogModuleHana , ConfigModule],
  providers: [Log],
  exports: [Log]
})
export class LogModule { }
