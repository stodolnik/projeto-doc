export interface Status {
  NumAtCard?: string,
  DocumentNumber?: string,
  Invoice?: string,
  InvoiceSerial?: string,
  CreateDate?: string,
  DocumentTotal?: number,
  StatusSefaz?: string,
  AcessKey?: string
}