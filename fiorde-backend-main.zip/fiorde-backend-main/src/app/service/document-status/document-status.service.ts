import { Injectable } from '@nestjs/common';
import { FiordeLoginService } from '../../../fiorde/login/login.service';
import { FiordeNfeService } from '../../../fiorde/nfe-return/nfe-return.service';
import { HanaSkillService } from '../../../b1/hana/skill/skill.service';
import { HanaLogService } from '../../../b1/hana/log/log.service';
import { ModelLog } from '../../../b1/hana/log/interfaces/index';
import { CronExpression, Cron, Timeout } from "@nestjs/schedule";
import * as _ from 'lodash';
import { Status } from './interfaces';
import { NFeReturn } from '../../../fiorde/nfe-return/interfaces/index';
import { response } from '../../../core/http/http.service';
import { HanaSaleInvoiceService } from '../../../b1/hana/sale-invoice/sale-invoice.service'
import { Log } from '../Log/log.service';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class NFeService {

  constructor(
    private readonly fiordeLoginService: FiordeLoginService,
    private readonly fiordeNfeService: FiordeNfeService,
    private readonly hanaSkillService: HanaSkillService,
    private readonly hanaLogService: HanaLogService,
    private readonly log: Log,
    private readonly hanaSaleInvoiceService: HanaSaleInvoiceService
  ) {

  }

  @Cron(CronExpression.EVERY_10_SECONDS)
  //@Timeout(0)
  async main() {

    try {
      const { data: documents } = await this.hanaSkillService.documentStatus();
      await this.log.createLog(`-------------------------------------------------------------------`);
      await this.log.createLog(`Starting status service`);
      let parametros;
      if (!_.isEmpty(documents)) {
        await this.log.createLog(`-------------------------------------------------------------------`);
        await this.log.createLog(`Starting status service`);
        const { data: login } = await this.fiordeLoginService.login();

        for (const document of documents) {
          console.log(JSON.stringify(document));
          await this.log.createLog(JSON.stringify(document));
          
          let entity = this.resolve(document);
          let insertError;
          parametros = document.DocumentType == 'INVOICE' ? `{ documentNumAtCard:${document.NumAtCard}, documentProject:${document.Project}}`
          : ` documentNumAtCard:${document.NumAtCard}`;
          try {
            if (document.DocumentType == 'INVOICE') {
              await this.log.createLog(`INVOICE`);
              
              let { data: tax } = await this.hanaSaleInvoiceService.getTax(document.DocumentID);
              tax.forEach(r => r.value = parseFloat(r.value));
              tax.forEach(r => r.percent = parseFloat(r.percent));
              entity = { ...entity, taxValues: tax }
              await this.log.createLog(JSON.stringify(entity));
              console.log(JSON.stringify(entity));
              
              delete entity.status;
              delete entity.serialNumber;
              delete entity.emissionDate;
              entity["numberNf"] = entity.invoice;
              delete entity.invoice;
              delete entity.documentNumber;

              const { data: insert, error: insertError } = await this.fiordeNfeService.insertEntry(document.NumAtCard, document.Project, entity, login);
              const log = this.objectmodelLog(document.DocumentNumber , entity ,insert ? JSON.stringify(insert) : insert, parametros, document.DocumentType, 'Sucesso')
              await this.hanaLogService.insertLog(log)
              console.log(log)
              await this.hanaLogService.updateLogPartner("Integrado com Sucesso no Sysfiorde" , document.DocumentID
              , "DocEntry" , "OINV")

            } else {
              const { data: insert, error: insertError } = await this.fiordeNfeService.insert(document.NumAtCard, entity, login);

              const log = this.objectmodelLog(document.DocumentNumber , entity ,insert ? JSON.stringify(insert) : insert, parametros, document.DocumentType, 'Sucesso')
              await this.hanaLogService.insertLog(log)
              console.log(log)
              await this.hanaLogService.updateLogPartner("Integrado com Sucesso no Sysfiorde" , document.DocumentID
              , "DocEntry" , "OPCH")

            }
            await this.hanaSkillService.updateIntegrationField(document.DocumentID, document.DocumentType);

          } catch (err) {
            let retrie = Number(document["Retrie"]) + 1;
            await this.hanaSkillService.updateIntegrationRetrie(document.DocumentID, document.DocumentType, retrie);
            await this.log.createLog(`error:' , ${JSON.stringify(err.response.data)} , 'id :' , ${document.Invoice}`);
            console.log(`error:' , ${JSON.stringify(err.response.data)} , 'id :' , ${document.Invoice}`);

            const log = this.objectmodelLog(document.DocumentNumber , entity ,err.response.data, parametros, document.DocumentType , 'Erro')
            console.log(log)
            await this.hanaLogService.insertLog(log)

            let table = document.DocumentType == 'INVOICE' ? "OINV" : "OPCH";

            if (err.response.data.status >= 400 && err.response.data.status < 500){
              await this.hanaLogService.updateLogPartner("Rejeitado pelo Sysfiorde, favor verificar a nota." , document.DocumentID
              , "DocEntry" , table)
              console.log("Rejeitado pelo Sysfiorde, favor verificar a nota." , document.DocumentID
              , "DocEntry" , table)
            }else if (err.response.data.status > 500){
              await this.hanaLogService.updateLogPartner("Falha ao conectar ao servidor Sysfiorde." , document.DocumentID
              , "DocEntry" , table)
              console.log("Falha ao conectar ao servidor Sysfiorde." , document.DocumentID
              , "DocEntry" , table)
            }else{
              await this.hanaLogService.updateLogPartner("Favor procurar o suporte Alfa." , document.DocumentID
              , "DocEntry" , table)
              console.log("Favor procurar o suporte Alfa." , document.DocumentID
              , "DocEntry" , table)
            }
          }
        }
      }
    } catch (err) {
      await this.log.createLog(`error- ${err}`);
      throw err;
    }
  }

  resolve(data: Status) {
    try {
      const doc: NFeReturn = {
        documentNumber: data.DocumentNumber,
        invoice: data.Invoice,
        serialNumber: data.InvoiceSerial,
        emissionDate: moment(data.CreateDate).format('YYYY-MM-DDThh:mm:ss'),
        status: data.StatusSefaz,
        keyNumber: data.AcessKey || ''
      }
      return doc;
    } catch (err) {
      throw err;
    }
  }

  objectmodelLog(documentId: string , document: object , response: string, parametros: string , typeDocument: string , status: string ){
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDThh:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: response,
      U_PARAMETROS: parametros,
      U_TYPE: `Retorno-Nota-${typeDocument}`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }

}