import { Module } from '@nestjs/common';
import { FiordNfeModule } from '../../../fiorde/nfe-return/nfe-return.module';
import { SkillModule } from '../../../b1/hana/skill/skill.module';
import { LogModule as LogModuleHana } from '../../../b1/hana/log/log.module';
import { FiordeLoginModule } from '../../../fiorde/login/login.module';
import { LogModule } from '../Log/log.module'
import { NFeService } from './document-status.service';
import { HanaSaleInvoiceModule } from '../../../b1/hana/sale-invoice/sale-invoice.module'

@Module({
  imports: [SkillModule, FiordeLoginModule, FiordNfeModule, HanaSaleInvoiceModule , LogModule , LogModuleHana],
  providers: [NFeService],
  exports: [NFeService]
})
export class ServiceStatusModule { }
