import { HanaProjectsModule } from '../../b1/hana/projects/projects.module';
import { JournalEntriesController } from './journal-entries.controller';
import { JournalEntriesService } from './journal-entries.service';
import { ConfigModule } from '../../config/config.module';
import { HanaBranchModule } from '../../b1/hana/branch/branch.module';
import { Module } from '@nestjs/common';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';

@Module({
  imports: [ HanaBranchModule, ConfigModule, HanaProjectsModule, LogModuleHana],
  providers: [JournalEntriesService],
  controllers: [JournalEntriesController]
})

export class JournalEntriesModule { }
