
import { Partner, PartnerAddress } from '../../../partner/interfaces/service/index';
import _ = require("lodash");
import { ApiModelProperty } from "@nestjs/swagger";

const FromList = (doc: JournalEntry[]): JournalEntryModel[] => {
  let line = 0;
  return doc.map(d => {
    let entry: JournalEntryModel = {
      ReferenceDate: d.referenceDate,
      DueDate: d.dueDate,
      TaxDate: d.taxDate,
      ProjectCode: d.project,
      Reference: d.partnerDocumentNumber,
      JournalEntryLines: d.journalLines.map(i => {
        const lines: JournalEntryLines = {
          AccountCode: i.accountCode,
          Credit: i.credit,
          Debit: i.debit,
          BPLID: d.branch,
          LineMemo: i.comments,
          Reference1: i.reference,
          ProjectCode: i.project
        }
        return lines;
      }),
    };

    return entry;
  });
}

export const Mapper = {
  FromList
};

export class JournalEntryLine {
  
  @ApiModelProperty()
  public accountCode: string;
  
  @ApiModelProperty()
  public credit: number;
  
  @ApiModelProperty()
  public debit: number;

  @ApiModelProperty()
  public reference: string;

  @ApiModelProperty()
  public comments: string;

  @ApiModelProperty()
  public project: string;
}

export class JournalEntry {

  
  @ApiModelProperty()
  public branch?: string;

  @ApiModelProperty()
  public referenceDate?: Date;
  
  @ApiModelProperty()
  public taxDate?: Date;
  
  @ApiModelProperty()
  public dueDate?: Date;

  public project: string;

  @ApiModelProperty()
  public partnerDocumentNumber: string;

  @ApiModelProperty({ isArray: true, type: JournalEntryLine })
  public journalLines: JournalEntryLine[];

}

export interface JournalEntryModel {
  ReferenceDate?: Date,
  TaxDate?: Date,
  DueDate?: Date,
  Reference?: string,
  ProjectCode?: string,
  JournalEntryLines: JournalEntryLines[]
}

export interface JournalEntryLines {
  AccountCode: string,
  Credit: number,
  Debit: number,
  Reference1: string,
  LineMemo: string,
  ProjectCode: string,
  BPLID: string
}
