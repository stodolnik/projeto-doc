import { JournalEntry } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class JournalEntriesRequest {
  @ApiModelProperty({isArray: true, type: JournalEntry})
  readonly journalEntries: JournalEntry[];
}