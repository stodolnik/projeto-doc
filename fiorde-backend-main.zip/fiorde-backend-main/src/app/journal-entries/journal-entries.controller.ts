import { Controller, Post, Body, Headers, Patch } from '@nestjs/common'
import { JournalEntriesRequest } from './interfaces/controller';
import { JournalEntriesService } from './journal-entries.service'
import { ApiImplicitHeader } from '@nestjs/swagger';

@Controller('journal-entries')
export class JournalEntriesController {

  constructor(private readonly journalEntriesService: JournalEntriesService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: JournalEntriesRequest, @Headers('token') token) {
    try {
      return this.journalEntriesService.create(body);
    } catch (err) {
      throw err;
    }
  }
}
