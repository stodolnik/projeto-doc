import { JournalEntryModel } from './interfaces/service';
import { HanaProjectsService } from '../../b1/hana/projects/projects.service';
import { HanaBranchService } from '../../b1/hana/branch/branch.service';
import { JournalEntriesRequest } from './interfaces/controller/index';
import { ConfigService } from '../../config/config.service';
import { Mapper } from './interfaces/service';
import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import * as _ from 'lodash';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { response } from '../../core/http/http.service';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';
import { isNull } from 'lodash';

@Injectable()
export class JournalEntriesService {
  constructor(
    private readonly configService: ConfigService,
    private readonly hanaBranchService: HanaBranchService,
    private readonly hanaProjectsService: HanaProjectsService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaLogService: HanaLogService
  ) { } đ

  private readonly defaultConfig = this.configService.companyConfig();

  async create(data: JournalEntriesRequest) {
    try {
      let result = [];
      const journalEntries = Mapper.FromList(data.journalEntries);

      for (const entry of journalEntries) {

        try {

          await this.validateJournalEntriesForInsert(entry);

          const document = await this.resolveJournalEntries(entry);

          //const { error: entryError, data: entryData } = await this.serviceLayerJournalEntryService.session(token).create(entry);

          const endpoint = `${Endpoints.JournalEntries}`;
          console.log('document' , JSON.stringify(document));
          const res = await this.serviceLayerService.post(endpoint, document, { credentials: this.defaultConfig, retries: 3 });

          const _response = await response(res);

          if (!_response.error && _response.data) {
            // entry.Reference
            const log = this.objectmodelLog(_response.data.Number || '', data, JSON.stringify(_response.data), 'Sucesso');
            await this.hanaLogService.insertLog(log);
            result.push({ error: null, id: _response.data.Number });

          } else {

            throw {
              error: {
                code: 'JE500',
                message: _response.error.innerMessage,
                innerMessage: _response.error.innerMessage
              },
              id: entry.Reference
            }

          }
        }
        catch (err) {
          console.log(err)
          throw new HttpException([{ ...err }], HttpStatus.UNPROCESSABLE_ENTITY);
        }
      }

      return result;
    } catch (err) {
      const log = this.objectmodelLog(err.id || '', data, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw err;
    }
  }

  async resolveJournalEntries(doc: JournalEntryModel): Promise<JournalEntryModel> {
    try {
      const { data: branchData } = await this.hanaBranchService.getByCnpj(_.first(doc.JournalEntryLines).BPLID);
      //validates if the branch exists
      if (_.isEmpty(branchData)) throw {
        error: {
          code: 'BP009',
          message: 'Branch not exists.',
          innerMessage: 'Branch not exists.'
        },
        id: doc.Reference
      }
      doc.JournalEntryLines.forEach(i => { i.BPLID = branchData[0].id });

      return doc;
    } catch (err) {
      throw err;
    }
  }

  async validateJournalEntriesForInsert(doc: JournalEntryModel): Promise<void> {
    try {
      //validates if the project exists
      if (!_.isEmpty(_.get(doc, 'ProjectCode'))) {

        const { data: projectData } = await this.hanaProjectsService.getById(doc.ProjectCode);

        if (projectData && projectData.length == 0) {
          throw {
            error: {
              code: 'PRJC001',
              message: 'Project not exists.',
              innerMessage: 'Project not exists.'
            },
            id: doc.Reference
          }
        }
      }
    } catch (err) {
      throw err;
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Lcm`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }
}
