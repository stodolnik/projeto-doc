import { Module } from '@nestjs/common';
import {  HanaBusinessPartnersModule } from '../../b1/hana/business-partners/business-partners.module';
import { HanaPurchaseInvoiceModule } from '../../b1/hana/purchase-invoice/purchase-invoice.module';
import { PurchaseInvoicesController } from './purchase-invoices.controller';
import { HanaProjectsModule } from '../../b1/hana/projects/projects.module';
import { PurchaseInvoicesService } from './purchase-invoices.service';
import { HanaBranchModule } from '../../b1/hana/branch/branch.module';
import { HanaItemsModule } from '../../b1/hana/items/items.module';
import { SkillModule } from '../../b1/hana/skill/skill.module';
import { ModelModule } from '../../b1/hana/model/model.module';
import { PartnerModule } from '../partner/partner.module';
import { ConfigModule } from '../../config/config.module';
import { DraftModule } from '../draft/draft.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';

@Module({
  imports: [ HanaPurchaseInvoiceModule, ConfigModule, LogModuleHana, HanaBusinessPartnersModule, PartnerModule, SkillModule, ModelModule, HanaProjectsModule, HanaItemsModule, DraftModule, HanaBranchModule],
  providers: [ PurchaseInvoicesService ],
  controllers: [ PurchaseInvoicesController ]
})

export class PurchaseInvoicesModule {}
