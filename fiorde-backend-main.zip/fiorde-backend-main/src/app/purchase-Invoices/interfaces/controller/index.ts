import { PurchaseInvoices } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class PurchaseInvoicesRequest {
  @ApiModelProperty({isArray: true, type: PurchaseInvoices})
  readonly purchase: PurchaseInvoices[];
}