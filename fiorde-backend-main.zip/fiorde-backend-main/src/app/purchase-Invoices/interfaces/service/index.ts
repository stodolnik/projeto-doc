import { Partner, PartnerAddress } from '../../../partner/interfaces/service/index';
import { ObjectTypeSAP } from '../../../draft/interfaces/service/index';
import { DraftsModel } from '../../../draft/interfaces/service/index';
import _ = require("lodash");
import { ApiModelProperty } from "@nestjs/swagger";


export const DeliveryDraft = (doc: PurchaseInvoicesModel): DraftsModel => {

  return {
    CardCode: '',
    DocObjectCode: ObjectTypeSAP.Invoices,
    NumAtCard: doc.NumAtCard,
    Project: doc.Project,
    BPL_IDAssignedToInvoice: doc.BPL_IDAssignedToInvoice,
    U_finNfe: 1,
    U_ALFA_Natureza: 'REM IMPORT. POR CONTA/ ORDEM DE TERCEIRO',
    DocumentLines: doc.DocumentLines.map(i => {
      let item = {
        ItemCode: i.ItemCode,
        Quantity: i.Quantity,
        UnitPrice: i.UnitPrice,
        Usage: '17',
        //TaxCode: i.TaxCode,
        U_PercentIPI: i.U_PercentIPI
      }
      return item;
    })
  }

}

const FromList = (doc: PurchaseInvoices[]): Invoices[] => {
  let line = 0;
  return doc.map(d => {
    let invoices: PurchaseInvoicesModel = {
      CardCode: d.partnerCode,
      DocDate: d.documentDate,
      DocDueDate: d.dueDate,
      TaxDate: d.taxDate,
      Project: d.project,
      SequenceModel: d.model,
      Comments: d.comments,
      //DiscountPercent: d.discountPercent,
      //Confirmed: d.status = d.status == '0' ? 'N' : 'Y',
      U_SKILL_FormaPagto: d.paymentMethod || '99',
      PaymentGroupCode: "-1",
      OpeningRemarks: d.openingRemarks,
      ClosingRemarks: d.closingRemarks,
      DocCurrency: "R$",
      NumAtCard: d.partnerDocumentNumber,
      BPL_IDAssignedToInvoice: d.branch,
      U_ALFA_Natureza: 'IMPORTAÇÃO POR CONTA E ORDEM DE TERCEIRO',
      //U_DocumentType: d.documentType,
      DocumentLines: d.items.map(i => {
        const item: DocumentLines = {
          LineNum: line++,
          ItemCode: i.itemCode,
          Quantity: i.quantity,
          UnitPrice: i.unitPrice,
          Usage: 50,
          //TaxCode: '3949-001',
          //WarehouseCode: i.warehouse, // comentado para teste -------------------
          U_B1SYS_IVAST: i.ivaSt || i.percentIPI,
          U_PercentIPI: String(i.percentIPI)
        }
        return item;
      }),
      DocumentAdditionalExpenses: (d.additionalExpenses || []).map(a => {
        const expenses: DocumentAdditionalExpenses = {
          ExpenseCode: a.expenseCode,
          Remarks: a.remarks,
          //TaxCode: '3949-001',
          //DistributionMethod: a.distributionMethod,
          //DistributionMethod: "aedm_RowTotal",
          //WTLiable: a.irf == 'Y' ? 'tYes' : 'tNo',
          LineTotal: a.lineTotal,
          Project: d.project
        }
        return expenses;
      }),
      TaxExtension: {
        Incoterms: d.taxExtensions.incoterms,
        Vehicle: d.taxExtensions.vehicle,
        PackQuantity: d.taxExtensions.packQuantity,
        PackDescription: d.taxExtensions.packDescription,
        NetWeight: d.taxExtensions.netWeight,
        GrossWeight: d.taxExtensions.grossWeight
      }
    };

    let partner: Partner = {
      code: d.partnerCode,
      name: d.partner.name,
      type: 'cSupplier',
      address: (d.partner.address || []).map((a, i) => {
        const address: PartnerAddress = {
          street: a.street,
          number: a.number,
          block: a.block,
          city: a.city,
          building: a.building,
          zipCode: a.zipCode,
          state: a.state,
          county: a.county,
          country: a.country
        }
        return address;
      }),
      fiscalInformations: [{ cnpj: d.partner.cnpj }]
    };

    let diData: DIdata[] = d.items.map(i => {
      const di: DIdata = {
        exporterCode: d.partnerCode,
        declarationType: i.declarationType,
        //itemCode: i.itemCode,
        diNumber: i.diNumber,
        diDate: i.diDate,
        location: i.location,
        uf: i.uf,
        landingDate: i.landingDate,
        //drawback: i.drawback,
        transport: i.transport,
        afrmmValue: i.afrmmValue,
        importModel: i.importModel,
        purchasersCNPJ: i.purchasersCNPJ,
        purchasersUF: i.purchasersUF
      }
      return di;
    });

    let diAdditional: DIAdditional[] = d.items.map(i => {
      const di: DIAdditional = {
        Number: i.numAdditional,
        NumberSeq: i.sequenceAdditional,
        Discount: i.descountAdditional,
        ItemId: ''
      }
      return di;
    });


    return { invoicesModel: invoices, partner, diData, diAdditional }

  });
}

export const Mapper = {
  FromList
};


export class TaxExtensions {

  @ApiModelProperty()
  public incoterms: number;

  public taxId0: string;

  @ApiModelProperty()
  public vehicle?: string;

  @ApiModelProperty()
  public packQuantity?: string;

  @ApiModelProperty()
  public packDescription?: string;

  @ApiModelProperty()
  public netWeight?: number;

  @ApiModelProperty()
  public grossWeight?: number

  public TaxId1: string;

  public TaxId4: string;
}

export class DocumentItem {

  public id: number;

  @ApiModelProperty()
  public itemCode: string;

  public itemName: string;

  @ApiModelProperty()
  public quantity: number;

  @ApiModelProperty()
  public unitPrice: number;

  @ApiModelProperty()
  public percentIPI: number;

  @ApiModelProperty()
  public ivaSt: number;

  public usage: number;

  public taxCode: string;

  @ApiModelProperty()
  public warehouse?: string;


  public exporterCode?: string;

  @ApiModelProperty()
  public declarationType?: string;

  @ApiModelProperty()
  public diNumber?: string;

  @ApiModelProperty()
  public diDate?: Date;

  @ApiModelProperty()
  public location?: string;

  @ApiModelProperty()
  public uf?: string;

  @ApiModelProperty()
  public landingDate?: Date;

  public drawback?: string;

  @ApiModelProperty()
  public transport?: string;

  @ApiModelProperty()
  public afrmmValue?: number;

  @ApiModelProperty()
  public importModel?: string;

  @ApiModelProperty()
  public purchasersCNPJ?: string;

  @ApiModelProperty()
  public purchasersUF?: string;

  @ApiModelProperty()
  public numAdditional?: string;

  @ApiModelProperty()
  public sequenceAdditional?: string;

  @ApiModelProperty()
  public descountAdditional?: number;

}

export class PartnerAddresses {

  @ApiModelProperty()
  street: string;

  @ApiModelProperty()
  number: string;

  @ApiModelProperty()
  block: string;

  @ApiModelProperty()
  city: string;

  @ApiModelProperty()
  building: string;

  @ApiModelProperty()
  zipCode: string;

  @ApiModelProperty()
  state: string;

  @ApiModelProperty()
  county: string;

  @ApiModelProperty()
  country: string;
}

export class Partners {

  public code: string;

  @ApiModelProperty()
  public name: string;

  @ApiModelProperty()
  public phone: string;

  @ApiModelProperty()
  public cellular: string;

  @ApiModelProperty()
  public email: string;

  @ApiModelProperty()
  public cnpj: string;

  public type: string;

  @ApiModelProperty({ isArray: true, type: PartnerAddresses })
  public address: PartnerAddresses[];
}

export class AdditionalExpenses {

  @ApiModelProperty()
  public expenseCode?: number;

  @ApiModelProperty()
  public remarks?: string;

  @ApiModelProperty()
  public taxCode?: string;

  @ApiModelProperty()
  public distributionMethod?: string;

  @ApiModelProperty()
  public irf?: string;

  @ApiModelProperty()
  public lineTotal?: number;

  public project?: string;
}

export class PurchaseInvoices {

  public id: number;

  public documentNumber: string;

  @ApiModelProperty()
  public project: string;

  // @ApiModelProperty()
  // public documentType: string;

  @ApiModelProperty()
  public partnerCode: string;

  @ApiModelProperty()
  public documentDate: Date;

  @ApiModelProperty()
  public branch: string;

  @ApiModelProperty()
  public dueDate: Date;

  @ApiModelProperty()
  public taxDate: Date;

  @ApiModelProperty()
  public comments: string;

  public discountPercent: number;

  public status: string;

  @ApiModelProperty()
  public model: string;

  public paymentMethod: string;

  @ApiModelProperty()
  public openingRemarks: string;

  @ApiModelProperty()
  public closingRemarks: string;

  public currency: string;

  @ApiModelProperty()
  public partnerDocumentNumber: string;

  public freightType: number;

  public payment: number;

  @ApiModelProperty({ isArray: true, type: DocumentItem })
  public items: DocumentItem[];

  @ApiModelProperty()
  public taxExtensions: TaxExtensions;

  @ApiModelProperty()
  public partner: Partners;

  @ApiModelProperty({ isArray: true, type: AdditionalExpenses })
  public additionalExpenses: AdditionalExpenses[];

}


export interface Invoices {
  invoicesModel: PurchaseInvoicesModel,
  partner?: Partner,
  diData?: DIdata[],
  diAdditional?: DIAdditional[]
}

export class DIdata {

  public companyId?: string;
  public objtype?: number;
  public docNum?: string;

 // public typeDoc?: string;

 // public key?: string;

  public lineNum?: string;

  public exporterCode?: string;

  public declarationType?: string;

//  public itemCode?: string;

  public diNumber?: string;

  public diDate?: Date;

  public location?: string;

  public uf?: string;

  public landingDate?: Date;

  //public drawback?: string;

  public transport?: string;

  public afrmmValue?: number;

  public importModel?: string;

  public purchasersCNPJ?: string;

  public purchasersUF?: string;
}

export class DIAdditional {

  ImporterId?: string;
     Number?: string;
    NumberSeq?: string;
    SuppCode?: string; 
    Discount?: number;
    PurchaseId?:number;
    ItemId?: string;
    nDraw?: string
}

export interface PurchaseInvoicesModel {
  DocEntry?: string,
  DocNum?: string,
  DocDate?: Date,
  DocDueDate?: Date,
  TaxDate?: Date,
  CardCode?: string,
  CardName?: string,
  DocTotal?: number,
  SalesPersonCode?: number
  DocumentStatus?: string,
  SequenceModel?: string,
  Confirmed?: string,
  NumAtCard?: string,
  gmaBankInfo?: string,
  ShipToCode?: string,
  DocCurrency?: string,
  DocRate?: number,
  DiscountPercent?: number,
  TotalDiscount?: number,
  PaymentGroupCode?: string,
  TransportationCode?: string,
  Comments?: string,
  BPL_IDAssignedToInvoice?: string,
  U_SKILL_FormaPagto?: string,
  U_ALFA_Natureza?: string,
  U_FiordeIntegratedId?: string,
  Project?: string,
  //BPLName?: string,
  Carrier?: string,
  OpeningRemarks?: string,
  ClosingRemarks?: string,
  U_EmailEnvDanfe?: string,
  //U_DocumentType?: string,
  DocumentLines?: DocumentLines[],
  TaxExtension?: TaxExtension,
  DocumentAdditionalExpenses?: DocumentAdditionalExpenses[]
}

export interface DocumentLines {
  LineNum?: number,
  ItemCode?: string,
  Quantity?: number,  
  Price?: number,
  DiscountPercent?: number,
  LineTotal?: number,
  UnitPrice?: number,
  Usage?: number,
  WarehouseCode?: string,
  TaxCode?: string,
  U_B1SYS_IVAST: number,
  U_PercentIPI?: string,
  U_skill_Compbas?: number
}

export interface TaxExtension {
  Incoterms?: number,
  Vehicle?: string,
  PackQuantity?: string,
  PackDescription?: string,
  NetWeight?: number,
  GrossWeight?: number
}

export interface DocumentAdditionalExpenses {
  ExpenseCode?: number,
  Remarks?: string,
  TaxCode?: string,
  DistributionMethod?: string,
  WTLiable?: string,
  LineTotal?: number,
  Project?: string 
}
