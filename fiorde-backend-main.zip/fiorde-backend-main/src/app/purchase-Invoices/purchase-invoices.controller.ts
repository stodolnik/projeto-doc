import { Controller, Post, Body, Headers, Patch, HttpStatus, Response } from '@nestjs/common'
import { PurchaseInvoicesRequest } from './interfaces/controller';
import { PurchaseInvoicesService } from './purchase-invoices.service'
import { ApiImplicitHeader } from '@nestjs/swagger';

@Controller('purchase-invoices')
export class PurchaseInvoicesController {

  constructor(private readonly purchaseInvoicesService: PurchaseInvoicesService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: PurchaseInvoicesRequest, @Headers('token') token) {
    try {
      return this.purchaseInvoicesService.create(body);
    } catch (err) {
      throw err;
    }
  }
}
