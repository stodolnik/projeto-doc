import { Controller, Post, Body, Headers, Patch  , Get , Param} from '@nestjs/common'
import { ProjectsRequest } from './interfaces/controller';
import { ProjectsService } from './projects.service'
import { ApiImplicitHeader , ApiImplicitParam } from '@nestjs/swagger';

@Controller('projects')
export class ProjectsController {

  constructor(private readonly projectsService: ProjectsService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: ProjectsRequest, @Headers('token') token) {
    try {
      console.log('teste');
      return this.projectsService.create(body);
    } catch (err) {
      throw err;
    }
  }

  @Get('/:id')
  @ApiImplicitHeader({ name: 'token', required: true })
  @ApiImplicitParam({ name: 'id', required: true })
  async getByProject(@Param('id') id, @Headers('token') token) {
    try {
      return this.projectsService.getProjectByCode(id);
    } catch (err) {
      throw err;
    }
  }

}
