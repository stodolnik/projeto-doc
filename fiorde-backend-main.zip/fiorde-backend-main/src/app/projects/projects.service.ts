import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { ProjectsRequest } from './interfaces/controller';
import { ConfigService } from '../../config/config.service';
import { Mapper } from './interfaces/service';
import { HanaProjectsService } from '../../b1/hana/projects/projects.service';
import { ProjectsModel } from './interfaces/service/index';
import * as _ from 'lodash';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { response } from '../../core/http/http.service';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class ProjectsService {
  constructor(
    private readonly configService: ConfigService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaProjectsService: HanaProjectsService,
    private readonly hanaLogService: HanaLogService
  ) { }

  private readonly defaultConfig = this.configService.companyConfig();

  async getProjectByCode(id : string){

    try{
      const { data: projectData } = await this.hanaProjectsService.getById(id.trim());

      if (projectData.length > 0){
        const log = this.objectmodelLog(id || '', id, JSON.stringify(projectData[0]), 'Sucesso');
        await this.hanaLogService.insertLog(log);
        return {error: null , id: projectData[0]};
      }else{
        throw {
          error: {
            code: 'PRJ001',
            message: 'Código do projeto não existe.',
            innerMessage: 'Código do projeto não existe.'
          },
          id: id
        }
      }  
    }catch(err){
      const log = this.objectmodelLog(err.id || '', id, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw new HttpException([{ ...err }], _.get(err, 'error').code == 401 ? HttpStatus.UNAUTHORIZED : HttpStatus.UNPROCESSABLE_ENTITY);
    }

  }

  async create(data: ProjectsRequest) {
    try {

      let result = [];
      const projects = Mapper.FromList(data.projects);

      for (const project of projects) {

        try {

          await this.validateProjectForInsert(project);

          // const document = await this.resolveProject(project, token);

          //const { error: projectError, data: projectData } = await this.serviceLayerProjectsService.session(token).create(project);

          const endpoint = `${Endpoints.Projects}`;

          const res = await this.serviceLayerService.post(endpoint, project, { credentials: this.defaultConfig, retries: 3 });
          const _response = await response(res);

          if (!_response.error && _response.data) {

            const log = this.objectmodelLog(project.Code || '', data, JSON.stringify(_response.data), 'Sucesso');
            await this.hanaLogService.insertLog(log);
            result.push({ error: null, id: project.Code });

          } else {

            throw {
              error: {
                code: 'PRJC500',
                message: _response.error.innerMessage,
                innerMessage: _response.error.innerMessage
              },
              id: project.Code
            }

          }
        }
        catch (err) {
          console.log(err);
          throw new HttpException([{ ...err }], _.get(err, 'error').code == 401 ? HttpStatus.UNAUTHORIZED : HttpStatus.UNPROCESSABLE_ENTITY);
        }
      }

      return result;

    } catch (err) {
      console.log(err);
      const log = this.objectmodelLog(err.id || '', data, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw err;
    }
  }

  // async resolveProject(doc: ProjectsModel): Promise<ProjectsModel> {

  //   return doc;
  // }

  async validateProjectForInsert(doc: ProjectsModel): Promise<void> {
    try {
      const { data: projectData } = await this.hanaProjectsService.getById(doc.Code);

      if (projectData && projectData.length > 0) {
        throw {
          error: {
            code: 'PRJC000',
            message: 'Código do projeto já existe.',
            innerMessage: 'Código do projeto já existe.'
          },
          id: doc.Code
        }
      }
    } catch (err) {
      throw err;
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Projeto`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }

}