import { ApiModelProperty } from "@nestjs/swagger";
import _ = require("lodash");

const FromList = (doc: Projects[]): ProjectsModel[] => {
  return doc.map(d => {
    let Projects: ProjectsModel = {
      Code: d.code,
      Name: d.description,
      ValidTo: d.validTo,
      ValidFrom: d.validFrom,
      U_ALFA_CustomerReference: d.customerReference,
      U_ALFA_Module: d.module
    };

    let ommited = _.omitBy(Projects, _.isNil);
    return ommited;
  });
}

export const Mapper = {
  FromList
};

export class Projects {

  @ApiModelProperty()
  public code: string;

  @ApiModelProperty()
  public description: string;

  @ApiModelProperty()
  public validFrom: Date;

  @ApiModelProperty()
  public validTo: Date;

  @ApiModelProperty()
  public module: string;

  @ApiModelProperty()
  public customerReference: string;


}

export interface ProjectsModel {
  Code?: string, 
  Name?: string,
  ValidFrom?: Date,
  ValidTo?: Date,
  U_ALFA_CustomerReference?: string,
  U_ALFA_Module?: string
}
