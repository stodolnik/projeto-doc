import { Projects } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class ProjectsRequest {
  @ApiModelProperty({isArray: true, type: Projects})
  readonly projects: Projects[];
}