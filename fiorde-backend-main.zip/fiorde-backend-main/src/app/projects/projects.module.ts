import { Module } from '@nestjs/common';
import { ProjectsService } from './projects.service';
import { ProjectsController } from './projects.controller';
import { HanaProjectsModule } from '../../b1/hana/projects/projects.module';
import { ConfigModule } from '../../config/config.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';

@Module({
  imports: [ ConfigModule,  HanaProjectsModule, LogModuleHana],
  providers: [ ProjectsService ],
  controllers: [ ProjectsController ]
})

export class ProjectsModule {}
