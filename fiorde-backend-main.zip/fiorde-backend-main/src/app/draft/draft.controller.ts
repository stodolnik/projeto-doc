// import { Controller, Post, Body, Headers } from '@nestjs/common'
// import { PartnerService } from './partner.service'
// import { PartnerRequest } from './interfaces/controller';
// import { ApiImplicitHeader } from '@nestjs/swagger';

// @Controller('partner')
// export class PartnerController {

//   constructor(private readonly partnerService: PartnerService) { }

//   // @Post()
//   // @ApiImplicitHeader({name: 'token', required: true})
//   // async createOrUpdate(@Body() body: PartnerRequest, @Headers('token') token) {
//   //   return this.partnerService.createOrUpdate(body, token);
//   // }
  
// }