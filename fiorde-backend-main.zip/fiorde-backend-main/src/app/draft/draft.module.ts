import { Module } from '@nestjs/common';
import { DraftService } from './draft.service';
import { HanaDeliveryInvoiceModule } from '../../b1/hana/delivery-invoice/delivery-invoice.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { ConfigModule } from '../../config/config.module';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';

@Module({
  imports: [ HanaDeliveryInvoiceModule, ConfigModule, LogModuleHana],
  providers: [DraftService],
  exports: [DraftService]
})

export class DraftModule { }
