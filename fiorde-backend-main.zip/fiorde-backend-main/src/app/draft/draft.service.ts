import { Injectable } from '@nestjs/common';
import { DraftsModel } from './interfaces/service';
import { HanaDeliveryInvoiceService } from '../../b1/hana/delivery-invoice/delivery-invoice.service';
import _ = require('lodash');
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { response } from '../../core/http/http.service';
import { ConfigService } from '../../config/config.service';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class DraftService {
  constructor(
    private readonly hanaDeliveryInvoiceService: HanaDeliveryInvoiceService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaLogService: HanaLogService,
    private readonly configService: ConfigService) { }

  private readonly defaultConfig = this.configService.companyConfig();

  async create(draft: DraftsModel, sumDAUnit: number) {

    let result = [];

    try {

      for (const line of draft.DocumentLines) {

        line.UnitPrice = line.UnitPrice + sumDAUnit;

        //const { data: taxData } = await this.hanaDeliveryInvoiceService.getTax(line.U_PercentIPI);

        line.Usage = '91';
        // line.TaxCode = taxData[0].taxId;

        //delete line.U_PercentIPI;
      }

      const endpoint = `${Endpoints.Drafts}`;
      
      const { data, error } = await this.serviceLayerService.post(endpoint, draft, { credentials: this.defaultConfig, retries: 3 });
      const log = this.objectmodelLog(draft.NumAtCard || '', draft, JSON.stringify(data), 'Sucesso');
      await this.hanaLogService.insertLog(log);
      console.log(error);
      // console.log(draftResult)
      // console.log(draftError)
      // if (!draftError && draftResult) {

      //   return result.push({ error: null, id: draftResult.NumAtCard });

      // } else {

      //   throw {
      //     error: {
      //       code: 'DRF001',
      //       message: draftError.innerMessage,
      //       innerMessage: draftError.innerMessage
      //     },
      //     id: draft.NumAtCard
      //   }
      // }

    } catch (err) {
      console.log(err)
      const log = this.objectmodelLog(err.id || '', draft, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      return err;
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Esboco`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }
}