import { ApiModelProperty } from "@nestjs/swagger";
import { ExtraField } from "../../../../app/common/interfaces";
import { BusinessPartnersModel, BPAddress, BPFiscalTaxID } from "../../../partner/interfaces/service/index";
import _ = require("lodash");

// const FromList = (doc: Document): any => {

// }

export interface Draft {
  CardCode: string,
  DocObjectCode: string,
  NumAtCard: string,
  Project: string,
  DocumentLines: DocumentLine[]

}

export enum ObjectTypeSAP {
  'Delivery' = '15',
  'Invoices' = '13'
}

export interface DraftsModel {
  CardCode: string,
  DocObjectCode: string,
  NumAtCard: string,
  Project: string,
  BPL_IDAssignedToInvoice?: string,
  U_finNfe?: number,
  U_ALFA_Natureza?: string,
  Comments?: string,
  DocumentLines: DocumentLine[]

}

export interface DocumentLine {
  ItemCode: string,
  Quantity: number,
  TaxCode?: string,
  UnitPrice: number,
  Usage: string,
  U_PercentIPI: string
}