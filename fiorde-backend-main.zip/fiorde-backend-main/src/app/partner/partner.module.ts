import { Module } from '@nestjs/common';
import { PartnerService } from './partner.service';
import { PartnerController } from './partner.controller';
import { HanaBusinessPartnersModule } from '../../b1/hana/business-partners/business-partners.module';
import { HanaCountyCodesModule } from '../../b1/hana/county-codes/county-codes.module';
import { ConfigModule } from '../../config/config.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
//import { BankModule } from '../../b1/hana/banks/bank.module';
import { FiordePartnerModule } from '../../fiorde/partner/partner.module';
import { FiordeLoginModule } from '../../fiorde/login/login.module';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';
@Module({
  imports: [ HanaBusinessPartnersModule, ConfigModule, LogModuleHana, HanaCountyCodesModule, FiordePartnerModule, FiordeLoginModule],
  providers: [ PartnerService ],
  exports: [PartnerService]
})

export class PartnerModule {}
