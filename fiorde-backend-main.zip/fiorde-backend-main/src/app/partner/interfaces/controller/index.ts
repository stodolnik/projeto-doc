import { Partner } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class PartnerRequest extends Partner {

}