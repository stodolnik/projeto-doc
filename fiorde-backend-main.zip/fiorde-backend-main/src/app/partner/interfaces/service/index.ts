import { ApiModelProperty } from "@nestjs/swagger";
import { ExtraField } from "../../../../app/common/interfaces";
import _ = require("lodash");

const FromList = (partners: Partner): any => {


	let bp: BusinessPartnersModel = {
		CardCode: partners.code,
		CardName: partners.name,
    CardType: partners.type,
    Phone1: partners.phone1,
    Cellular: partners.cellular,
    EmailAddress: partners.email,
    BPAddresses: [],
    BPFiscalTaxIDCollection:(partners.fiscalInformations || []).map((t) => {
      const tax: BPFiscalTaxID = {
        TaxId5: '',
        TaxId0: t.cnpj,
        BPCode: partners.code
      }
      return tax;
    })
  };

	(partners.address || []).forEach((a) => {
		const address: BPAddress[] = [{
			AddressName: 'Entrega',
			AddressType: 'bo_ShipTo',
			Street: a.street,
			StreetNo: a.number,
			BuildingFloorRoom: a.building,
			ZipCode: a.zipCode,
			Block: a.block,
			City: a.city,
			State: a.state,
			County: a.county,
			Country:  a.country,
			// U_SKILL_indIEDest: a.indIEDest
		}, {
			AddressName: 'Cobranca',
			AddressType: 'bo_BillTo',
			Street: a.street,  
			StreetNo: a.number,
			BuildingFloorRoom: a.building,
			ZipCode: a.zipCode,
			Block: a.block,
			City: a.city,
			State: a.state,
			County: a.county,
			Country: a.country
			// U_SKILL_indIEDest: a.indIEDest
		}];
		bp.BPAddresses = bp.BPAddresses.concat(address);
	});

	let ommited = _.omitBy(bp, _.isNil);
	ommited = _.omitBy(bp, item => _.isArray(item) && _.isEmpty(item));

	return ommited;
}


export const Mapper = {
	FromList
}

export class PartnerFiscalInformation {

	// @ApiModelProperty()
	// public address: string;

	// @ApiModelProperty()
	// public addressType: string;

  @ApiModelProperty()
  public cnpj?: string;

	@ApiModelProperty()
	public ie?: string;

	@ApiModelProperty()
	public foreignId?: string;

	@ApiModelProperty()
	public de?: string;
}

export class PartnerAddress {

	// @ApiModelProperty()
	// addressName: string;

	// @ApiModelProperty()
	// addressType: AdrressType;

	@ApiModelProperty()
	street?: string;

	@ApiModelProperty()
	number?: string;

	@ApiModelProperty()
	block?: string;

	@ApiModelProperty()
	city?: string;

	@ApiModelProperty()
	building?: string;

	// @ApiModelProperty()
	// streetType: string;

	@ApiModelProperty()
	zipCode?: string;

	@ApiModelProperty()
	state?: string;

	@ApiModelProperty()
	county?: string;

	@ApiModelProperty()
	country?: string;

	// @ApiModelProperty()
	// indIEDest: string;

	// @ApiModelProperty()
	// extraFields: ExtraField[]
}

export class Partner {

	@ApiModelProperty()
	public code: string;

	@ApiModelProperty()
	public name: string;

	@ApiModelProperty()
	public type: string;

  @ApiModelProperty()
	public cnpj?: string;

	@ApiModelProperty()
	public phone1?: string;

	@ApiModelProperty()
	public phone2?: string;

  @ApiModelProperty()
  public cellular?: string;

	@ApiModelProperty()
	public email?: string;

	@ApiModelProperty()
	public nfseEmail?: string;

	@ApiModelProperty({ isArray: true, type: PartnerFiscalInformation })
	public fiscalInformations?: PartnerFiscalInformation[];

	@ApiModelProperty({ isArray: true, type: PartnerAddress })
	public address?: PartnerAddress[];

	// @ApiModelProperty({ isArray: true, type: PartnerContacts })
	// public contacts: PartnerContacts[];

	// @ApiModelProperty({ isArray: true, type: ExtraField })
	// public extraFields: ExtraField[];
}

enum AdrressType {
	'bo_ShipTo' = 'S',
	'bo_BillTo' = 'B'
}
export interface BusinessPartnersModel {
  CardCode?: string,
  CardName?: string,
  CardType?: string,
  Phone1?: string,
  Phone2?: string,
  AliasName?: string,
  Cellular?: string,
  Fax?: string, 
  Website?: string,
  Notes?: string,
  //modifiquei aqui
  BPAddresses?: BPAddress[],
  BPFiscalTaxIDCollection?: BPFiscalTaxID[],
  // ContactEmployees?: ContactEmployee[],
  U_SKILL_NFSEEMAIL?: string,
  EmailAddress?: string,
  BPCode?: string,
  GroupCode?: string,
  Series?: string
}

export interface BPFiscalTaxID {
  TaxId0?: string,
  TaxId1?: string,
  TaxId5?: string,
  TaxId6?: string,
  BPCode?: string
}

export interface BPAddress {
  AddressName?: string;
  AddressType?: string;
  Street?: string;
  StreetNo?: string;
  BuildingFloorRoom?: string;
  ZipCode?: string;
  Block?: string;
  City?: string;
  State?: string;
  County?: string;
  Country?: string;
  U_SKILL_indIEDest?: string;
  BPCode?: string;
  RowNum?: number;
}




// export interface ContactEmployee {
//   Name: string,
//   E_Mail: string,
//   BPCode?: string
// }

export interface BusinessPartnerGroup {
  Code?: string,
  Name?: string
}
