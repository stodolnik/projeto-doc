import { Injectable } from '@nestjs/common';
import { Interval, NestSchedule } from 'nest-schedule';
import { Mapper } from './interfaces/service/index';
import { HanaBusinessPartnersService } from '../../b1/hana/business-partners/business-partners.service';
import { HanaCountyCodesService } from '../../b1/hana/county-codes/county-codes.services';
import { Partner } from '../partner/interfaces/service/index';
import { BusinessPartnersModel } from "./interfaces/service";
import _ = require('lodash');
import { ConfigService } from '../../config/config.service';
import { response } from '../../core/http/http.service';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class PartnerService extends NestSchedule {
  constructor(
    private readonly hanaBusinessPartnersService: HanaBusinessPartnersService,
    private readonly hanaCountyCodesService: HanaCountyCodesService,
    private readonly configService: ConfigService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaLogService: HanaLogService
  ) {
    super();
  }

  private readonly defaultConfig = this.configService.companyConfig();

  async create(partner: Partner) {

    try {

      const businessPartner = Mapper.FromList(partner);

      await this.validateBusinessPartner(businessPartner);

      const businessPartner_ = await this.resolveBusinessPartner(businessPartner);

      const endpoint = `${Endpoints.BusinessPartners}`;

      const res = await this.serviceLayerService.post(endpoint, businessPartner_, { credentials: this.defaultConfig, retries: 3 });

      const _response = await response(res);
      console.log(_response)
      // const { data: partnerData, error: partnerError } = await this.businessPartnersService.session(token).create(businessPartner_);

      if (_response.error) {
        throw _response.error;
      }

      const log = this.objectmodelLog(businessPartner_.CardCode || '', partner, JSON.stringify(_response.data), 'Sucesso');
      await this.hanaLogService.insertLog(log);

    } catch (err) {
      const log = this.objectmodelLog(err.id || '', partner, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw err;
    }
  }

  async resolveBusinessPartner(businessPartner: BusinessPartnersModel): Promise<BusinessPartnersModel> {
    try {

      try {

        for (const bpaddresses of businessPartner.BPAddresses) {
          if (bpaddresses.State == 'EX') {
            const codeCounty = await this.hanaBusinessPartnersService.getByCodeCounty(bpaddresses.Country, bpaddresses.State)
            bpaddresses.County = codeCounty.data[0].AbsId; // _.first(codeCounty.data[0].AbsId); 

            bpaddresses.ZipCode = '00000000';
            bpaddresses.U_SKILL_indIEDest = "9";
          }
        }

        // businessPartner.BPFiscalTaxIDCollection.forEach(t => t.TaxId5 = '99999');
      } catch (exception) {
        throw exception;
      }

      return businessPartner;

    } catch (err) {
      throw err;
    }

  }

  async validateBusinessPartner(businessPartner: BusinessPartnersModel): Promise<void> {
    try {
      const { data: existingData } = await this.hanaBusinessPartnersService.getById(businessPartner.CardCode);

      if (existingData && existingData.length > 0) {

        throw {
          error: {
            code: 'B001',
            message: 'Customer already exists.',
            innerMessage: 'Customer already exists.'
          },
          id: businessPartner.CardCode
        }
      }

      for (const bpaddresses of businessPartner.BPAddresses) {
        if (bpaddresses.State == 'EX') {
          const codeCounty = await this.hanaBusinessPartnersService.getByCodeCounty(bpaddresses.Country, bpaddresses.State)
          if (!codeCounty.data || codeCounty.data.length == 0) {
            throw {
              error: {
                code: 'B001',
                message: 'State not exists.',
                innerMessage: 'State not exists.'
              },
              id: businessPartner.CardCode
            }
          }
        }
      }





      // if (_.isEmpty(_.first(businessPartner.BPAddresses).Block)) {

      //   throw {
      //     error: {
      //       code: 'B010',
      //       message: 'Block is required.',
      //       innerMessage: 'Block is required. [PartnerAddress]'
      //     },
      //     id: businessPartner.CardCode
      //   }
      // }

      // if (_.isEmpty(_.first(businessPartner.BPAddresses).StreetNo)) {

      //   throw {
      //     error: {
      //       code: 'B011',
      //       message: 'Number is required.',
      //       innerMessage: 'Number is required. [PartnerAddress]'
      //     },
      //     id: businessPartner.CardCode
      //   }
      // }

      // if (_.isEmpty(_.first(businessPartner.BPAddresses).Street)) {

      //   throw {
      //     error: {
      //       code: 'B012',
      //       message: 'Street is required.',
      //       innerMessage: 'Street is required. [PartnerAddress]'
      //     },
      //     id: businessPartner.CardCode
      //   }
      // }
    } catch (err) {
      throw err;
    }
  }

  async createClientBySupplier(cardCode: string) {

    console.log('createClientBySupplier: ', cardCode);
    
    try {
      const endpoint = `${Endpoints.BusinessPartners}`;
      const businessPartnerResponse = await this.serviceLayerService.get<BusinessPartnersModel>(`${endpoint}('${cardCode}')`, { credentials: this.defaultConfig, retries: 3 });

      if (businessPartnerResponse.error) {
        throw businessPartnerResponse.error;
      }
      
      let businessPartner: BusinessPartnersModel = {
        CardName: businessPartnerResponse.data.CardName,
        CardType: 'cCustomer',
        AliasName: businessPartnerResponse.data.AliasName,
        U_SKILL_NFSEEMAIL: businessPartnerResponse.data.U_SKILL_NFSEEMAIL,
        Notes: businessPartnerResponse.data.Notes,
        Phone1: businessPartnerResponse.data.Phone1,
        Phone2: businessPartnerResponse.data.Phone2,
        Cellular: businessPartnerResponse.data.Cellular,
        EmailAddress: businessPartnerResponse.data.EmailAddress,
        BPAddresses: businessPartnerResponse.data.BPAddresses,
        BPFiscalTaxIDCollection:businessPartnerResponse.data.BPFiscalTaxIDCollection
      };

      for(const line of businessPartner.BPAddresses){
        delete line.BPCode;
      }

      for(const line of businessPartner.BPFiscalTaxIDCollection){
        delete line.BPCode;
      }

      console.log('businessPartner: ', businessPartner);
      const res = await this.serviceLayerService.post(endpoint, businessPartner, { credentials: this.defaultConfig, retries: 3 });

      const _response = await response(res);

      if (_response.error) {
        throw _response.error;
      }

      const log = this.objectmodelLog('', businessPartner, JSON.stringify(_response.data), 'Sucesso');
      await this.hanaLogService.insertLog(log);

    } catch (err) {
      const log = this.objectmodelLog(err.id || '', cardCode, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      
      throw {
        error: {
          code: err.code,
          message: err.innerMessage,
          innerMessage: err.innerMessage
        },
        id: cardCode
      }
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Partner`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }

}