import { Module } from '@nestjs/common';
import { IncomingPaymentsService } from './incoming-payment.service';
import { IncomingPaymentsController } from './incoming-payment.controller';
import { HanaBusinessPartnersModule } from '../../b1/hana/business-partners/business-partners.module';
import { ConfigModule } from '../../config/config.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { HanaBranchModule } from '../../b1/hana/branch/branch.module';
import { HanaSaleInvoiceModule } from '../../b1/hana/sale-invoice/sale-invoice.module'
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';
@Module({
  imports: [ConfigModule, HanaBusinessPartnersModule, LogModuleHana, HanaBranchModule, HanaSaleInvoiceModule],
  providers: [IncomingPaymentsService],
  controllers: [IncomingPaymentsController]
})

export class IncomingPaymentsModule { }
