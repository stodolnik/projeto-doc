import { IncomingPayment } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class IncomingPaymentsRequest {
  @ApiModelProperty({isArray: true, type: IncomingPayment})
  readonly payment: IncomingPayment[];
}