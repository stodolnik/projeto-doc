import { Partner, PartnerAddress } from '../../../partner/interfaces/service/index';
import _ = require("lodash");
import { ApiModelProperty } from "@nestjs/swagger";

// const FromList = (doc: IncomingPayment[]): Payments[] => {
  
//   return doc.map(d => {
//     let payment: Payments = {
//       CardCode: d.cardCode,
//       DocDate: d.docDate,
//       DueDate: d.dueDate,
//       TaxDate: d.taxDate,
//       U_FIORDE_CODE: d.code,
//       BPLID: d.branch,
//       TransferAccount: d.transferAccount,
//       TransferDate: d.transferDate,
//       TransferSum: d.transferSum,
//       CashSum: d.cashSum,
//       PaymentInvoices: d.paymentInvoices.map(r => {
//         let invoice: PaymentInvoices = {
//           DocEntry: r.documentId,
//           InvoiceType: 'it_Invoice',
//           InstallmentId: r.installmentId
//         }
//         return invoice
//       })

//     }
//     return payment
//   })
// }

export const Mapper = {
  //FromList
};




export class Invoice {

  @ApiModelProperty()
  documentId: number;

  @ApiModelProperty()
  installmentId: number;

}

export class IncomingPayment {

  @ApiModelProperty()
  docInvoice: string;

  @ApiModelProperty()
  transferAccount: string;

  @ApiModelProperty()
  paymentDate: string;

}

// export class IncomingPayment {


//   @ApiModelProperty()
//   docDate: string;

//   @ApiModelProperty()
//   cardCode: string;

//   @ApiModelProperty()
//   cashSum: number;

//   @ApiModelProperty()
//   transferAccount: string;

//   @ApiModelProperty()
//   transferSum: number;

//   @ApiModelProperty()
//   transferDate: string;

//   @ApiModelProperty()
//   taxDate: string;

//   @ApiModelProperty()
//   dueDate: string;

//   @ApiModelProperty()
//   branch: string;

//   @ApiModelProperty()
//   code: string;

//   @ApiModelProperty({ isArray: true, type: Invoice })
//   paymentInvoices: Invoice[];

// }


export interface PaymentInvoices {
  DocEntry: number;
  InvoiceType: string;
  InstallmentId: number;
}

export interface Payments {
  DocDate: string;
  CardCode: string;
  CashSum: number;
  TransferAccount: string;
  TransferSum: number;
  TransferDate: string;
  TaxDate: string;
  DueDate: string;
  BPLID: string;
  U_FIORDE_CODE: String;
  PaymentInvoices: PaymentInvoices[];
}

