import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { IncomingPaymentsRequest } from './interfaces/controller/index';
import { ConfigService } from '../../config/config.service';
import { Mapper, Payments } from './interfaces/service';
import { HanaBusinessPartnersService } from '../../b1/hana/business-partners/business-partners.service';
import { HanaSaleInvoiceService } from '../../b1/hana/sale-invoice/sale-invoice.service'
import { HanaBranchService } from '../../b1/hana/branch/branch.service'
import * as _ from 'lodash';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { response } from '../../core/http/http.service';
import * as dayjs from 'dayjs';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class IncomingPaymentsService {
  constructor(
    private readonly configService: ConfigService,
    private readonly hanaBusinessPartnesService: HanaBusinessPartnersService,
    private readonly hanaSaleInvoiceService: HanaSaleInvoiceService,
    private readonly hanaBranchService: HanaBranchService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaLogService: HanaLogService
  ) { }

  private readonly defaultConfig = this.configService.companyConfig();

  async create(data: IncomingPaymentsRequest) {
    try {
      let result = [];
      let document = [];

      for (const payment of data.payment) {

        if (!payment['docInvoice'] || !payment['transferAccount']) {
          throw {
            error: {
              code: 'SI0001',
              message: `docInvoice or transferAccount invalid.`,
              innerMessage: `docInvoice or transferAccount invalid.`
            },
            id: payment['docInvoice']
          }
        }

        const dados = await this.hanaSaleInvoiceService.getInvoiceForPayment(payment['docInvoice'])
        if (dados.error) {
          throw {
            error: {
              code: 'SI0001',
              message: `docInvoice ${payment['docInvoice']} not found.`,
              innerMessage: `docInvoice ${payment['docInvoice']} not found.`
            },
            id: payment['docInvoice']
          }
        }
        if (dados.data.length === 0) {
          throw {
            error: {
              code: 'SI0001',
              message: `docInvoice ${payment['docInvoice']} not found.`,
              innerMessage: `docInvoice ${payment['docInvoice']} not found.`
            },
            id: payment['docInvoice']
          }
        }



        const verifyPayment = await this.hanaSaleInvoiceService.verifyExistPaymentOfInvoice(dados.data[0].DocEntry)
        if (verifyPayment.data.length > 0) {
          throw {
            error: {
              code: 'SI0001',
              message: `Exist an payment for ${payment['docInvoice']}.`,
              innerMessage: `Exist an payment for ${payment['docInvoice']}.`
            },
            id: payment['docInvoice']
          }
        }

        const verifyAccount = await this.hanaSaleInvoiceService.verifyExistAccount(payment['transferAccount'])
        if (verifyAccount.data.length === 0) {
          throw {
            error: {
              code: 'SI0001',
              message: `Account ${payment['transferAccount']} not found.`,
              innerMessage: `Account ${payment['transferAccount']} not found.`
            },
            id: payment['transferAccount']
          }
        }


        const paymentDate = payment['paymentDate'];

        if(!paymentDate || paymentDate == ''){
          throw {
            error: {
              code: 'SI0001',
              message: `Payment Date not found. Value ${paymentDate}`,
              innerMessage: `Payment Date not found. Value ${paymentDate}`
            },
            id: payment['docInvoice']
          }
        }

        const doc = {
          CardCode: dados.data[0].CardCode,
          DocDate: paymentDate,
          DueDate: paymentDate,
          TaxDate: paymentDate,
          BPLID: parseInt(dados.data[0].BPLId),
          TransferAccount: payment['transferAccount'],
          TransferDate: paymentDate,
          ProjectCode: dados.data[0].Project,
          TransferSum: parseFloat(dados.data[0].DocTotal),
          CashSum: 0.0,
          PaymentInvoices: [
            {
              DocEntry: parseInt(dados.data[0].DocEntry),
              InvoiceType: 'it_Invoice',
              InstallmentId: "1"
            }
          ]

        }
        document.push(doc);

      }

      for (const payment of document) {
        const endpoint = `${Endpoints.IncomingPayments}`;
        const res = await this.serviceLayerService.post(endpoint, payment, { credentials: this.defaultConfig, retries: 3 });
        const _response = await response(res);
        if (!_response.error && _response.data) {
          const dados = await this.hanaSaleInvoiceService.getNumberLcmByPayment(res.data['DocEntry'])
          // result.push({ error: null, id: res.data['DocEntry'] });
          if (dados.error) {
            throw {
              error: {
                code: 'SI001',
                message: 'Error - Get number LCM',
                innerMessage: 'Error - Get number LCM'
              }
            }
          }

          const log = this.objectmodelLog(dados.data[0].Number || '', data, JSON.stringify(_response.data), 'Sucesso');
          await this.hanaLogService.insertLog(log);
          result.push({ error: null, id: dados.data[0].Number });

        } else {

          throw {
            error: {
              code: 'SI001',
              message: _response.error.innerMessage,
              innerMessage: _response.error.innerMessage
            }
          }
        }
      }

      return result;
    } catch (err) {
      const log = this.objectmodelLog(err.id || '', data, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw new HttpException([{ ...err }], _.get(err, 'error').code == 401 ? HttpStatus.UNAUTHORIZED : HttpStatus.UNPROCESSABLE_ENTITY);
    }


  }







  async resolveInvoice(doc: Payments): Promise<Payments> {
    try {

      const { data: branchData, error: err } = await this.hanaBranchService.getByCnpj(doc.BPLID);

      doc.BPLID = branchData.length > 0 && branchData[0].id ? branchData[0].id : '3';

      return doc;
    } catch (err) {
      throw err;
    }

  }

  async validateInvoiceForInsert(doc: Payments): Promise<void> {
    try {

      const { data: customerData } = await this.hanaBusinessPartnesService.getById(doc.CardCode);
      if (customerData && customerData.length == 0) {
        throw {
          error: {
            code: 'BP005',
            message: `Business Partner '${doc.CardCode}' not exists.`,
            innerMessage: `Business Partner '${doc.CardCode}' not exists.`
          }
        }
      }
      for (const line of doc.PaymentInvoices) {

        const { data: itemData } = await this.hanaSaleInvoiceService.getInvoice(line.DocEntry);

        if (itemData && itemData.length == 0) {
          throw {
            error: {
              code: 'SI002',
              message: `Sale Invoice '${line.DocEntry}' not found.`,
              innerMessage: `Sale Invoice '${line.DocEntry}' not found.`
            }
          }
        }

      }

    } catch (err) {
      throw err;
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Baixa`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }

}

