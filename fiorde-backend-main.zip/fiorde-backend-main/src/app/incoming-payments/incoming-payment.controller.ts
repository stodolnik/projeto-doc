import { Controller, Post, Body, Headers, Patch } from '@nestjs/common'
import { IncomingPaymentsRequest } from './interfaces/controller';
import { IncomingPaymentsService } from './incoming-payment.service'
import { ApiImplicitHeader } from '@nestjs/swagger';

@Controller('incoming-payment')
export class IncomingPaymentsController {

  constructor(private readonly incomingPaymentsService: IncomingPaymentsService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: IncomingPaymentsRequest, @Headers('token') token) {
    try {
      return this.incomingPaymentsService.create(body);
    } catch (err) {
      throw err;
    }
  }
}
