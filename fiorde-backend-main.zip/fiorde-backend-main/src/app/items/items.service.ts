import { ItemModel } from './interfaces/service';
import { HanaItemsService } from './../../b1/hana/items/items.service';
import { Injectable, HttpException, HttpStatus, BadRequestException } from '@nestjs/common';
import { ItemsRequest } from './interfaces/controller';
import { Mapper } from './interfaces/service';
import * as _ from 'lodash';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { response } from '../../core/http/http.service';
import { ConfigService } from '../../config/config.service';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class ItemService {
  constructor(
    private readonly hanaItemsService: HanaItemsService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly configService: ConfigService,
    private readonly hanaLogService: HanaLogService
  ) { }

  private readonly defaultConfig = this.configService.companyConfig();

  async createOrUpdate(data: ItemsRequest) {
    try {
      let _response = [];
      let result = [];


      // try {
      const items = Mapper.FromList(data.items);

      for (const item of items) {

        // try {

        const { error: itemError, data: itemData } = await this.hanaItemsService.getById(item.ItemCode);

        if (item.ItemClass == 'itcMaterial') {

          const { error: ncmError, data: ncmCodeData } = await this.hanaItemsService.getNCM(item.NCMCode);

          if (!ncmError && ncmCodeData.length > 0) {
            item.NCMCode = ncmCodeData[0].AbsEntry;

          } else {
            result.push({
              error: {
                code: 'NC001',
                message: `NcmCode '${item.NCMCode}' not found.`,
                innerMessage: `NcmCode '${item.NCMCode}' not found.`,

              },
              id: item.ItemCode
            });
          }

        } else {
          item.InventoryItem = "tNO";
        }
        if (!itemError && itemData.length <= 0) {

          const endpoint = `${Endpoints.Items}`;
          const res = await this.serviceLayerService.post(endpoint, item, { credentials: this.defaultConfig, retries: 3 });

          let _res = await response(res);

          if (!_res.error && _res.data) {
            const log = this.objectmodelLog(_res.data.ItemCode || '', data, JSON.stringify(_res.data), 'Sucesso');
            await this.hanaLogService.insertLog(log);
            result.push({ error: null, id: _res.data.ItemCode });
          } else {
            result.push({ error: _res.error, id: item.ItemCode })
          }
        } else {
          result.push({
            error: null,
            id: item.ItemCode
          });
        }
        // } catch (err) {

        // }

      }

      // if (batchRequest.hasChanges()) {

      // const batchResult: HttpServiceResponse<HttpServiceResponse<ItemModel>[]> = await this.serviceLayerService.batch( batchRequest, { credentials: this.defaultConfig, retries: 3 });

      // if (!_response.error) {

      //_response.forEach(r => { result.push({ error: r.error, id: r.data ? `banana` : null }) });
      // } else {
      //   throw _response.error;
      // }
      // }

      if (result.find(r => r.error)) {
        for (let i = 0; i < result.length; i++) {
          if (!result[i].error) {
            result.splice(i, 1);
          }
        }
      }


      if (result.find(r => r.error))
        throw new HttpException(result, HttpStatus.UNPROCESSABLE_ENTITY);
      return result

      // return result;
      // } catch (err) {
      //   // throw new HttpException([{ ...err }], _.get(err, 'error').code == 401 ? HttpStatus.UNAUTHORIZED : HttpStatus.UNPROCESSABLE_ENTITY);
      // }
    } catch (err) {
      const log = this.objectmodelLog(err.id || '', data, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);
      throw err
    }
  }

  async deleteItem(id: string) {

    try {
      const { error: itemError, data: itemData } = await this.hanaItemsService.getById(id);

      if (!itemError && itemData.length > 0) {

        const endpoint = `${Endpoints.Items}('${id}')`;

        const res = await this.serviceLayerService.delete(endpoint, { credentials: this.defaultConfig, retries: 3 });

        let _response = await response(res);

        if (!_response.error) {

          return { error: null, id: id };
        } else {
          throw _response.error;
        }

      } else {
        throw {
          error: {
            code: 'ITM002',
            message: 'Item not found.',
            innerMessage: 'Item not found.'
          },
          id: id
        };
      }
    } catch (err) {
      throw new HttpException(err, HttpStatus.UNPROCESSABLE_ENTITY);
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Item`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }
}