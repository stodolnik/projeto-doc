import { ApiModelProperty } from "@nestjs/swagger";
import _ = require("lodash");

const FromList = (doc: Items[]): Partial<ItemModel>[] => {
  return doc.map(d => {
    let items: ItemModel = {
      ItemCode: d.code,
      ItemName: d.name,
      InventoryItem: d.inventoryItem ? 'tYES' : 'tNO',
      SalesItem: d.salesItem ? 'tYES' : 'tNO',
      PurchaseItem: d.purchaseItem ? 'tYES' : 'tNO',
      ItemClass: d.class,
      MaterialType: d.type,
      NCMCode: d.ncmCode,
      PurchaseUnit: d.buyUnitMeasure,
      SalesUnit: d.sellUnitMeasure,
      InventoryUOM: d.stockUnitMeasure,
      ProductSource: d.productSource,
      U_SKILL_CodCNAE: d.cnaeCode,
      U_SKILL_LisSer: d.listServices,
      U_SKILL_SerMun: d.countyServiceCode
    };

    let ommited = _.omitBy(items, _.isNil);
    return ommited;
  });
}

export const Mapper = {
  FromList
};

export class Items {

  @ApiModelProperty()
  public code: string;

  @ApiModelProperty()
  public name: string;

  @ApiModelProperty()
  public inventoryItem: boolean;

  @ApiModelProperty()
  public salesItem: boolean;

  @ApiModelProperty()
  public purchaseItem: boolean;

  @ApiModelProperty({
    enum: ['itcMaterial', 'itcService']
  })
  public class: string;
  
  @ApiModelProperty({
    enum: ['mt_FinishedGoods','mt_GoodsForReseller','mt_GoodsInProcess','mt_RawMaterial','mt_Package',
    'mt_SubProduct','mt_IntermediateMaterial','mt_ConsumerMaterial','mt_FixedAsset','mt_Service',
    'mt_OtherInput','mt_Other']
  })
  public type: string;

  @ApiModelProperty()
  public ncmCode: string;

  @ApiModelProperty()
  public productSource: string;

  @ApiModelProperty()
  public buyUnitMeasure: string;

  @ApiModelProperty()
  public sellUnitMeasure: string;

  @ApiModelProperty()
  public stockUnitMeasure: string;

  @ApiModelProperty()
  public listServices: string;

  @ApiModelProperty()
  public cnaeCode: string;

  @ApiModelProperty()
  public countyServiceCode: string;

}

export interface ItemModel {
  ItemCode?: string,
  ItemName?: string,
  InventoryItem?: string,
  SalesItem?: string,
  PurchaseItem?: string,
  ItemClass?: string,
  MaterialType?: string,
  NCMCode?: string,
  PurchaseUnit?: string,
  SalesUnit?: string,
  InventoryUOM?: string,
  ProductSource: string,
  U_SKILL_LisSer?: string,
  U_SKILL_CodCNAE?: string,
  U_SKILL_SerMun?: string
}
