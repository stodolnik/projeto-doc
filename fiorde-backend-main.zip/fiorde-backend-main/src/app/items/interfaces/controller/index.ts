import { Items } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class ItemsRequest {
  @ApiModelProperty({isArray: true, type: Items})
  readonly items: Items[];
}