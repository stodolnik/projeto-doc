import { HanaItemsModule } from './../../b1/hana/items/items.module';
import { Module } from '@nestjs/common';
import { ItemService } from './items.service';
import { itemsController } from './items.controller';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { ConfigModule } from '../../config/config.module';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';

@Module({
  imports: [ HanaItemsModule, ConfigModule, LogModuleHana],
  providers: [ItemService],
  controllers: [itemsController]
})

export class ItemsModule { }
