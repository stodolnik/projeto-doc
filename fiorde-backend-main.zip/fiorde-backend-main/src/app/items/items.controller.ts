import { Controller, Post, Body, Headers, Delete, Param, HttpException, Res, HttpStatus, HttpCode } from '@nestjs/common'
import { ItemService } from './items.service'
import { ItemsRequest } from './interfaces/controller';
import { ApiImplicitHeader, ApiImplicitHeaders, ApiImplicitParam } from '@nestjs/swagger';
import { Response } from 'express';

@Controller('items')
export class itemsController {

  constructor(private readonly itemsService: ItemService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async createOrUpdate(@Body() body: ItemsRequest, @Headers('token') token) {

    return this.itemsService.createOrUpdate(body);

  }

  @Delete('/:id')
  @ApiImplicitHeader({ name: 'token', required: true })
  @ApiImplicitParam({ name: 'id', required: true })
  async deleteItem(@Param('id') id, @Headers('token') token) {
    try {
      return this.itemsService.deleteItem(id);
    } catch (err) {
      return err;
    }
  }

}