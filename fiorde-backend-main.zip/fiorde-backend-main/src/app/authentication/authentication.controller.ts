// import { Controller, Post, Body } from '@nestjs/common'
// import { AuthenticationService } from './authentication.service'
// import { LoginRequest } from './interfaces/controller';

// @Controller('login')
// export class AuthenticationController {

//   constructor(private readonly authenticationService: AuthenticationService) { }

//   @Post()
//   async login(@Body() body: LoginRequest) {
//     try {
//       return await this.authenticationService.login(body.username, body.password);
//     } catch (err) {
//       throw err;
//     }
//   }
// }
