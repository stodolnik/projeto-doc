// export interface AuthenticationServiceResponse {
//   session: string;
//   timeout: number;
// }
