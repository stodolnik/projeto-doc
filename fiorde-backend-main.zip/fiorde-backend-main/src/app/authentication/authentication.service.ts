// import { Injectable } from '@nestjs/common';
// import { LoginService } from '../../b1/service-layer/login/login.service';
// import { UsersService } from '../../b1/service-layer/users/users.service';
// import { SalesPersonsService } from '../../b1/service-layer/sales-persons/sales-persons.service';
// import { EmployeesInfoService } from '../../b1/service-layer/employees-info/employees-info.service';
// import { HttpServiceResponse } from '../../b1/core/http/interfaces';
// import { AuthenticationServiceResponse } from './interfaces/service';

// @Injectable()
// export class AuthenticationService {
//   constructor(private readonly loginService: LoginService,
//     private readonly usersService: UsersService,
//     private readonly employeesInfoService: EmployeesInfoService,
//     private readonly salesPersonsService: SalesPersonsService) { }

//   async login(username: string, password: string): Promise<HttpServiceResponse<AuthenticationServiceResponse>> {
//     try {
//       let response: HttpServiceResponse<AuthenticationServiceResponse> = {
//         error: null
//       };

//       const loginResponse = await this.loginService.login({ username, password });
//       const { error: loginError, data: loginData } = loginResponse;

//       if (!loginError) {

//         response.data = {
//           session: loginData.SessionId,
//           timeout: loginData.SessionTimeout
//         };

//       } else {
//         response.error = {
//           code: 'L0001',
//           innerMessage: loginResponse.error.innerMessage,
//           message: 'Acesso não permitido.'
//         };
//       }

//       return response;
//     } catch (err) {
//       throw err;
//     }
//   }
// }
