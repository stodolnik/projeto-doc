// import { Module } from '@nestjs/common';
// import { AuthenticationService } from './authentication.service';
// import { AuthenticationController } from './authentication.controller';
// import { LoginModule } from '../../b1/service-layer/login/login.module';
// import { UsersModule } from '../../b1/service-layer/users/users.module';
// import { EmployeesInfoModule } from '../../b1/service-layer/employees-info/employees-info.module';
// import { SalesPersonsModule } from '../../b1/service-layer/sales-persons/sales-persons.module';

// @Module({
//   imports: [LoginModule, UsersModule, EmployeesInfoModule, SalesPersonsModule],
//   providers: [AuthenticationService],
//   controllers: [AuthenticationController]
// })
// export class AuthenticationModule { }
