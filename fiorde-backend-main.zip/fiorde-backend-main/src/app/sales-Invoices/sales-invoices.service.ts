import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { SalesInvoicesRequest } from './interfaces/controller/index';
import { ConfigService } from '../../config/config.service';
import { Mapper, Invoices, InvoicesModel } from './interfaces/service';
import { HanaBusinessPartnersService } from '../../b1/hana/business-partners/business-partners.service';
import { HanaModelService } from '../../b1/hana/model/model.service';
import { HanaBranchService } from '../../b1/hana/branch/branch.service';
import * as _ from 'lodash';
import { ServiceLayerService, Endpoints } from '@alfaerp/service-layer';
import { PartnerService } from '../partner/partner.service';
import { HanaProjectsService } from '../../b1/hana/projects/projects.service';
import { HanaItemsService } from '../../b1/hana/items/items.service';
import { response } from '../../core/http/http.service';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
var moment = require('moment');
import { v4 as uuidv4 } from 'uuid';
import { HanaSaleInvoiceService } from '../../b1/hana/sale-invoice/sale-invoice.service';
import { validateOrReject } from 'class-validator';
@Injectable()
export class InvoiceService {
  constructor(
    private readonly configService: ConfigService,
    private readonly hanaBusinessPartnesService: HanaBusinessPartnersService,
    private readonly partnerService: PartnerService,
    private readonly serviceLayerService: ServiceLayerService,
    private readonly hanaBranchService: HanaBranchService,
    private readonly hanaModelService: HanaModelService,
    private readonly hanaProjectsService: HanaProjectsService,
    private readonly hanaItemsService: HanaItemsService,
    private readonly hanaLogService: HanaLogService,
    //private readonly hanaSaleInvoiceService: HanaSaleInvoiceService
  ) { }

  private readonly defaultConfig = this.configService.companyConfig();

  async create(data: SalesInvoicesRequest) {
    try {
      let result = [];
      const invoices = Mapper.FromList(data.sales);
      for (const invoice of invoices) {
        
        try {
          await this.validateInvoiceForInsert(invoice.invoicesModel);

          const document = await this.resolveInvoice(invoice);

          const endpoint = `${Endpoints.Invoices}`;
          document.U_FiordeIntegratedId = "2ad3c442-6b93-494c-a570-be4fc02932da";

          console.log(document);
          const res = await this.serviceLayerService.post(endpoint, document, { credentials: this.defaultConfig, retries: 3 });
          
          const _response = await response(res);

          //const { error: invoicesError, data: invoicesData } = await this.invoicesService.session(token).create(document);

          if (!_response.error && _response.data) {

            const log = this.objectmodelLog(_response.data.DocEntry || '', data, JSON.stringify(_response.data), 'Sucesso');
            await this.hanaLogService.insertLog(log);
            result.push({ error: null, id: _response.data.DocNum, RPS: _response.data.SequenceSerial });

          } else {

            throw {
              error: {
                code: 'SI001',
                message: _response.error.innerMessage,
                innerMessage: _response.error.innerMessage
              },
              id: invoice.invoicesModel.NumAtCard
            }

          }
        }
        catch (err) {
          console.log(err)
          throw new HttpException([{ ...err }], _.get(err, 'error').code == 401 ? HttpStatus.UNAUTHORIZED : HttpStatus.UNPROCESSABLE_ENTITY);
        }
      }

      return result;
    } catch (err) {
      const log = this.objectmodelLog(err.id || '', data, JSON.stringify(err), 'Erro');
      await this.hanaLogService.insertLog(log);

      throw err;
    }


  }

  async resolveInvoice(doc: Invoices): Promise<InvoicesModel> {
    try {
      const { data: customerData } = await this.hanaBusinessPartnesService.getById(doc.invoicesModel.CardCode.trim());
      if (customerData && customerData.length == 0) {
        if (!doc.partners.cnpj){
          throw {
            error: {
              code: 'SI0001',
              message: `Sale-Invoice - CNPJ valor: ${doc.partners.cnpj} está com formato inválido.`,
              innerMessage: `CNPJ valor: ${doc.partners.cnpj} está com formato inválido.`
            },
            id: doc.invoicesModel.NumAtCard
          }
        }
        const { data: partnerCode } = await this.hanaBusinessPartnesService.getByCnpjOfCustomer(doc.partners.cnpj.replace(/[^\d]+/g, ''));
        if (!partnerCode || partnerCode.length == 0) {
          throw {
            error: {
              code: 'SI0001',
              message: `Sale-Invoice CNPJ ${doc.partners.cnpj} não encontrado.`,
              innerMessage: `CNPJ ${doc.partners.cnpj} não encontrado.`
            },
            id: doc.invoicesModel.NumAtCard
          }
        }

        if (partnerCode.length > 1) {
          throw {
            error: {
              code: 'SI0002',
              message: `Sale-Invoice CNPJ ${doc.partners.cnpj} double.`,
              innerMessage: `CNPJ ${doc.partners.cnpj} double.`
            },
            id: doc.invoicesModel.NumAtCard
          }
        }

        doc.invoicesModel.CardCode = partnerCode[0].CardCode;
        //await this.partnerService.create(doc.partners);

      }

      const { data: branchData, error: err } = await this.hanaBranchService.getByCnpj(doc.invoicesModel.BPL_IDAssignedToInvoice);
      const { data: modelData } = await this.hanaModelService.getModelId(doc.invoicesModel.SequenceModel);


      doc.invoicesModel.BPL_IDAssignedToInvoice = branchData.length > 0 && branchData[0].id ? branchData[0].id : '3';
      doc.invoicesModel.SequenceModel = _.first(modelData).AbsEntry;


      // const { data: tribType } = await this.hanaBranchService.getTrib(doc.invoicesModel.BPL_IDAssignedToInvoice);
      // if (tribType && tribType.length > 0)
      //   doc.invoicesModel.U_SKILL_TipTrib = tribType[0].U_TipoTrib

      // for (const line of doc.invoicesModel.DocumentLines) {

      //   // const { data: itemData, error: err } = await this.hanaItemsService.getByFiordeId(line.ItemCode);
      //   // console.log(itemData, err)
      //   // line.ItemCode = itemData.id;

      //   line.WarehouseCode == '' || !line.WarehouseCode ? delete (line.WarehouseCode) : line.WarehouseCode
      // }

      return doc.invoicesModel;
    } catch (err) {
      throw err;
    }

  }

  async validateInvoiceForInsert(doc: InvoicesModel): Promise<void> {
    try {

      // validate len of U_SKILL_TipTrib

      if (doc.U_SKILL_TipTrib) {
        if (doc.U_SKILL_TipTrib.length <= 0 || doc.U_SKILL_TipTrib.length > 2) {
          throw {
            error: {
              code: 'TB001',
              message: 'Tipo Tributação invalid',
              innerMessage: 'Tipo Tributação format invalid'
            },
            id: doc.NumAtCard
          }
        }
      }

      //validates if the project exists
      if (!_.isEmpty(_.get(doc, 'Project'))) {

        const { data: projectData } = await this.hanaProjectsService.getById(doc.Project);

        if (projectData && projectData.length == 0) {
          throw {
            error: {
              code: 'PRJC001',
              message: 'Project not exists.',
              innerMessage: 'Project not exists.'
            },
            id: doc.NumAtCard
          }
        }
      }

      

      //validates if the items exists
      for (const line of doc.DocumentLines) {

        const { data: itemData } = await this.hanaItemsService.getById(line.ItemCode);

        if (itemData && itemData.length == 0) {
          throw {
            error: {
              code: 'ITM002',
              message: 'Item not found.',
              innerMessage: 'Item not found.'
            },
            id: doc.NumAtCard
          }
        }

      }

      //validates maximum length
      if (doc.Comments && doc.Comments.length > 250) {
        throw {
          error: {
            code: 'STO001',
            message: 'Comments - Maximum length of 250 characters.',
            innerMessage: 'Comments - Maximum length of 250 characters.'
          },
          id: doc.NumAtCard
        }
      }
      
      // NÃO ESTÁ USANDO, MAS DEIXA ISSO AQUI
      /*
      function verificaItem(linhas: any): boolean {
        let validacao = false;
        
        linhas.forEach(item => {
          if (item.ItemCode == modelData[0].U_ALFA_ITEM) {
            validacao = true;
          }
        });

        return validacao;
      }*/


      if (doc.SequenceModel.toLowerCase() != 'nada') {
        //validates if the model exists
        const { data: modelData } = await this.hanaModelService.getModelId(doc.SequenceModel);

        if (modelData && modelData.length == 0) {
          throw {
            error: {
              code: 'SI005',
              message: 'Model not exists.',
              innerMessage: 'Model not exists.'
            },
            id: doc.NumAtCard
          }
        }
      } else {
        const { data: modelData } = await this.hanaModelService.getNextNumSerial();

        doc.SequenceCode = modelData[0].U_ALFA_SEQ;
        doc.SequenceModel = modelData[0].U_ALFA_MODEL;

        if (modelData && modelData.length == 0) {
          throw {
            error: {
              code: 'SI005',
              message: 'Model not exists.',
              innerMessage: 'Model not exists.'
            },
            id: doc.NumAtCard
          }
        }
      

      }
    } catch (err) {
      throw err;
    }
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Nota-Saida`,
      U_HORADOC: moment().format('HHmm'),
    }
    return objectLog;
  }
}

