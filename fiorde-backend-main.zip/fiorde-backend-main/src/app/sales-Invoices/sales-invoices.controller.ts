import { Controller, Post, Body, Headers, Patch } from '@nestjs/common'
import { SalesInvoicesRequest } from './interfaces/controller';
import { InvoiceService } from './sales-invoices.service'
import { ApiImplicitHeader } from '@nestjs/swagger';

@Controller('sales-invoices')
export class SalesInvoicesController {

  constructor(private readonly salesInvoicesService: InvoiceService) { }

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: SalesInvoicesRequest, @Headers('token') token) {
    try {
      return this.salesInvoicesService.create(body);
    } catch (err) {
      throw err;
    }
  }
}
