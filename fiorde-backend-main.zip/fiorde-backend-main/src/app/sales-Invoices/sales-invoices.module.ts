import { Module } from '@nestjs/common';
import { InvoiceService } from './sales-invoices.service';
import { SalesInvoicesController } from './sales-invoices.controller';
import { HanaBusinessPartnersModule } from '../../b1/hana/business-partners/business-partners.module';
import { ConfigModule } from '../../config/config.module';
import { PartnerModule } from '../partner/partner.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import { HanaBranchModule } from '../../b1/hana/branch/branch.module';
import { ModelModule } from '../../b1/hana/model/model.module';
import { HanaProjectsModule } from '../../b1/hana/projects/projects.module';
import { HanaItemsModule } from '../../b1/hana/items/items.module';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';
import { HanaSaleInvoiceService } from '../../b1/hana/sale-invoice/sale-invoice.service';

@Module({
  imports: [ ConfigModule, HanaBusinessPartnersModule, PartnerModule, ModelModule, LogModuleHana, HanaProjectsModule, HanaItemsModule, HanaBranchModule],
  providers: [InvoiceService],
  controllers: [SalesInvoicesController]
})

export class SalesInvoicesModule { }
