import { Partner, PartnerAddress } from '../../../partner/interfaces/service/index';
import _ = require("lodash");
import { ApiModelProperty } from "@nestjs/swagger";

const FromList = (doc: SalesInvoices[]): Invoices[] => {
  let line = 0;
  return doc.map(d => {
    let invoices: InvoicesModel = {
      CardCode: d.partnerCode,
      DocDate: d.documentDate,
      DocDueDate: d.dueDate,
      TaxDate: d.taxDate,
      Project: d.project,
      SequenceCode: d.seqcode ? null : null ,
      SequenceModel: d.model,
      Comments: d.comments,
      U_SKILL_FormaPagto: d.paymentMethod || '99',
      PaymentGroupCode: "-1",
      OpeningRemarks: d.openingRemarks,
      ClosingRemarks: d.closingRemarks,
      DocCurrency: "R$",
      NumAtCard: d.partnerDocumentNumber,
      BPL_IDAssignedToInvoice: d.branch,
      U_SKILL_TipTrib: d.tipoTributacao,
      U_IntegratedStatus: "N",
      DocumentLines: d.items.map(i => {
        const item: DocumentLines = {
          LineNum: line++,
          ItemCode: i.itemCode,
          Quantity: i.quantity,
          UnitPrice: i.unitPrice,
          Usage: 101,
          //TaxCode: '1933-006',
          WarehouseCode: i.warehouse,
          ProjectCode: d.project
        }
        return item;
      })
      // TaxExtension: {
      //   Incoterms: d.taxExtensions.incoterms,
      //   Vehicle: d.taxExtensions.vehicle,
      //   PackQuantity: d.taxExtensions.packQuantity,
      //   PackDescription: d.taxExtensions.packDescription,
      //   NetWeight: d.taxExtensions.netWeight,
      //   GrossWeight: d.taxExtensions.grossWeight
      // }
    };

    let partners: Partner = {
      code: d.partnerCode,
      name: d.partner.name,
      type: 'cCustomer',
      cnpj: d.partner.cnpj,
      address: (d.partner.address || []).map((a, i) => {
        const address: PartnerAddress = {
          street: a.street,
          number: a.number,
          block: a.block,
          city: a.city,
          building: a.building,
          zipCode: a.zipCode,
          state: a.state,
          county: a.county,
          country: a.country
        }
        return address;
      })
    };

    return { invoicesModel: invoices, partners }

  });
}

export const Mapper = {
  FromList
};


export class TaxExtensions {

  @ApiModelProperty()
  public incoterms: number;

  public taxId0: string;

  @ApiModelProperty()
  public vehicle?: string;

  @ApiModelProperty()
  public packQuantity?: string;

  @ApiModelProperty()
  public packDescription?: string;

  @ApiModelProperty()
  public netWeight?: number;

  @ApiModelProperty()
  public grossWeight?: number

  public TaxId1: string;

  public TaxId4: string;
}

export class InvoiceDocumentItem {

  public id: number;

  @ApiModelProperty()
  public itemCode: string;

  public itemName: string;

  @ApiModelProperty()
  public quantity: number;

  @ApiModelProperty()
  public unitPrice: number;

  @ApiModelProperty()
  public warehouse?: string;

  public usage: number;

  public taxCode: string;

}

export class PartnerAddresses {

  @ApiModelProperty()
  street: string;

  @ApiModelProperty()
  number: string;

  @ApiModelProperty()
  block: string;

  @ApiModelProperty()
  city: string;

  @ApiModelProperty()
  building: string;

  @ApiModelProperty()
  zipCode: string;

  @ApiModelProperty()
  state: string;

  @ApiModelProperty()
  county: string;

  @ApiModelProperty()
  country: string;
}

export class Partners {

  public code: string;

  @ApiModelProperty()
  public name: string;

  public type: string;

  public cnpj?: string;

  @ApiModelProperty({ isArray: true, type: PartnerAddresses })
  public address: PartnerAddresses[];
}

// export class AdditionalExpenses {

//   @ApiModelProperty()
//   public expenseCode?: number;

//   @ApiModelProperty()
//   public remarks?: string;

//   @ApiModelProperty()
//   public taxCode?: string;

//   @ApiModelProperty()
//   public distributionMethod?: string;

//   @ApiModelProperty()
//   public irf?: string;

//   @ApiModelProperty()
//   public lineTotal?: number;

//   public project?: string;
// }

export class SalesInvoices {

  public id: number;

  public documentNumber: string;

  @ApiModelProperty()
  public project: string;

  @ApiModelProperty()
  public partnerCode: string;

  @ApiModelProperty()
  public documentDate: Date;

  @ApiModelProperty()
  public branch: string;

  @ApiModelProperty()
  public dueDate: Date;

  @ApiModelProperty()
  public taxDate: Date;

  @ApiModelProperty()
  public comments: string;

  public discountPercent: number;

  public status: string;

  @ApiModelProperty()
  public model: string;

  @ApiModelProperty()
  public seqcode: number;

  public paymentMethod: string;

  @ApiModelProperty()
  public openingRemarks: string;

  @ApiModelProperty()
  public closingRemarks: string;

  public currency: string;

  @ApiModelProperty()
  public tipoTributacao: string;

  @ApiModelProperty()
  public partnerDocumentNumber: string;

  public freightType: number;

  public payment: number;

  @ApiModelProperty({ isArray: true, type: InvoiceDocumentItem })
  public items: InvoiceDocumentItem[];

  @ApiModelProperty()
  public taxExtensions: TaxExtensions;

  @ApiModelProperty()
  public partner: Partners;

  // @ApiModelProperty({ isArray: true, type: AdditionalExpenses })
  // public additionalExpenses: AdditionalExpenses[];

}

export interface Invoices {
  invoicesModel: InvoicesModel,
  partners?: Partner
}

export interface InvoicesModel {
  DocEntry?: number,
  DocNum?: string,
  DocDate?: Date,
  DocDueDate?: Date,
  TaxDate?: Date,
  CardCode?: string,
  CardName?: string,
  DocTotal?: number,
  SalesPersonCode?: number
  DocumentStatus?: string,
  SequenceCode: number,
  SequenceModel?: string,
  Confirmed?: string,
  NumAtCard?: string,
  gmaBankInfo?: string,
  ShipToCode?: string,
  DocCurrency?: string,
  DocRate?: number,
  DiscountPercent?: number,
  TotalDiscount?: number,
  PaymentGroupCode?: string,
  TransportationCode?: string,
  Comments?: string,
  BPL_IDAssignedToInvoice?: string,
  U_SKILL_FormaPagto: string,
  U_SKILL_TipTrib?: string,
  U_IntegratedStatus?: string,
  U_FiordeIntegratedId?: string,
  Project?: string,
  //BPLName?: string,
  Carrier?: string,
  OpeningRemarks?: string,
  ClosingRemarks?: string,
  U_EmailEnvDanfe?: string,
  DocumentLines?: DocumentLines[],
  TaxExtension?: TaxExtension
  DocumentAdditionalExpenses?: DocumentAdditionalExpenses[]
}

export interface DocumentLines {
  LineNum?: number,
  ItemCode?: string,
  Quantity?: number,
  Price?: number,
  DiscountPercent?: number,
  LineTotal?: number,
  UnitPrice?: number,
  Usage?: number,
  TaxCode?: string,
  WarehouseCode?: string,
  ProjectCode?: string
}

export interface TaxExtension {
  Incoterms?: number,
  Vehicle?: string,
  PackQuantity?: string,
  PackDescription?: string,
  NetWeight?: number,
  GrossWeight?: number
}

export interface DocumentAdditionalExpenses {
  ExpenseCode?: number,
  Remarks?: string,
  TaxCode?: string,
  DistributionMethod?: string,
  WTLiable?: string,
  LineTotal?: number,
  Project?: string
}
