import { SalesInvoices } from '../service';
import { ApiModelProperty } from '@nestjs/swagger';

export class SalesInvoicesRequest {
  @ApiModelProperty({isArray: true, type: SalesInvoices})
  readonly sales: SalesInvoices[];
}