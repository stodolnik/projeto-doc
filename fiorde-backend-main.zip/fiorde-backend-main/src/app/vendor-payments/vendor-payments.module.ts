import { Module } from '@nestjs/common';
import { ConfigModule } from '../../config/config.module';
import { LogModule as LogModuleHana } from '../../b1/hana/log/log.module';
import { VendorPaymentsService } from './vendor-payments.service';
import { VendorPaymentsController } from './vendor-payments.controller';
import { HanaPurchaseInvoiceModule } from '../../b1/hana/purchase-invoice/purchase-invoice.module';

@Module({
  imports: [ConfigModule, LogModuleHana, HanaPurchaseInvoiceModule],
  providers: [VendorPaymentsService],
  controllers: [VendorPaymentsController],
})
export class VendorPaymentsModule {}
