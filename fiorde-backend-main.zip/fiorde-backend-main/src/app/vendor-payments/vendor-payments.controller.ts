import { Body, Controller, Post, Headers } from '@nestjs/common';
import { ApiImplicitHeader } from '@nestjs/swagger';
import { VendorPaymentsService } from './vendor-payments.service';
import { VendorPaymentsRequest } from './interfaces/controller';

@Controller('vendor-payment')
export class VendorPaymentsController {
  constructor(private readonly vendorPaymentsService: VendorPaymentsService) {}

  @Post()
  @ApiImplicitHeader({ name: 'token', required: true })
  async create(@Body() body: VendorPaymentsRequest, @Headers('token') token) {
    try {
      return this.vendorPaymentsService.create(body);
    } catch (err) {
      throw err;
    }
  }
}
