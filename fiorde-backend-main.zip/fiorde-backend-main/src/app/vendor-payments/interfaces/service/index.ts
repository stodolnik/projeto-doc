import { ApiModelProperty } from '@nestjs/swagger';

export class VendorPayment {
  @ApiModelProperty()
  docInvoice: string;
  
  @ApiModelProperty()
  account: string;

  @ApiModelProperty()
  paymentDate: string;

  @ApiModelProperty()
  paymentType: string;

  @ApiModelProperty()
  value: number;
}
