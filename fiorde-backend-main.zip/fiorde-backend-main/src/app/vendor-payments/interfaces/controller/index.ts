import { ApiModelProperty } from '@nestjs/swagger';
import { VendorPayment } from '../service';

export class VendorPaymentsRequest {
  @ApiModelProperty({ isArray: true, type: VendorPayment })
  readonly payment: VendorPayment[];
}
