import { Endpoints, ServiceLayerService } from '@alfaerp/service-layer';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { HanaLogService } from '../../b1/hana/log/log.service';
import { ConfigService } from '../../config/config.service';
import { VendorPaymentsRequest } from './interfaces/controller';
import { ModelLog } from '../../b1/hana/log/interfaces/index';
import { v4 as uuidv4 } from 'uuid';
import _ = require('lodash');
import { HanaPurchaseInvoiceService } from '../../b1/hana/purchase-invoice/purchase-invoice.service';
import { response } from '../../core/http/http.service';
var moment = require('moment');

@Injectable()
export class VendorPaymentsService {
  constructor(
    private readonly configService: ConfigService,
    private readonly hanaPurchaseInvoiceService: HanaPurchaseInvoiceService,
    private readonly hanaLogService: HanaLogService,
    private readonly serviceLayerService: ServiceLayerService,
  ) { }

  private readonly defaultConfig = this.configService.companyConfig();

  async create(data: VendorPaymentsRequest) {
    try {
      let result = [];
      let document = [];

      let validado = await this.validateRequest(data);

      for (const payment of validado) {
        const endpoint = `${Endpoints.VendorPayments}`;
        const res = await this.serviceLayerService.post(endpoint, payment, { credentials: this.defaultConfig, retries: 3 });
        const _response = await response(res);
        if (!_response.error && _response.data) {
          const dados = await this.hanaPurchaseInvoiceService.getNumberLcmByPayment(res.data['DocEntry'])
          // result.push({ error: null, id: res.data['DocEntry'] });
          if (dados.error) {
            throw {
              error: {
                code: 'SI001',
                message: 'Error - Get number LCM',
                innerMessage: 'Error - Get number LCM'
              }
            }
          }

          const log = this.objectmodelLog(dados.data[0].Number || '', data, JSON.stringify(_response.data), 'Sucesso');
          await this.hanaLogService.insertLog(log);
          result.push({ error: null, id: dados.data[0].Number });

        } else {

          throw {
            error: {
              code: 'SI001',
              message: _response.error.innerMessage,
              innerMessage: _response.error.innerMessage
            }
          }
        }
      }

      return result;

    } catch (err) {
      const log = this.objectmodelLog(
        err.id || '',
        data,
        JSON.stringify(err),
        'Erro',
      );
      await this.hanaLogService.insertLog(log);
      throw new HttpException(
        [{ ...err }],
        _.get(err, 'error').code == 401
          ? HttpStatus.UNAUTHORIZED
          : HttpStatus.UNPROCESSABLE_ENTITY,
      );
    }
  }

  async validateRequest(data: VendorPaymentsRequest): Promise<any> {
    var document = [];
    for (const payment of data.payment) {
      if (!payment['docInvoice']) {
        throw {
          error: {
            code: 'SI0001',
            message: `docInvoice invalid.`,
            innerMessage: `docInvoice invalid.`,
          },
          id: payment['docInvoice'],
        };
      }

      if (!payment['value']) {
        throw {
          error: {
            code: 'SI0001',
            message: `value invalid.`,
            innerMessage: `value invalid.`,
          },
          id: payment['value'],
        };
      }

      const dados = await this.hanaPurchaseInvoiceService.getInvoiceForPayment(
        payment['docInvoice'],
      );
      if (dados.data.length === 0) {
        throw {
          error: {
            code: 'SI0001',
            message: `docInvoice ${payment['docInvoice']} not found.`,
            innerMessage: `docInvoice ${payment['docInvoice']} not found.`,
          },
          id: payment['docInvoice'],
        };
      }

      const verifyPayment = await this.hanaPurchaseInvoiceService.verifyExistPaymentOfInvoice(
        dados.data[0].DocEntry,
      );
      if (verifyPayment.data.length > 0 && payment['paymentType'].toUpperCase() != "CARTAOC") {
        throw {
          error: {
            code: 'SI0001',
            message: `Exist an payment for ${payment['docInvoice']}.`,
            innerMessage: `Exist an payment for ${payment['docInvoice']}.`,
          },
          id: payment['docInvoice'],
        };
      }

      if (payment['account'] || payment['account'] != '') {
        const verifyAccount = await this.hanaPurchaseInvoiceService.verifyExistAccount(
          payment['account'],
        );
        if (verifyAccount.data.length === 0) {
          throw {
            error: {
              code: 'SI0001',
              message: `Account ${payment['account']} not found.`,
              innerMessage: `Account ${payment['account']} not found.`,
            },
            id: payment['account'],
          };
        }
      }
      
      const paymentDate = payment['paymentDate'];

      if (!paymentDate || paymentDate == '') {
        throw {
          error: {
            code: 'SI0001',
            message: `Payment Date not found. Value ${paymentDate}`,
            innerMessage: `Payment Date not found. Value ${paymentDate}`,
          },
          id: payment['docInvoice'],
        };
      }

      const creditCard = await this.hanaPurchaseInvoiceService.getCreditCard(payment['account']);
      const dadosAccountingInvoice = await this.hanaPurchaseInvoiceService.getInfoAccounting(parseInt(payment['docInvoice']));

      if (payment['paymentType'].toUpperCase().trim() == "TRANSFERENCIAB") {
        const doc = {
          CardCode: dados.data[0].CardCode,
          DocDate: paymentDate,
          DueDate: paymentDate,
          TaxDate: paymentDate,
          BPLID: parseInt(dados.data[0].BPLId),
          TransferAccount: payment['account'],
          TransferDate: paymentDate,
          TransferSum: payment['value'],
          ProjectCode: dados.data[0].Project,
          CashSum: 0.0,
          PaymentInvoices: [
            {
              DocEntry: parseInt(dados.data[0].DocEntry),
              InvoiceType: 'it_PurchaseInvoice',
              InstallmentId: dadosAccountingInvoice.data[0].InstlmntID,
            },
          ],
        };
        document.push(doc);

      } else if (payment['paymentType'].toUpperCase().trim() == "DINHEIRO") {
        const doc = {
          CardCode: dados.data[0].CardCode,
          DocDate: paymentDate,
          DueDate: paymentDate,
          TaxDate: paymentDate,
          BPLID: parseInt(dados.data[0].BPLId),
          ProjectCode: dados.data[0].Project,
          CashAccount: payment['account'],
          CashSum: payment['value'],
          PaymentInvoices: [
            {
              DocEntry: parseInt(dados.data[0].DocEntry),
              InvoiceType: 'it_PurchaseInvoice',
              InstallmentId: dadosAccountingInvoice.data[0].InstlmntID,
            },
          ],
        };
        document.push(doc);
      } else if (payment['paymentType'].toUpperCase().trim() == "CARTAOC") {
        const doc = {
          CardCode: dados.data[0].CardCode,
          DocDate: paymentDate,
          DueDate: paymentDate,
          TaxDate: paymentDate,
          BPLID: parseInt(dados.data[0].BPLId),
          ProjectCode: dados.data[0].Project,
          PaymentInvoices: [
            {
              DocEntry: parseInt(dados.data[0].DocEntry),
              InvoiceType: 'it_PurchaseInvoice',
              InstallmentId: dadosAccountingInvoice.data[0].InstlmntID,
            },
          ],
          PaymentCreditCards: [
            {
              CreditCard: creditCard.data[0].CreditCard,
              CreditAcct: payment['account'],
              CreditSum: payment['value']
            }
          ]
        };
        document.push(doc);


      }
    }

    return document;
  }

  objectmodelLog(documentId: string, document: any, response: string, status: string,
  ) {
    const objectLog: ModelLog = {
      Code: uuidv4(),
      U_DATEDOC: moment().format('YYYY-MM-DDTHH:mm:ss'),
      U_IDDOC: documentId,
      U_STATUS: status,
      U_OBJETOREQUEST: JSON.stringify(document).replace(/\\/g, ''),
      U_OBJETORESPONSE: JSON.stringify(response).replace(/\\/g, ''),
      U_PARAMETROS: '',
      U_TYPE: `Recebimento-Baixa`,
      U_HORADOC: moment().format('HHmm'),
    };
    return objectLog;
  }
}
