import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ApplicationModule } from './app.module';
import { AuthorizationGuard } from './core/authorization/index';
import * as helmet from 'helmet';
import * as rateLimit from 'express-rate-limit';
import * as compression from 'compression';
import * as cookieSession from 'cookie-session';
import * as bodyParser from 'body-parser';
import * as timeout from 'connect-timeout';
import {ConfigService} from './config/config.service'

const config = new ConfigService(`./environment/${process.env.NODE_ENV || 'staging'}.json`);

declare const module: any;
const secret: string = "8cfc62be134cf9cba6d643db3855db35e44735d0a8c4a3d144140df04862a759";

async function bootstrap() {
	const app = await NestFactory.create(ApplicationModule);
	app.use(timeout('5m'));
	app.use(bodyParser.json({ limit: '50mb' }));
  	app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
  	app.useGlobalGuards(new AuthorizationGuard);

	const options = new DocumentBuilder()
		.setTitle(`Integração Fiorde - ${config._get('ENVIRONMENT')}`)
		.setDescription('API de integração da Fiorde desenvolvida pela ALFA.')
		.setVersion('1.0')
		.build();

	const document = SwaggerModule.createDocument(app, options);
	SwaggerModule.setup('api', app, document);

	await app.listen(config._get('API_PORT'));

	if (module.hot) {
		module.hot.accept();
		module.hot.dispose(() => app.close());
	}

}

bootstrap();