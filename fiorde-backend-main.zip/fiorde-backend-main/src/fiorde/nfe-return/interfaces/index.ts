export interface NFeReturn {
  documentNumber: string,
  invoice: string,
  serialNumber: string,
  emissionDate: string,
  value?: number,
  status: string,
  keyNumber: string,
  taxValues?:any[]
}




