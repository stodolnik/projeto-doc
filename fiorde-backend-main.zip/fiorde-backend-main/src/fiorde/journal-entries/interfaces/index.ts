export interface JournalEntrieReturn {
  id: string
}




