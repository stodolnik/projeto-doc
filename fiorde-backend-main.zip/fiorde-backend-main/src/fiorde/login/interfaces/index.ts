export interface Token {

  'token_type': string,
  'access_token': string

}



