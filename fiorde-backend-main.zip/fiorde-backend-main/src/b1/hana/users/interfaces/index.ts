import { EmployeeModel } from "../../employees/interfaces";
import { Table } from "../../../../common/database/interfaces";

export const UserModel: Table = {
  
  name: 'OUSR',
  alias: 'T0',
  columns: [
    {name: 'INTERNAL_K'},
    {name: 'USER_CODE'},
    {name: 'U_NAME'},
    {name: 'Branch'}
  ],
  relationships: [
    { 
      model: EmployeeModel, 
      alias: 'T1',
      type: 'LEFT',
      connectors: [ {  from: { name: 'GroupCode'}, to: { name: 'GroupCode'}, operator: '=' } ]
    }
  ]
}

export interface User {
  INTERNAL_K: string,
  USER_CODE: string,
  U_NAME: string,
  Branch: string
}