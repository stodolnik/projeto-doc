import { Module } from '@nestjs/common';
import { HanaSaleInvoiceService } from './sale-invoice.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaSaleInvoiceService],
  exports: [HanaSaleInvoiceService]
})

export class HanaSaleInvoiceModule {}
