import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import { SaleInvoice } from './interfaces';
import * as dayjs from 'dayjs';
import { Console } from 'console';

@Injectable()
export class HanaSaleInvoiceService extends DatabaseService<any> {

  getInvoice(documentId: number): Promise<DatabaseResponse<SaleInvoice[]>> {

    let query = `SELECT "DocEntry"
               
                 FROM ${this.databaseName}."OINV" 
                 
                 WHERE "DocEntry" = '${documentId}'`;

    return this.exec(query);
  }

  verifyExistPaymentOfInvoice(docEntry: string) : Promise<DatabaseResponse<any[]>>{
    let query = `
                  SELECT 
	                    RCT2."DocNum" 
                  FROM
                  ${this.databaseName}.RCT2 , ${this.databaseName}.ORCT
                  WHERE
	                    RCT2."DocNum" = ORCT."DocEntry" AND 
	                    RCT2."DocEntry" = '${docEntry}' AND
	                    ORCT."Canceled" = 'N'`;
          return this.exec(query);
  }

  verifyExistAccount(account: string) : Promise<DatabaseResponse<any[]>>{
    let query = `SELECT 
                    "AcctCode"
                 FROM 
                 ${this.databaseName}.OACT
                 WHERE
                    "AcctCode" = '${account}'`;
            return this.exec(query);
  }

  

  getInvoiceForPayment(docNum) {
    try {
        let query = `
  SELECT 
          OINV."DocEntry" ,
          OINV."CardCode",
          OINV."BPLId" , 
          (OINV."DocTotal" - IFNULL(Sum(INV5."WTAmnt"), 0)) "DocTotal",
          OINV."Project"
  FROM 
          ${this.databaseName}."OINV"
  LEFT JOIN
          ${this.databaseName}.INV5 
  ON 
          INV5."AbsEntry"  = OINV."DocEntry"
          AND INV5."Category" = 'P'  
  WHERE 
          OINV."DocNum" = '${docNum}'
  GROUP BY
          OINV."DocEntry" ,
          OINV."CardCode",
          OINV."BPLId" , 
          OINV."DocTotal",
          OINV."Project"`;
        return this.exec(query);
    }
    catch (err) {
        return null;
    }
}


  getNumberLcmByPayment(docEntry: string): Promise<DatabaseResponse<any[]>>{
    try{
      let query = `	
      SELECT 
            OJDT."Number" ,
            ORCT."DocEntry" ,
            OJDT."U_FiordeIntegration",
            ORCT."JrnlMemo"
      FROM
            ${this.databaseName}.OJDT ,
            ${this.databaseName}.ORCT
      WHERE 
            OJDT."TransId" = ORCT."TransId"
            AND ORCT."DocEntry" = '${docEntry}'`;
            
        return this.exec(query);

    }catch(err){
      return null;
    }
  }

  

  getTax(documentId: string): Promise<DatabaseResponse<any[]>> {

    let query = ` SELECT 
                      T1."WTType" AS "name"
                      , Tax."Rate" as "percent"
                    , Sum(TAX."WTAmnt") AS "value"
                  FROM 
                    ${this.databaseName}.OINV DOCUMENT 
                  INNER JOIN 
                    ${this.databaseName}.INV5 TAX 
                  ON 
                    DOCUMENT."DocEntry" = TAX."AbsEntry" 
                  INNER JOIN 
                    ${this.databaseName}.OWHT TAX_NAME 
                  ON 
                    TAX."WTCode" = TAX_NAME."WTCode"
                  INNER JOIN
                  ${this.databaseName}.OWTT T1 
                  ON TAX_NAME."WTTypeId" = T1."WTTypeId"
                  WHERE 
                    "DocEntry" = '${documentId}'
                  GROUP BY 
                    DOCUMENT."DocNum",
                    T1."WTType",
                    Tax."Rate"
                `;
    return this.exec(query);
  }

}
