import { Document } from '../../../../common/interfaces/index';

export interface SaleInvoice extends Document {

}



