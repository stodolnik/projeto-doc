import { CardGroupModel } from "../../card-groups/interfaces";
import { PaymentTermModel } from "../../payment-terms/interfaces";
import { PriceListModel } from "../../price-lists/interfaces";
import { CurrencyModel } from "../../currency/interfaces";
import { Table } from "../../../../common/database/interfaces";

export const BusinessPartnerModel: Table = {

  name: 'OCRD',
  alias: 'T0',
  columns: [
    { name: 'CardCode' },
    { name: 'CardName' },
    { name: 'CardType' },
    { name: 'frozenFor' },
    { name: 'CreditLine' },
    { name: 'Phone1' },
    { name: 'Phone2' },
    { name: 'E_Mail' },
    { name: 'Territory' },
    { name: 'ShipToDef' },
    { name: 'MainUsage' }
  ],
  relationships: [
    {
      model: CardGroupModel,
      alias: 'T1',
      type: 'LEFT',
      connectors: [{ from: { name: 'GroupCode' }, to: { name: 'GroupCode' }, operator: '=' }]
    },
    {
      model: PaymentTermModel,
      alias: 'T2',
      type: 'LEFT',
      connectors: [{ from: { name: 'GroupNum' }, to: { name: 'GroupNum' }, operator: '=' }]
    },
    {
      model: PriceListModel,
      alias: 'T3',
      type: 'LEFT',
      connectors: [{ from: { name: 'ListNum' }, to: { name: 'ListNum' }, operator: '=' }]
    },
    {
      model: CurrencyModel,
      alias: 'T4',
      type: 'LEFT',
      connectors: [{ from: { name: 'Currency' }, to: { name: 'CurrCode' }, operator: '=' }]
    }
  ],
  customColumns: [
    `CR1."TaxId0"`
  ],
  customRelationships: [
    ` LEFT JOIN (
      SELECT 
        MIN("TaxId0") AS "TaxId0",
        "CardCode"
      FROM 
        {{databaseName}}."CRD7" 
      WHERE 
        "TaxId0" IS NOT NULL
      GROUP BY 
        "CardCode") CR1
  ON CR1."CardCode" = T0."CardCode"`
  ]
}


export interface Address {
  LineNum: number
}

export interface ContactPerson {
  CntctCode: number
}

export interface BusinessPartner {
  CardCode: string,
  CardName: string,
  CardType: string,
  frozenFor: string,
  CreditLine: number,
  Phone1: string,
  Phone2: string,
  E_Mail: ContactEmployees[],
  Territory: number,
  ShipToDef: string,
  TaxId0: string,
  GroupCode: string,
  GroupName: string,
  GroupNum: number,
  Series: string,
  PymntGroup: string,
  InstNum: number,
  ListNum: number,
  ListName: string,
  CurrCode: string,
  CurrName: string,
  MainUsage: string,
  Free_Text: string,
  U_ALFA_ParadigmaId?: string,
  Addresses?: Address[]
}

export interface Address {
  Address: string,
  Street: string,
  Block: string,
  ZipCode: string,
  City: string,
  Country: string,
  State: string,
  AddressType: string,
  AddrType: string,
  StreetNo: string
}

export interface BPText {
  Free_Text: string
}

export interface PendingPartner {
  cardCode: string,
  cardCNPJ: string,
  cardType: string,
  cardName: string,
  cardForeignName: string,
  phone1: string,
  phone2: string,
  cellular: string,
  fax: string,
  emailAddress: string,
  website: string,
  freeText: string,
  groupCode: number,
  groupName: string,
  singlePayment: string,
  street: string,
  number: number,
  complement: string,
  zipCode: string,
  city: string,
  state: string,
  country: string,
  neighborhood: string
}
export interface ContactEmployees {
  E_MailL: string
}
