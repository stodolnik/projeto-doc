import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';
import { QueryBuilder } from '../../../common/database';
import { DatabaseQuery } from '../../../common/database/interfaces';
import { BusinessPartnerModel, BusinessPartner, BPText, ContactPerson, Address, PendingPartner, ContactEmployees } from './interfaces'
import { Partner } from '../../../fiorde/partner/interfaces/index';
import _ = require('lodash');

@Injectable()
export class HanaBusinessPartnersService extends DatabaseService<any[]> {

  get(query: DatabaseQuery): Promise<DatabaseResponse<BusinessPartner[]>> {

    let qb = new QueryBuilder()
      .database(this.databaseName)
      .model(BusinessPartnerModel)
      .filter(query.filter)
      .orderBy(query.order)
      .take(query.take)
      .skip(query.skip)
      .query();

    let data = this.exec(qb);

    return data;

  }

  getContactCode(id: string, name: string): Promise<DatabaseResponse<ContactPerson[]>> {

    let query = `
      SELECT "CntctCode" FROM ${this.databaseName}.OCPR T0 WHERE "CardCode" = '${id}' AND "Name" = '${name}'
      `;

    return this.exec(query)

  }

  getAddressId(id: string, name: string, type: string): Promise<DatabaseResponse<Address[]>> {

    let query = `
    SELECT "LineNum" FROM ${this.databaseName}.CRD1 WHERE "CardCode" = '${id}' AND "Address" = '${name}' AND "AdresType" = '${type}'
    `;

    return this.exec(query)


  }
  getById(id: string): Promise<DatabaseResponse<BusinessPartner[]>> {

    let query = `
    SELECT 
      "CardCode"
    FROM 
        ${this.databaseName}."OCRD"
    WHERE 
      "CardCode" = '${id}'`;

    return this.exec(query);
  }

  getByCodeCounty( country: string , state: string): Promise<DatabaseResponse<any[]>>{
    let query = 
    `SELECT "AbsId" FROM ${this.databaseName}."OCNT" WHERE "Country" = '${country}' AND "State" = '${state}'`;
    return this.exec(query);
  }

  getByCnpj(cnpj: string, type: string): Promise<DatabaseResponse<BusinessPartner[]>> {
    let query = `
    SELECT TOP 1
      oc."CardCode"
    FROM 
      ${this.databaseName}."CRD7" cr
    INNER JOIN
      ${this.databaseName}."OCRD" oc
      ON oc."CardCode" = cr."CardCode"
    WHERE 
      REPLACE(REPLACE(REPLACE(REPLACE(cr."TaxId0",'.',''),'/',''),'-',''),' ','') =  '${cnpj}'
    AND oc."CardType" = '${type}' `;

    console.log('getByCnpj: ', query);
    
    return this.exec(query);
  }

  getByCnpjOfCustomer(cnpj: string): Promise<DatabaseResponse<BusinessPartner[]>> {
    let query = `
    SELECT TOP 1
      	"CRD7"."CardCode"
    FROM 
      ${this.databaseName}."CRD7" 
      
      INNER JOIN ${this.databaseName}."OCRD"
      ON "OCRD"."CardCode" = "CRD7"."CardCode" 
      
    WHERE 
      REPLACE(REPLACE(REPLACE(REPLACE("TaxId0",'.',''),'/',''),'-',''),' ','') =  '${cnpj}'
      AND "OCRD"."CardType" = 'C'
      `;

    return this.exec(query);
  }

  

  getBankAccount(id: string, AccountId: string): Promise<DatabaseResponse<BusinessPartner[]>> {

    let query = `
    SELECT 
      Partner."CardCode"
    , Account."U_ALFA_ParadigmaId"
    FROM 
        ${this.databaseName}."OCRD" Partner
    INNER JOIN 
        ${this.databaseName}."OCRB" Account
    ON Partner."CardCode" = Account."CardCode"
    WHERE 
      Partner."CardCode" = '${id}' AND Account."U_ALFA_ParadigmaId" = '${AccountId}'`;

    return this.exec(query);
  }

  getPartnerbyType(): Promise<DatabaseResponse<BusinessPartner[]>> {
    let query = `
    SELECT 
      Partner."CardCode"
    FROM 
        ${this.databaseName}."OCRD" Partner
    WHERE 
      Partner."CardType" = 'C' AND Partner."U_FiordeIntegration" is null`;

    return this.exec(query);
  }

  updateRetryField(id: string) {
    let query = `
    UPDATE
      ${this.databaseName}."OCRD"
    SET 
        "U_ALFA_RETRY" = "U_ALFA_RETRY" + 1
    WHERE 
      "CardCode" = '${id}'`;

    this.exec(query);
  }

  updateIntegrationField(id: string) {
    let query = `
    UPDATE
      ${this.databaseName}."OCRD"
    SET 
      "U_FiordeIntegration" = 'Y' 
    WHERE 
      "CardCode" = '${id}'`;

    this.exec(query);

    query = `
    UPDATE
      ${this.databaseName}."CRD1"
    SET 
      "U_FiordeIntegration" = 'Y' 
    WHERE 
      "CardCode" = '${id}'`;

    this.exec(query);
  }

  NoIntegrated(): Promise<DatabaseResponse<Partner[]>> {
    let query = ` SELECT 
                       "CardCode"   as "CardCode"
                      --,"CardType"   as "CardType"
                      ,'T'   as "CardType"
                      ,"CardName"   as "CardName"
                      ,"AliasName"  as "CardForeignName"
                      ,"Phone1"     as "Phone1"
                      ,"Phone2"     as "Phone2"
                      ,"Cellular"   as "Cellular"
                      ,"Fax"        as "Fax"
                      ,"E_Mail"     as "eMailAddress"
                      ,"IntrntSite" as "website"
                      ,"Notes"      as "FreeText"
                      ,"GroupCode"  as "GroupCode"
                      ,''           as "SinglePayment"
                  FROM 
                    ${this.databaseName}."OCRD" 
                  WHERE "U_FiordeIntegration" IS NULL`;

    return this.exec(query);
  }

  getPendingPartners(): Promise<DatabaseResponse<PendingPartner[]>> {

    let query = ` SELECT DISTINCT
                      PARTNER."CardCode"   					        as "cardCode"
                    ,	PARTNER_TAX."TaxId0" 				      	  as "cardCNPJ"
                    ,	PARTNER."CardType"   				      	  as "cardType"
                    ,	IFNULL(PARTNER."CardName",'')   					        as "cardName"
                    ,	CASE WHEN IFNULL(CAST(PARTNER."AliasName" as Varchar),'') = '' 
                          THEN IFNULL(PARTNER."CardName",'')  
                          ELSE IFNULL(CAST(PARTNER."AliasName" as Varchar),'')	
                      END									              	  as "cardForeignName"
                    ,	IFNULL(PARTNER."Phone1",'') 				      	      as "phone1"
                    ,	IFNULL(REPLACE(REPLACE(PARTNER."Phone2", '(', ''), ')', ''),'')     					        as "phone2"
                    ,	IFNULL(PARTNER."Cellular",'')   					        as "cellular"
                    ,	IFNULL(PARTNER."Fax",'')        					        as "fax"
                  -- ,	IFNULL(PARTNERCONTACT."E_MailL",'')				        as "emailAddress"
                    ,	IFNULL(PARTNER."IntrntSite",'') 					        as "website"
                    ,	IFNULL(PARTNER."Notes",'')      					        as "freeText"
                    ,	PARTNER."GroupCode"  				      	  as "groupCode"
                    , UPPER(GROUP_."GroupName")                     as "groupName"
                    ,	''           		  				        	  as "singlePayment"
                    ,	IFNULL(PARTNER_ADDRESS."Street",'')		    		  as "street"
                    ,	IFNULL(PARTNER_ADDRESS."StreetNo",'')			  	  as "number"
                    ,	IFNULL(CAST(PARTNER_ADDRESS."Building" as VARCHAR),'')			  	  as "complement"
                    ,	IFNULL(PARTNER_ADDRESS."ZipCode",'')			    	  as "zipCode"
                    ,	IFNULL(PARTNER_ADDRESS."City",'')					      as "city"
                    ,	IFNULL(PARTNER_ADDRESS."State",'')					      as "state"
                    ,	IFNULL(PARTNER_ADDRESS."Country",'')  			  	  as "country"
                    , IFNULL(PARTNER_ADDRESS."Block",'')               as "neighborhood"

                  FROM ${this.databaseName}."OCRD" PARTNER

                  INNER JOIN ${this.databaseName}."CRD7" PARTNER_TAX 
                  ON PARTNER."CardCode" = PARTNER_TAX."CardCode"
                  AND PARTNER_TAX."TaxId12" = PARTNER."CardCode" 
                  AND 	PARTNER_TAX."TaxId0" IS NOT NULL 

                  LEFT JOIN ${this.databaseName}."OCPR" PARTNERCONTACT 
                  ON PARTNERCONTACT."CardCode" = PARTNER."CardCode"

                  INNER JOIN ${this.databaseName}."CRD8" PARTNER_BRANCH
				          ON PARTNER."CardCode" = PARTNER_BRANCH."CardCode"
				          AND PARTNER_BRANCH."BPLId" = '1'

                  INNER JOIN ${this.databaseName}."CRD1" PARTNER_ADDRESS
                  ON PARTNER."CardCode" = PARTNER_ADDRESS."CardCode"
                  AND PARTNER_ADDRESS."AdresType" = 'S'
                  --AND PARTNER_ADDRESS."LineNum" = 0 

                  INNER JOIN ${this.databaseName}."OCRG" GROUP_ 
                  ON PARTNER."GroupCode" = GROUP_."GroupCode"

                  WHERE IFNULL(PARTNER."U_FiordeIntegration", 'N') <> 'Y'
                  AND   IFNULL(PARTNER_ADDRESS."U_FiordeIntegration", 'N') <> 'Y'
                  AND   IFNULL(PARTNER."U_ALFA_RETRY", 0) < 4
                  AND   PARTNER."CreateDate" > '20200817'
                  AND   PARTNER."CardType" = 'C'
                  AND   PARTNER_TAX."TaxId0" IS NOT NULL
                  AND   PARTNER_TAX."TaxId0" <> ''`;


    return this.exec(query);

  }
  getPendingContatoPartners(cardcode: string): Promise<DatabaseResponse<ContactEmployees[]>> {

    let query = ` SELECT 
                  T0."E_MailL" 
                  from ${this.databaseName}.OCPR T0
                  INNER JOIN ${this.databaseName}.OCRD T1 ON T1."CardCode" =  T0."CardCode"
                  WHERE T0."CardCode" = '${cardcode}'`;


    return this.exec(query);

  }
}