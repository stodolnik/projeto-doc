import { Table } from "../../../../common/database/interfaces";
import { Document } from '../../../../common/interfaces/index';

export const OrdersModel: Table = {

  name: 'ORDR',
  alias: 'T0',
  columns: [
    { name: 'DocEntry' },
    { name: 'DocNum' },
    { name: 'CardCode' },
    { name: 'CardName' },
    { name: 'NumAtCard' },
    { name: 'DocDate' },
    { name: 'DocDueDate' },
    { name: 'DocTotal' },
    { name: 'ALFA_ThundersInvoiceId' }

  ],
  relationships: [

  ],
  customColumns: [

  ],
  customRelationships: [

  ]
}


export interface Orders extends Document {

}

