import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';
import { OrdersModel, Orders } from './interfaces';
import { QueryBuilder } from '../../../common/database';
import { DatabaseQuery } from '../../../common/database/interfaces';

@Injectable()
export class HanaOrdersService extends DatabaseService<any[]> {

  get(query: DatabaseQuery): Promise<DatabaseResponse<Orders[]>> {
        
    let qb = new  QueryBuilder()
                  .database(this.databaseName)
                  .model(OrdersModel)
                  .filter(query.filter)
                  .orderBy(query.order)
                  .take(query.take)
                  .skip(query.skip)
                  .query(); 
    
    return this.exec(qb);

  }

  getById(id: string[]): Promise<DatabaseResponse<Orders[]>> {

    let qb = new  QueryBuilder()
                  .database(this.databaseName)
                  .model(OrdersModel)
                  .filter([
                    {columnName: "DocNum", operator: "IN", tableAlias: "T0",  type: 'array', value: id}
                  ])
                  .query();
    
    return this.exec(qb);

  }
  
  getByNumAtCard(id: string): Promise<DatabaseResponse<Orders[]>> {
    return this.exec(`SELECT COUNT("NumAtCard") FROM ${this.databaseName}."ORDR" WHERE "NumAtCard" = '${id}'`);
  }

  getByUpdated(ids: string[]): Promise<DatabaseResponse<Orders[]>> {

    return this.exec(`
      SELECT 
        "U_ALFA_ThundersInvoiceId" 
      FROM 
        ${this.databaseName}."ORDR" 
      WHERE 
        "U_ALFA_ThundersInvoiceId" IN (${ids.map(r=> `'${r}'`).join(',')})
    `);
  }
}
