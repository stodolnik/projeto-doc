import { Module } from '@nestjs/common';
import { HanaOrdersService } from './orders.service';
import { DatabaseModule } from '../../../b1/core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaOrdersService],
  exports: [HanaOrdersService]
})

export class HanaOrdersModule {}
