import { Module } from '@nestjs/common';
import { HanaItemsService } from './items.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaItemsService],
  exports: [HanaItemsService]
})

export class HanaItemsModule {}
