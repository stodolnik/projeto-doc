export interface NCM {
  AbsEntry: string
}

export interface ItemCode {
  id: string
}