import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import { QueryBuilder } from '../../../common/database';
import { DatabaseQuery } from '../../../common/database/interfaces';
import { NCM, ItemCode } from './interfaces/index';

@Injectable()
export class HanaItemsService extends DatabaseService<any> {

  async getById(id: string): Promise<DatabaseResponse<any>> {
    console.log( await this.exec(`SELECT "ItemCode" FROM ${this.databaseName}."OITM" WHERE "ItemCode" = '${id}'`))
    return await this.exec(`SELECT "ItemCode" FROM ${this.databaseName}."OITM" WHERE "ItemCode" = '${id}'`);
  }

  getByFiordeId(id: string): Promise<DatabaseResponse<ItemCode>> {
    return this.exec(`SELECT "ItemCode"  FROM ${this.databaseName}.OITM WHERE "U_CodSysfiorde" = '${id}'`);
  }

  async getNCM(id: string): Promise<DatabaseResponse<NCM[]>> {

    // let ncm = id.substr(0, 4) + '.' + id.substr(4, 2) + '.' + id.substr(6, 2);   
    return await this.exec(`SELECT "AbsEntry" FROM ${this.databaseName}."ONCM" WHERE "NcmCode" = '${id}'`);
  }

}
