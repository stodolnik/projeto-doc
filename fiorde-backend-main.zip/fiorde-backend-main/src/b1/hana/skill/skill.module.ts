import { Module } from '@nestjs/common';
import { HanaSkillService } from './skill.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaSkillService],
  exports: [HanaSkillService]
})
export class SkillModule {}
