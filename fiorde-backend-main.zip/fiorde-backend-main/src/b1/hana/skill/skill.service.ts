import { Injectable } from '@nestjs/common';
import { Sequence, DIModel, DIAdditional, Status, Sequence1 } from './interfaces';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import * as _ from 'lodash';

@Injectable()
export class HanaSkillService extends DatabaseService<any> {

  getSequenceCode(table: string): Promise<DatabaseResponse<Sequence[]>> {

    const query = `SELECT MAX(CAST("Code" AS Number)) + 1 as "Code" FROM ${this.databaseName}."${table}"`;

    return this.exec(query);

  }

  getSequenceCodeimport(table: string): Promise<DatabaseResponse<Sequence1[]>> {

    const query = `SELECT MAX(CAST("Id" AS Number)) + 1 as "Id" FROM ${this.databaseName}."${table}"`;

    return this.exec(query);

  }

  getSequenceCodeimportadd(table: string): Promise<DatabaseResponse<Sequence1[]>> {

    const query = `SELECT MAX(CAST("Id" AS Number))  as "Id2" FROM ${this.databaseName}."${table}"`;

    return this.exec(query);

  }
  

  documentStatus(): Promise<DatabaseResponse<Status[]>> {
    const query = ` 
    
    SELECT  
    PURCHASE_INVOICE."NumAtCard" AS "NumAtCard"
  , PURCHASE_INVOICE."DocEntry"   AS "DocumentID"
  , PURCHASE_INVOICE."DocNum"   AS "DocumentNumber"
	, CAST (PURCHASE_INVOICE."Serial" AS VARCHAR) AS "Invoice"
	, PURCHASE_INVOICE."SeriesStr"   AS "InvoiceSerial"
	, SKL_NFE."U_CreateDate" 	    AS "CreateDate"
	, PURCHASE_INVOICE."DocTotal" AS "DocumentTotal"
  , SKL_NFE."U_msgSEFAZ"        AS "StatusSefaz"
  , SKL_NFE."U_ChaveAcesso" AS "AcessKey"
  , 'PURCHASE_INVOICE' AS "DocumentType"
  , PURCHASE_INVOICE."Project"
  , PURCHASE_INVOICE."U_fiordeRetries" AS "Retrie"
 
FROM ${this.databaseName}.OPCH PURCHASE_INVOICE

INNER JOIN ${this.databaseName}."@SKL25NFE" SKL_NFE
	ON  PURCHASE_INVOICE."DocEntry" = SKL_NFE."U_DocEntry"
AND SKL_NFE."U_tipoDocumento" = 'NE'

WHERE PURCHASE_INVOICE."U_IntegratedStatus" = 'N'
AND PURCHASE_INVOICE."U_FiordeIntegratedId" IS NOT NULL 
AND PURCHASE_INVOICE."U_fiordeRetries" <= 3 

UNION ALL 

SELECT  
    INVOICE."NumAtCard" AS "NumAtCard"
  , INVOICE."DocEntry"   AS "DocumentID"
	, INVOICE."DocNum"   AS "DocumentNumber"
	, SKL_NFE."U_NrRetNFSE" 			      AS "Invoice"
	, INVOICE."SeriesStr"   AS "InvoiceSerial"
	, INVOICE."DocDate"	    AS "CreateDate"
	, INVOICE."DocTotal" AS "DocumentTotal"
  , ''  AS "StatusSefaz"
  , '' AS "AcessKey"
  , 'INVOICE' AS "DocumentType"
  , INVOICE."Project"
  , INVOICE."U_fiordeRetries" AS "Retrie"
 
FROM ${this.databaseName}.OINV INVOICE

LEFT JOIN ${this.databaseName}."@SKILL_NOFSNFSE001" SKL_NFE
	ON  INVOICE."DocEntry" = SKL_NFE."U_NrDocEntry" 
INNER JOIN ${this.databaseName}.ONFM MODELONOTA 
	ON INVOICE."Model" = MODELONOTA."AbsEntry"



WHERE  INVOICE."U_IntegratedStatus" = 'N'
AND INVOICE."U_FiordeIntegratedId" IS NOT NULL 
AND INVOICE."U_fiordeRetries" <= 3 
AND SKL_NFE."U_XmlCancelado" IS NULL 
AND INVOICE."Project" IS NOT NULL 
AND IFNULL(SKL_NFE."U_NrRetNFSE",'') <> ''
AND MODELONOTA."NfmName" <> 'NADA'

UNION

SELECT  
    INVOICE."NumAtCard" AS "NumAtCard"
  , INVOICE."DocEntry"   AS "DocumentID"
	, INVOICE."DocNum"   AS "DocumentNumber"
	, SKL_NFE."SerialNfSe" 			      AS "Invoice"
	, INVOICE."SeriesStr"   AS "InvoiceSerial"
	, INVOICE."DocDate"	    AS "CreateDate"
	, INVOICE."DocTotal" AS "DocumentTotal"
  , ''  AS "StatusSefaz"
  , '' AS "AcessKey"
  , 'INVOICE' AS "DocumentType"
  , INVOICE."Project"
  , INVOICE."U_fiordeRetries" AS "Retrie"
 
FROM ${this.databaseName}.OINV INVOICE

LEFT JOIN ${this.databaseName}."Doc" SKL_NFE
	ON  INVOICE."DocEntry" = SKL_NFE."DocEntry" 
INNER JOIN ${this.databaseName}.ONFM MODELONOTA 
	ON INVOICE."Model" = MODELONOTA."AbsEntry"



WHERE  
--INVOICE."DocNum" = 206242 AND
INVOICE."U_IntegratedStatus" = 'N'
AND INVOICE."U_FiordeIntegratedId" IS NOT NULL 
AND INVOICE."U_fiordeRetries" <= 3 
AND SKL_NFE."IsCancel" IS NULL 
AND INVOICE."Project" IS NOT NULL 
AND IFNULL(SKL_NFE."SerialNfSe",'') <> ''
AND MODELONOTA."NfmName" <> 'NADA'

UNION

SELECT  
    INVOICE."NumAtCard" AS "NumAtCard"
  , INVOICE."DocEntry"   AS "DocumentID"
	, INVOICE."DocNum"   AS "DocumentNumber"
	, INVOICE."Serial" 			      AS "Invoice"
	, INVOICE."SeriesStr"   AS "InvoiceSerial"
	, INVOICE."DocDate"	    AS "CreateDate"
	, INVOICE."DocTotal" AS "DocumentTotal"
  , ''  AS "StatusSefaz"
  , '' AS "AcessKey"
  , 'INVOICE' AS "DocumentType"
  , INVOICE."Project"
  , INVOICE."U_fiordeRetries" AS "Retrie"
 
FROM ${this.databaseName}.OINV INVOICE

INNER JOIN ${this.databaseName}.ONFM MODELONOTA 
	ON INVOICE."Model" = MODELONOTA."AbsEntry"



WHERE  INVOICE."U_IntegratedStatus" = 'N'
AND INVOICE."U_FiordeIntegratedId" IS NOT NULL 
AND INVOICE."U_fiordeRetries" <= 3 
AND INVOICE."Project" IS NOT NULL 
AND IFNULL(INVOICE."Serial",0) <> 0
AND MODELONOTA."NfmName" = 'NADA'


`;
    return this.exec(query);
  }


  updateIntegrationField(id: string, type: string) {

    const objectType = {
      'PURCHASE_INVOICE': 'OPCH',
      'INVOICE': 'OINV',
      'DELIVERY': 'ODLN',
    }

    let query = `
    UPDATE
      ${this.databaseName}."${objectType[type]}"
    SET 
      "U_IntegratedStatus" = 'Y' 
    WHERE 
      "DocEntry" = '${id}'`;

    this.exec(query);
  }

  updateIntegrationRetrie(id: string, type: string , retrie : number) {

    const objectType = {
      'PURCHASE_INVOICE': 'OPCH',
      'INVOICE': 'OINV',
      'DELIVERY': 'ODLN',
    }

    let query = `
    UPDATE
      ${this.databaseName}."${objectType[type]}"
    SET 
      "U_fiordeRetries" = '${retrie}' 
    WHERE 
      "DocEntry" = '${id}'`;

    this.exec(query);
  }
/*
  async insertDIData(di: DIModel): Promise<DatabaseResponse<any>> {
    try {
      const { data: sequence } = await this.getSequenceCode(`@SKL25IMPOT`);

      const query = `INSERT INTO ${this.databaseName}."@SKL25IMPOT" (			   
			"Code"
      , "Name"
      , "U_LineNum"
			, "U_DocNum"
      , "U_TipoDoc"
      , "U_Chave"
			, "U_cExportador"
			, "U_ItemCode"
			, "U_nDI"
			, "U_dDi"
			, "U_xLocDemsemb"
			, "U_UFDesemb"
			, "U_dDesemb"
			, "U_Drawback"
			, "U_Declaracao"
			, "U_tpViaTransp"
			, "U_vAFRMM"
			, "U_tpIntermedio"
			, "U_CNPJ"
			, "U_UFTerceiro" )
			
			VALUES (
         ${this.getValue(_.first(sequence).Code) || 0}
        ,${this.getValue(_.first(sequence).Code) || 0}
        ,${this.getValue(di.lineNum)}
        ,${this.getValue(di.docNum)}
        ,${this.getValue(di.typeDoc)}
        ,${this.getValue(di.key)}
        ,${this.getValue(di.exporterCode)}
        ,${this.getValue(di.itemCode)}
        ,${this.getValue(di.diNumber)}
        ,TO_DATE(${this.getValue(di.diDate)})
        ,${this.getValue(di.location)}
        ,${this.getValue(di.uf)} 
        ,TO_DATE(${this.getValue(di.landingDate)})
        ,${this.getValue(di.drawback)}
        ,${this.getValue(di.declarationType)}
        ,${this.getValue(di.transport)}
        ,${this.getValue(di.afrmmValue)}
        ,${this.getValue(di.importModel)}
        ,${this.getValue(di.purchasersCNPJ)}
        ,${this.getValue(di.purchasersUF)}
    )`;

      return this.exec(query);
    } catch (err) {
      throw err;
    }

  }
*/
async getByCompany(cnpj: string): Promise<DatabaseResponse<any>> {
  let query = `

  SELECT "ID", "RazaoSocial", "CNPJ"  
  
  FROM ${this.databaseName}."Entidade"

  WHERE REPLACE(REPLACE(REPLACE(REPLACE("CNPJ",'.',''),'/',''),'-',''),' ','') = REPLACE(REPLACE(REPLACE(REPLACE('${cnpj}','.',''),'/',''),'-',''),' ','')`;

   return this.exec(query);

}

async insertDIData(di: DIModel): Promise<DatabaseResponse<any>> {
  try {
    const { data: sequence1 } = await this.getSequenceCodeimport(`Importer`);
   

    const query = `INSERT INTO ${this.databaseName}."Importer" (
    "Id",  			   
    "LineNum",
    "CompanyId",
    "ObjType",
    "DocEntry",
    "ExporterCode",
    "DocNum",
    "DateRecord",
    "Place",
    "PlaceState",
    "DateClearance",
    "TipoImportacao",
    "TransportVia",
    "AfrmmValue",
    "IntermediationType",
    "CnpjBuyer",
    "StateBuyer" )
    
    VALUES (
      ${this.getValue(_.first(sequence1).Id) || 0}
      ,${this.getValue(di.lineNum)}
      ,${this.getValue(di.companyId)}
      ,${this.getValue(di.objtype)}
      ,${this.getValue(di.docNum)}
      ,${this.getValue(di.exporterCode)}
      ,${this.getValue(di.diNumber)}
      ,TO_DATE(${this.getValue(di.diDate)})
      ,${this.getValue(di.location)}
      ,${this.getValue(di.uf)} 
      ,TO_DATE(${this.getValue(di.landingDate)})
      ,${this.getValue(di.declarationType)}
      ,${this.getValue(di.transport)}
      ,${this.getValue(di.afrmmValue)}
      ,${this.getValue(di.importModel)}
      ,${this.getValue(di.purchasersCNPJ)}
      ,${this.getValue(di.purchasersUF)}
  )`;
   
    console.log(query)
    return this.exec(query);
    
  } catch (err) {
    throw err;
  }

}
/*
  async insertDIAdditional(di: DIAdditional): Promise<DatabaseResponse<any>> {
    try {
      const { data: sequence } = await this.getSequenceCode(`@SKL25IMPAD`);

      const query = `INSERT INTO  ${this.databaseName}."@SKL25IMPAD" (			   
    "Code"
    , "Name"
    , "U_LineNum"
    , "U_DI"
    , "U_ItemCode"
    , "U_NumAdic"
    , "U_Sequencia"
    , "U_VlDesconto"
        )
   
   VALUES (
      ${this.getValue(_.first(sequence).Code) || 0}
    , ${this.getValue(_.first(sequence).Code) || 0}
    , ${this.getValue(di.lineNum)}	  
    , ${this.getValue(di.diKey)}	  
    , ${this.getValue(di.itemCode)}	  
    , ${this.getValue(di.numAdditional)}	  
    , ${this.getValue(di.sequence)}  
    , ${this.getValue(di.discountAmount)}  
    )`;

      return this.exec(query);
    } catch (err) {
      throw err;
    }

  }
*/
async insertDIAdditional(di: DIAdditional): Promise<DatabaseResponse<any>> {
  try {
    const { data: sequence1 } = await this.getSequenceCodeimport(`ImporterAddition`);
    const { data: sequence2 } = await this.getSequenceCodeimportadd(`Importer`);

    const query = `INSERT INTO  ${this.databaseName}."ImporterAddition" (			   
      "Id",
      "ImporterId",
      "Number",
      "NumberSeq",
      "SuppCode",
      "Discount",
      "PurchaseId",
      "ItemId",
      "nDraw"
      )
 
 VALUES (
  ${this.getValue(_.first(sequence1).Id) || 0}
   ,${this.getValue(_.first(sequence2).Id2) || 0}	  
  , ${this.getValue(di.Number)}	  
  , ${this.getValue(di.NumberSeq)}	  
  , ${this.getValue(di.SuppCode)}	  
  , ${this.getValue(di.Discount)}  
  , ${this.getValue(di.PurchaseId)} 
  , ${this.getValue(di.ItemId)}  
  , ${this.getValue(di.nDraw)}   
  )`;
  console.log(query);
    return this.exec(query);
  } catch (err) {
    throw err;
  }

}
  getValue = (value) => {
    if (value) {
      return `'${value}'`;
    } else {
      return null;
    }
  }


}