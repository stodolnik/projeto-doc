export interface Sequence {
  Code: string
}

export interface Sequence1 {
  Id: string,
  Id2:string

}

export interface DIModel {
  companyId?: string;
  objtype?: number;
  docNum?: string,
  typeDoc?: string,
  key?: string,
  lineNum?: string,
  exporterCode?: string,
  declarationType?: string,
  itemCode?: string,
  diNumber?: string,
  diDate?: Date,
  location?: string,
  uf?: string,
  landingDate?: Date,
  drawback?: string,
  transport?: string,
  afrmmValue?: number,
  importModel?: string,
  purchasersCNPJ?: string,
  purchasersUF?: string
}

export interface DIAdditional {
    ImporterId?: string,
     Number?: string,
    NumberSeq?: string,
    SuppCode?: string, 
    Discount?: number,
    PurchaseId?:number,
    ItemId?: string,
    nDraw?: string
  
}

export interface Status {
  NumAtCard?: string,
  DocumentID?: string,
  DocumentNumber?: string,
  Invoice?: string,
  InvoiceSerial?: string,
  CreateDate?: string,
  DocumentTotal?: number,
  StatusSefaz?: string,
  DocumentType?: string,
  AcessKey?: string,
  Project?: string
}