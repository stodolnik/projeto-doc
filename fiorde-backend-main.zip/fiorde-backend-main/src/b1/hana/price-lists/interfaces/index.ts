import { Table } from "../../../../common/database/interfaces";

export const PriceListModel: Table = {
  name: 'OPLN',
  alias: 'T0',
  columns: [
    {name: 'ListNum'},
    {name: 'ListName'}
  ]
}

export interface PriceList {
  ListNum: number,
  ListName: string
}