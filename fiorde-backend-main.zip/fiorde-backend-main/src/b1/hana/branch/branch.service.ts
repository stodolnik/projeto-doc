import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';
import { Branch, Trib } from './interfaces'
import _ = require('lodash');

@Injectable()
export class HanaBranchService extends DatabaseService<any> {

  async getByCnpj(cnpj: string): Promise<DatabaseResponse<Branch[]>> {
    let query = `

    SELECT "BPLId" as "id"
    
    FROM ${this.databaseName}.OBPL 
    
    WHERE REPLACE(REPLACE(REPLACE(REPLACE("TaxIdNum",'.',''),'/',''),'-',''),' ','') = REPLACE(REPLACE(REPLACE(REPLACE('${cnpj}','.',''),'/',''),'-',''),' ','')`;

    return this.exec(query);

  }

  async getByCnpjCompany(cnpj: string): Promise<DatabaseResponse<Branch[]>> {
    let query = `

    SELECT "TaxIdNum" as "id"
    
    FROM ${this.databaseName}.OBPL 
    
    WHERE "BPLId" = '${cnpj}'`;

    return this.exec(query);

  }

  async getTrib(branch: string): Promise<DatabaseResponse<Trib[]>> {
    let query = `

    SELECT "U_TipoTrib" 

    FROM ${this.databaseName}."@ALFA_TIPOTRIB_NFS" 

    WHERE "U_CodFilial" = ${branch}`;

    return this.exec(query);

  }
}