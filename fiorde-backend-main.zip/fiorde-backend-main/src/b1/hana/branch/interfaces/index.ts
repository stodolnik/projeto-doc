export interface Branch {
  id: string
}

export interface Trib {
  U_TipoTrib: string
}

