import { Module } from '@nestjs/common';
import { HanaBranchService } from './branch.service';
import { DatabaseModule } from '../../../b1/core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaBranchService],
  exports: [HanaBranchService]
})

export class HanaBranchModule {}
