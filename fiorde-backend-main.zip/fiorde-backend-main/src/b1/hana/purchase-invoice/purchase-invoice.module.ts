import { Module } from '@nestjs/common';
import { HanaPurchaseInvoiceService } from './purchase-invoice.service';
import { DatabaseModule } from '../../../b1/core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaPurchaseInvoiceService],
  exports: [HanaPurchaseInvoiceService]
})

export class HanaPurchaseInvoiceModule {}
