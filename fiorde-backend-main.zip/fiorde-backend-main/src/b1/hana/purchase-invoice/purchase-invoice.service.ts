import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';
import { PurchaseInvoice, Tax } from './interfaces';

@Injectable()
export class HanaPurchaseInvoiceService extends DatabaseService<any> {
  

  updateIVAST(
    key: string,
    line: number,
    taxValue: number,
  ): Promise<DatabaseResponse<PurchaseInvoice[]>> {
    let query = `
                UPDATE ${this.databaseName}."PCH1" 

                SET "U_B1SYS_IVAST" = '${taxValue}'

                WHERE "DocEntry" = '${key}'
                  AND "LineNum" = ${line}`;
    return this.exec(query);
  }

  getTax(description: string): Promise<DatabaseResponse<Tax>> {
    let query = `SELECT "U_usage_purchase" as "usage"
                      , "U_taxid_purchase" as "taxId"
               
                 FROM ${this.databaseName}."@ALFA_USAGE" 
                 
                 WHERE "U_percent_ipi" = '${description}'`;

    return this.exec(query);
  }

  verifyExistPaymentOfInvoice(
    docEntry: string,
  ): Promise<DatabaseResponse<any[]>> {
    let query = `
                  SELECT 
	                    VPM2."DocNum" 
                  FROM
                  ${this.databaseName}.VPM2 , ${this.databaseName}.OVPM
                  WHERE
	                    VPM2."DocNum" = OVPM."DocEntry" AND 
	                    VPM2."DocEntry" = '${docEntry}' AND
	                    OVPM."Canceled" = 'N'`;
    return this.exec(query);
  }

  getInvoiceForPayment(docNum) {
    try {
      let query = `
  SELECT 
          OPCH."DocEntry" ,
          OPCH."CardCode",
          OPCH."BPLId" , 
          (OPCH."DocTotal" - IFNULL(Sum(PCH5."WTAmnt"), 0)) "DocTotal",
          OPCH."Project"
  FROM 
          ${this.databaseName}."OPCH"
  LEFT JOIN
          ${this.databaseName}.PCH5 
  ON 
          PCH5."AbsEntry"  = OPCH."DocEntry"
          AND PCH5."Category" = 'P'  
  WHERE 
          OPCH."DocNum" = '${docNum}'
  GROUP BY
          OPCH."DocEntry" ,
          OPCH."CardCode",
          OPCH."BPLId" , 
          OPCH."DocTotal",
          OPCH."Project"`;
      return this.exec(query);
    } catch (err) {
      return null;
    }
  }

  verifyExistAccount(account: string): Promise<DatabaseResponse<any[]>> {
    let query = `SELECT 
                    "AcctCode"
                 FROM 
                 ${this.databaseName}.OACT
                 WHERE
                    "AcctCode" = '${account}'`;
    return this.exec(query);
  }

  getNumberLcmByPayment(docEntry: string): Promise<DatabaseResponse<any[]>> {
    try {
      let query = `	
      SELECT 
            OJDT."Number" ,
            OVPM."DocEntry" ,
            OJDT."U_FiordeIntegration",
            OVPM."JrnlMemo"
      FROM
            ${this.databaseName}.OJDT ,
            ${this.databaseName}.OVPM
      WHERE 
            OJDT."TransId" = OVPM."TransId"
            AND OVPM."DocEntry" = '${docEntry}'`;

      return this.exec(query);
    } catch (err) {
      return null;
    }
  }

  getCreditCard(creditCard: string): Promise<DatabaseResponse<any[]>> {
    try {
      let query = `
      SELECT 
        T0."CreditCard" 
      FROM 
        ${this.databaseName}.OCRC T0 
      WHERE 
        T0."AcctCode" = '${creditCard}'
      `;

      return this.exec(query);
    } catch (err) {
      return null
    }
  }

  getInfoAccounting(docNum: number): Promise<DatabaseResponse<any[]>> {
    try {
      let query = `
      SELECT TOP 1 
        T1."InstlmntID",
        T1."InsTotal"
      FROM ${this.databaseName}.OPCH T0  
        INNER JOIN ${this.databaseName}.PCH6 T1 ON T0."DocEntry" = T1."DocEntry" 
      WHERE 
        T0."DocNum" = ${docNum} AND T1."Status" = 'O' 
      ORDER BY 
        T1."InstlmntID"
      `;

      return this.exec(query);
    } catch (err) {
      return null
    }
  }
  
}
