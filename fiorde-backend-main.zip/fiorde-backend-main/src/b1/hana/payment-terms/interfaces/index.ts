import { Table } from "../../../../common/database/interfaces";

export const PaymentTermModel: Table = {
  name: 'OCTG',
  alias: 'T0',
  columns: [
    {name: 'GroupNum'},
    {name: 'PymntGroup'},
    {name: 'InstNum'}
  ]
}

export interface PaymentTerm {
  GroupNum: number,
  PymntGroup: string,
  InstNum: number
}