import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import { CountyCodesModel, CountyCode } from './interfaces';
import { QueryBuilder } from '../../../common/database';

@Injectable()
export class HanaCountyCodesService extends DatabaseService<any[]> {

  get(id: string[]): Promise<DatabaseResponse<CountyCode[]>> {

    let qb = new QueryBuilder()
      .database(this.databaseName)
      .model(CountyCodesModel)
      .filter([
        { columnName: "IbgeCode", operator: "IN", tableAlias: "T0", type: 'array', value: id }
      ])
      .query();
    
    return this.exec(qb);

  }

}
