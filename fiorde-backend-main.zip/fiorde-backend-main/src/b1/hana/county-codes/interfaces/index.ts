import { Table } from "../../../../common/database/interfaces";

export const CountyCodesModel: Table = {
  name: 'OCNT',
  alias: 'T0',
  columns: [
    {name: 'AbsId'},
    {name: 'IbgeCode'}
  ]
}

export interface CountyCode {
  AbsId: string,
  IbgeCode: string
}

