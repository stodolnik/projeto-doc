import { Module } from '@nestjs/common';
import { HanaCountyCodesService } from './county-codes.services';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaCountyCodesService],
  exports: [HanaCountyCodesService]
})

export class HanaCountyCodesModule {}
