import { Module } from '@nestjs/common';
import { HanaModelService } from './model.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaModelService],
  exports: [HanaModelService]
})
export class ModelModule {}
