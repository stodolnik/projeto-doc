import { Injectable } from '@nestjs/common';
import { Model } from './interfaces';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';

@Injectable()
export class HanaModelService extends DatabaseService<any> {

  getModelId(id: string): Promise<DatabaseResponse<Model[]>> {

    const query = `SELECT "AbsEntry" FROM ${this.databaseName}.ONFM WHERE "NfmName" = '${id}'`;
    return this.exec(query);

  }



  getNextNumSerial(): Promise<DatabaseResponse<any[]>> {
    let query = `
    SELECT 
      T0."Name",
      T0."U_ALFA_SEQ",
      T0."U_ALFA_FILIAL",
      T0."U_ALFA_ITEM",
      T0."U_ALFA_MODEL" 
    FROM 
      ${this.databaseName}."@ALFA_MODELO_NOTAS" T0
    `;
    return this.exec(query);
  }  

}