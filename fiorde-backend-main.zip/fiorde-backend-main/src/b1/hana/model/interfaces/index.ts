export interface Model {
  AbsEntry: string
}

