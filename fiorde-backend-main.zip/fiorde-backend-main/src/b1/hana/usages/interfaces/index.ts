export interface UsagesModel {
  ID: number,
  Usage: string
}
