import { Module } from '@nestjs/common';
import { B1UsagesService } from './usages.service';
import { DatabaseModule } from '../../../b1/core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [B1UsagesService],
  exports: [B1UsagesService]
})
export class B1UsagesModule {}
