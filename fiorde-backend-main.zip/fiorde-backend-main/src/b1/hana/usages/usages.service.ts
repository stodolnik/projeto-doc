import { Injectable } from '@nestjs/common';
import { UsagesModel } from './interfaces';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';

@Injectable()
export class B1UsagesService extends DatabaseService<UsagesModel[]> {

  get(): Promise<DatabaseResponse<UsagesModel[]>> {

    let query = `
      SELECT
        T0."ID",
        T0."Usage"
      FROM
        ${this.databaseName}."OUSG" T0
      ORDER BY
        T0."Usage"
    `;

    return this.exec(query);

  }
}
