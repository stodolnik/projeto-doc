import { Table } from "../../../../common/database/interfaces";

export const EmployeeModel: Table = {

  name: 'OHEM',
  alias: 'T0',
  columns: [
    {name: 'manager'},
    {name: 'salesPrson'},
    {name: 'position'},
    {name: 'Active'},
    {name: 'userId'},
  ]
}

export interface Employee {
  manager: string,
  salesPrson: string,
  position: string,
  Active: string,
  userId: string,
}