import { Table } from "../../../../common/database/interfaces";

export const CardGroupModel: Table = {
  name: 'OCRG',
  alias: 'T0',
  columns: [
    {name: 'GroupCode'},
    {name: 'GroupName'}
  ]
}

export interface CardGroup {
  GroupCode: number,
  GroupName: string
}