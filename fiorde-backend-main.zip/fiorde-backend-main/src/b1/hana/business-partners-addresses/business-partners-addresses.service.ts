import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import { BusinessPartnersAddressModel } from './interfaces';
import { QueryBuilder } from '../../../common/database';
import { DatabaseQuery } from '../../../common/database/interfaces';

@Injectable()
export class HanaBusinessPartnersAddressesService extends DatabaseService<any[]> {

  get(query: DatabaseQuery): Promise<DatabaseResponse<any[]>> {
        
    let qb = new  QueryBuilder()
                  .database(this.databaseName)
                  .model(BusinessPartnersAddressModel)
                  .filter(query.filter)
                  .orderBy(query.order)
                  .take(query.take)
                  .skip(query.skip)
                  .query();
    
    let data = this.exec(qb);

    return data;

  }

}
