import { Module } from '@nestjs/common';
import { HanaBusinessPartnersAddressesService } from './business-partners-addresses.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaBusinessPartnersAddressesService],
  exports: [HanaBusinessPartnersAddressesService]
})

export class HanaBusinessPartnersAddressesModule {}
