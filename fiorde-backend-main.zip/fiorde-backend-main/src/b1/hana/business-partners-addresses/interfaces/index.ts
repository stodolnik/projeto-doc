import { Table } from "../../../../common/database/interfaces";

export const BusinessPartnersAddressModel: Table = {
  name: 'CRD1',
  alias: 'T0',
  columns: [
    {name: 'CardCode'},
    {name: 'Address'},
    {name: 'Street'},
    {name: 'Block'},
    {name: 'ZipCode'},
    {name: 'City'},
    {name: 'Country'},
    {name: 'State'},
    {name: 'AdresType'},
    {name: 'AddrType'},
    {name: 'StreetNo'},
  ]
}

export interface BusinessPartnersAddress {
  CardCode: string,
  Address: string,
  Street: string,
  Block: string,
  ZipCode: string,
  City: string,
  Country: string,
  State: string,
  AdresType: string,
  AddrType: string,
  StreetNo: string
}