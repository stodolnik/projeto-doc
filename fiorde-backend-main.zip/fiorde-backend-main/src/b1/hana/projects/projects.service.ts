import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';
import { QueryBuilder } from '../../../common/database';
import { DatabaseQuery } from '../../../common/database/interfaces';

@Injectable()
export class HanaProjectsService extends DatabaseService<any[]> {
  
  getById(id: string): Promise<DatabaseResponse<any[]>> {
    return this.exec(`SELECT "PrjCode" FROM ${this.databaseName}."OPRJ" WHERE "PrjCode" = '${id}'`);
  }

}
