import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../../b1/core/database/interfaces';
import { DatabaseService } from '../../../b1/core/database/database.service';
import { Tax } from './interfaces';

@Injectable()
export class HanaDeliveryInvoiceService extends DatabaseService<any> {
  
  getTax(description: string): Promise<DatabaseResponse<Tax>> {

    let query = `SELECT "U_usage_Delivery" as "usage"
                      , "U_taxid_Delivery" as "taxId"
               
                 FROM ${this.databaseName}."@ALFA_USAGE" 
                 
                 WHERE "U_percent_ipi" = '${description}'`;

    return this.exec(query);
  }
}
