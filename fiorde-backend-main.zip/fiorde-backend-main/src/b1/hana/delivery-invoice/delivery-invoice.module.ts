import { Module } from '@nestjs/common';
import { HanaDeliveryInvoiceService } from './delivery-invoice.service';
import { DatabaseModule } from '../../../b1/core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaDeliveryInvoiceService],
  exports: [HanaDeliveryInvoiceService]
})

export class HanaDeliveryInvoiceModule {}
