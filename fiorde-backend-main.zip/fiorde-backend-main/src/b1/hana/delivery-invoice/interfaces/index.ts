import { Document } from '../../../../common/interfaces/index';

export interface PurchaseInvoice extends Document {

}

export interface Tax{
    usage: number,
    taxId: string
}