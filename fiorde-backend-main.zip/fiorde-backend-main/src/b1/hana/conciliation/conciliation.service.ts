import { Injectable } from '@nestjs/common';
import { ConciliationModel, ConciliationType, ConciliationField } from './interfaces';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';

@Injectable()
export class B1ConciliationService extends DatabaseService<any> {

  getPendingReceived(): Promise<DatabaseResponse<ConciliationModel[]>> {

    const query = `
    SELECT 
      T0."DocEntry",
      T0."DocNum",
      T0."U_ALFA_ParadigmaId",  
      'VENDA'                   AS "Type"
    FROM 
      ${this.databaseName}.ORDR T0
    WHERE 
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') 		= 'N' AND
      IFNULL(T0."U_ALFA_ParadigmaCanceled",'N') 		= 'N'
        
    UNION ALL

    SELECT        
      T0."DocEntry",
      T0."DocNum",
      T0."U_ALFA_ParadigmaId",  
      'COMPRA'                   AS "Type"
    FROM 
      ${this.databaseName}.OPOR T0
    WHERE 
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') 		= 'N' AND
      IFNULL(T0."U_ALFA_ParadigmaCanceled",'N') 		= 'N'
    `;

    return this.exec(query);

  }

  getPendingInvoices(): Promise<DatabaseResponse<ConciliationModel[]>> {

    const query = `
    SELECT DISTINCT
        T0."DocEntry"				        AS "DocEntry",
        T0."DocNum"					        AS "DocNum",
        T2."Serial"					        AS "Serial",	
        T0."U_ALFA_ParadigmaId"	  	AS "U_ALFA_ParadigmaId",
        T3."U_msgSEFAZ"			  	    AS "InvoiceMessage",
        'VENDA'                   	AS "Type"
    FROM 
      ${this.databaseName}.ORDR T0
      
      INNER JOIN ${this.databaseName}.INV1 T1 
      ON T1."BaseEntry" = T0."DocEntry" 
      AND T1."BaseType" = '17'
      
      INNER JOIN ${this.databaseName}.OINV T2 
      ON T2."DocEntry" = T1."DocEntry" 
      
      INNER JOIN ${this.databaseName}."@SKL25NFE" T3
      ON "U_DocEntry" = T2."DocEntry" 

    WHERE 
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') 		= 'S' AND
      IFNULL(T0."U_ALFA_ParadigmaInvoiceSent",'N') 	= 'N'
              
    UNION ALL

    SELECT DISTINCT
      T0."DocEntry"				        AS "DocEntry",
      T0."DocNum"					        AS "DocNum",
      T2."Serial"					        AS "Serial",	
      T0."U_ALFA_ParadigmaId"	  	AS "U_ALFA_ParadigmaId",
      ''						              AS "InvoiceMessage",
      'COMPRA'                   	AS "Type"
    FROM 
      ${this.databaseName}.OPOR T0
      
      INNER JOIN ${this.databaseName}.PCH1 T1 
      ON T1."BaseEntry" = T0."DocEntry" 
      AND T1."BaseType" = '22'
      
      INNER JOIN ${this.databaseName}.OPCH T2 
      ON T2."DocEntry" = T1."DocEntry" 
      
    WHERE 
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') 		= 'S' AND
      IFNULL(T0."U_ALFA_ParadigmaInvoiceSent",'N') 	= 'N'
    `;

    return this.exec(query);

  }

  getPendingCancelations(): Promise<DatabaseResponse<ConciliationModel[]>> {

    const query = `
    SELECT 
      T0."DocEntry"				          AS "DocEntry",
      T0."DocNum"				      	    AS "DocNum",
      T2."Serial"					          AS "Serial",	
      T0."U_ALFA_ParadigmaId"	  	  AS "U_ALFA_ParadigmaId",
      T0."U_ALFA_ParadigmaComments"	AS "InvoiceMessage",
      'VENDA'                   	  AS "Type"
    FROM 
      ${this.databaseName}.ORDR T0
      
      LEFT JOIN ${this.databaseName}.INV1 T1 
      ON T1."BaseEntry" = T0."DocEntry" 
      AND T1."BaseType" = '17'
      
      LEFT JOIN ${this.databaseName}.OINV T2 
      ON T2."DocEntry" = T1."DocEntry" 
        
    WHERE 
      T0."CANCELED" = 'Y' AND
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') = 'S' AND
      IFNULL(T0."U_ALFA_ParadigmaCanceled",'N') = 'N'
          
    UNION ALL

    SELECT 
      T0."DocEntry"				          AS "DocEntry",
      T0."DocNum"					          AS "DocNum",
      T2."Serial"					          AS "Serial",	
      T0."U_ALFA_ParadigmaId"	  	  AS "U_ALFA_ParadigmaId",
      T0."U_ALFA_ParadigmaComments"	AS "InvoiceMessage",
      'COMPRA'                   	  AS "Type"
    FROM 
      ${this.databaseName}.OPOR T0
      
      LEFT JOIN ${this.databaseName}.PCH1 T1 
      ON T1."BaseEntry" = T0."DocEntry" 
      AND T1."BaseType" = '22'
      
      LEFT JOIN ${this.databaseName}.OPCH T2 
      ON T2."DocEntry" = T1."DocEntry" 
      
    WHERE 
      T0."CANCELED" = 'Y' AND
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') = 'S' AND
      IFNULL(T0."U_ALFA_ParadigmaCanceled",'N') = 'N'   
    `;

    return this.exec(query);

  }

  getPendingPayments(): Promise<DatabaseResponse<ConciliationModel[]>> {

    const query = `
    SELECT 
      T4."DocEntry"					      AS "DocEntry",
      T0."DocNum"						      AS "DocNum",	
      T0."U_ALFA_ParadigmaId"	  	AS "U_ALFA_ParadigmaId",
      'VENDA'                   	AS "Type",
      T3."InstId"						      AS "Installment",
      T3."SumApplied"					    AS "PaidAmount",
      T4."DocDate"					      AS "DocDate",
      T4."DocDueDate"					    AS "DueDate"
    FROM 
      ${this.databaseName}.ORDR T0
      
      INNER JOIN ${this.databaseName}.INV1 T1 
      ON T1."BaseEntry" = T0."DocEntry" 
      AND T1."BaseType" = '17'
      
      INNER JOIN ${this.databaseName}.OINV T2 
      ON T2."DocEntry" = T1."DocEntry" 
      
      INNER JOIN ${this.databaseName}.RCT2 T3
      ON T2."DocEntry" = T3."DocEntry" 
          
      INNER JOIN ${this.databaseName}.ORCT T4 
      ON T4."DocEntry" = T3."DocNum" 
            
    WHERE 
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') = 'S' AND
      IFNULL(T4."U_ALFA_ParadigmaPaymentSent",'N') = 'N'
        
    UNION ALL

    SELECT 
      T4."DocEntry"					    AS "DocEntry",
      T0."DocNum"						    AS "DocNum",	
      T0."U_ALFA_ParadigmaId"	  AS "U_ALFA_ParadigmaId",
      'COMPRA'                  AS "Type",
      T3."InstId"						    AS "Installment",
      T3."SumApplied"					  AS "PaidAmount",
      T4."DocDate"					    AS "DocDate",
      T4."DocDueDate"					  AS "DueDate"
    FROM 
      ${this.databaseName}.OPOR T0
      
      INNER JOIN ${this.databaseName}.PCH1 T1 
      ON T1."BaseEntry" = T0."DocEntry" 
      AND T1."BaseType" = '22'
      
      INNER JOIN ${this.databaseName}.OPCH T2 
      ON T2."DocEntry" = T1."DocEntry" 
      
      INNER JOIN ${this.databaseName}.VPM2 T3
      ON T2."DocEntry" = T3."DocEntry" 
          
      INNER JOIN ${this.databaseName}.OVPM T4 
      ON T4."DocEntry" = T3."DocNum" 
            
    WHERE 
      T0."U_ALFA_ParadigmaId" IS NOT NULL AND
      IFNULL(T0."U_ALFA_ParadigmaReceived",'N') = 'S' AND
      IFNULL(T4."U_ALFA_ParadigmaPaymentSent",'N') = 'N'    
    `;

    return this.exec(query);

  }

  updateConciliation(docEntry: string, type: ConciliationType, field: ConciliationField): Promise<DatabaseResponse<boolean>> {

    const query = `
    UPDATE  ${this.databaseName}."${type == ConciliationType.COMPRA ? 'OPOR' : 'ORDR'}" 
      SET "${field}" = 'S'
    WHERE 
      "DocEntry" = ${docEntry}`;
      
    return this.exec(query);

  }

  updatePaymentConciliation(docEntry: string, type: ConciliationType, field: ConciliationField): Promise<DatabaseResponse<boolean>> {

    const query = `
    UPDATE  ${this.databaseName}."${type == ConciliationType.COMPRA ? 'OVPM' : 'ORCT'}" 
      SET "${field}" = 'S'
    WHERE 
      "DocEntry" = ${docEntry}`;
      
    return this.exec(query);
1
  }

}
