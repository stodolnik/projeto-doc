export interface ConciliationModel {
  DocEntry: string,
  DocNum: string,
  Serial: string,
  U_ALFA_ParadigmaId: string,
  InvoiceMessage: string,
  Type: string,
  Installment: string,
  PaidAmount: string,
  DocDate: string,
  DueDate: string,
}

export enum ConciliationType {
  VENDA = 'VENDA',
  COMPRA = 'COMPRA'
}

export enum ConciliationField {
  U_ALFA_ParadigmaReceived = 'U_ALFA_ParadigmaReceived',
  U_ALFA_ParadigmaInvoiceSent = 'U_ALFA_ParadigmaInvoiceSent',
  U_ALFA_ParadigmaPaymentSent = 'U_ALFA_ParadigmaPaymentSent',
  U_ALFA_ParadigmaCanceled = 'U_ALFA_ParadigmaCanceled',
}