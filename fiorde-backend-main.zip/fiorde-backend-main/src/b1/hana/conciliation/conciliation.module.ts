import { Module } from '@nestjs/common';
import { B1ConciliationService } from './conciliation.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [B1ConciliationService],
  exports: [B1ConciliationService]
})
export class B1ConciliationModule {}
