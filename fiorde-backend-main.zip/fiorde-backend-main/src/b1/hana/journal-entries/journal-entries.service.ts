import { Injectable } from '@nestjs/common';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import { JournalEntrie } from './interfaces'
import _ = require('lodash');

@Injectable()
export class HanaJournalEntriesService extends DatabaseService<any[]> {
  
  updateIntegrationField(id: string) {
    let query = `
    UPDATE
      ${this.databaseName}."OJDT"
    SET 
      "U_FiordeIntegration" = 'Y' 
    WHERE 
      "Number" = '${id}'`;

    this.exec(query);

  }

  NoIntegrated(): Promise<DatabaseResponse<JournalEntrie[]>> {

    let query = `  SELECT 
                        "Number" as "id" 
                        , "U_fiordeRetries" AS "Retrie"
                  FROM 
                  ${this.databaseName}.OJDT
                  WHERE
                         IFNULL("U_FiordeIntegration",'N') = 'N'
                        AND  "U_fiordeRetries" <=3    
                        AND "TransId" IN 
                            ( SELECT 
                                    "StornoToTr"
                              FROM 
                                    ${this.databaseName}.OJDT 
                              WHERE 
                                    "StornoToTr" IS NOT NULL 
                              )`;

    return this.exec(query);
  }

  updateIntegrationRetrie(id: string , retrie : number) {
    let query = `
    UPDATE
      ${this.databaseName}."OJDT"
    SET 
      "U_fiordeRetries" = '${retrie}' 
    WHERE 
      "Number" = '${id}'`;

    this.exec(query);
  }


  
}