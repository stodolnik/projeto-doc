import { Module } from '@nestjs/common';
import { HanaJournalEntriesService } from './journal-entries.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaJournalEntriesService],
  exports: [HanaJournalEntriesService]
})

export class HanaBusinessPartnersModule {}
