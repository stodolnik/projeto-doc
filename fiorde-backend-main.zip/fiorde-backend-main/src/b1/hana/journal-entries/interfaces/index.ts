export interface JournalEntrie {
  id: string
}


