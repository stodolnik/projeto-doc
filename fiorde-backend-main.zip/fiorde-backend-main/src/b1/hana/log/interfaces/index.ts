export interface ModelLog {
  Code: string,
  Name?: string,
  U_DATEDOC: Date, 
  U_STATUS: string,
  U_IDDOC: string,
  U_OBJETOREQUEST: string,
  U_OBJETORESPONSE: string,
  U_PARAMETROS: string,
  U_TYPE: string,
  U_HORADOC?: string,
}
