import { Injectable } from '@nestjs/common';
import { ModelLog } from './interfaces';
import { DatabaseResponse } from '../../core/database/interfaces';
import { DatabaseService } from '../../core/database/database.service';
import * as _ from 'lodash';

@Injectable()
export class HanaLogService extends DatabaseService<any> {

  async insertLog(model: ModelLog): Promise<DatabaseResponse<any>> {
    try {
      const query = `INSERT INTO ${this.databaseName}."@ALFA_LOGS" (			   
			"Code"
      , "Name"
      , "U_DATEDOC"
      , "U_STATUS"
      , "U_IDDOC"
      , "U_OBJETOREQUEST"
      , "U_OBJETORESPONSE"
      , "U_PARAMETROS"
      , "U_TYPE"
      , "U_HORADOC"
      )
			
			VALUES (
         '${model.Code}'
        ,'${model.Code}'
        ,'${model.U_DATEDOC}'
        ,'${model.U_STATUS}'
        ,'${model.U_IDDOC}'
        ,'${JSON.stringify(model.U_OBJETOREQUEST).replace(/\\/g, '').replace(/'/g, '')}'
        ,'${JSON.stringify(model.U_OBJETORESPONSE).replace(/'/g, '')}'
        ,'${JSON.stringify(model.U_PARAMETROS).replace(/'/g, '')}'
        ,'${model.U_TYPE}'
        ,'${model.U_HORADOC}'
        )`;

      return this.exec(query);
    } catch (err) {
      throw err;
    }

  }

  async deleteLog() {

    try {
      const query = `
      DELETE 
      FROM 
                   ${this.databaseName}."${this.tableName}" 
      WHERE 
                  "${this.dateField}" < ADD_DAYS(CURRENT_DATE, -${this.daysToKeep})
      `;

      
      if (this.databaseName && this.tableName && this.daysToKeep) {
        console.log(query);
        return await this.exec(query);
      } else {
        return null;
      }

    } catch (err) {
      console.log('Erro na função deleteLog:', err);
    }

  }

  async updateLogPartner(message: string, id: string, column: string, table: string): Promise<DatabaseResponse<any>> {
    try {
      const query = `UPDATE ${this.databaseName}."${table}" SET "U_LogIntegratedFiorde" = '${message}' WHERE "${column}" = '${id}'`;
      return this.exec(query);
    } catch (err) {
      throw err;
    }
  }

}