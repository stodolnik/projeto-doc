import { Module } from '@nestjs/common';
import { HanaLogService } from './log.service';
import { DatabaseModule } from '../../core/database/database.module';

@Module({
  imports: [DatabaseModule],
  providers: [HanaLogService],
  exports: [HanaLogService]
})
export class LogModule {}
