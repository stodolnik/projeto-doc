import { Table } from "../../../../common/database/interfaces";

export const CurrencyModel: Table = {
  name: 'OCRN',
  alias: 'T0',
  columns: [
    {name: 'CurrCode'},
    {name: 'CurrName'}
  ]
}
export interface Currency {
  CurrCode: string,
  CurrName: string
}