import { Module } from '@nestjs/common';
import { HttpService } from './http.service';
import { ConfigModule } from '../../../config/config.module';

@Module({
  imports: [ConfigModule],
  providers: [{provide: 'HttpService', useClass: HttpService}],
  exports: [HttpService]
})

export class HttpModule {}
