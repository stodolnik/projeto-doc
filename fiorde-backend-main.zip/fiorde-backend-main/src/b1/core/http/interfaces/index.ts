//import * as uuid from 'uuid/v4';
import { uuid } from 'uuidv4';


export class BatchResponse {
  public error: HttpServiceError
  public id: string
}

export interface HttpServiceResponse<T> {
  error?: HttpServiceError,
  data?: T
}

export interface HttpServiceError {
  code: string,
  message?: string,
  innerMessage: string
}

export class BatchRequest {

  private _requests: Request[] = [];
  private _changesets: Changeset[] = [];
  private _id: string;
  private _batchId: string;

  constructor() {
    this._id = uuid();
    this._batchId = "batch_" + this._id;
  }

  addRequest(request: Request) {
    this._requests.push(request);
  }

  batchId() {
    return this._batchId;
  }

  id() {
    return this._id;
  }

  requests(): Request[] {
    return this._requests;
  }

  hasChanges(): boolean {
    return this._requests.length > 0;
  }

  raw() {
    return `
${this._requests.map(r => {
      if (r.method == RequestMethodType.GET) {
        return `--${this._batchId}
Content-Type: application/http
Content-Transfer-Encoding:binary

${r.method.toString()} /b1s/v1/${r.path};

`;
      } else {
        return `--${this._batchId}
Content-Type: application/http
Content-Transfer-Encoding:binary

${r.method.toString()} /b1s/v1/${r.path}${r.id ? `('${r.id}')` : ''}

${JSON.stringify(r.data)}

`;
      }
    }).join('')}
--${this._batchId}--
`;

  }
  
}

export enum RequestMethodType {
  "GET" = "GET",
  "POST" = "POST",
  "PATCH" = "PATCH",
  "PUT" = "PUT",
  "DELETE" = "DELETE"
}

export interface Request {
  id?: string;
  data?: any;
  method: RequestMethodType;
  path: string;
}

class Changeset {

  private _requests: Request[] = [];
  private _id: string;

  constructor() {
    this._id = uuid();
  }

  addRequest(request: Request) {
    this._requests.push(request);
  }

}