
import { Injectable } from '@nestjs/common';
import { ConfigService } from '../../../config/config.service';
import { ConnectionOptions, createConnection } from '@ibsolution/types-hana-client';
import { DatabaseResponse } from './interfaces';
import Axios, { AxiosInstance } from 'axios';

@Injectable()
export class DatabaseService<T> {


	isHTTP: boolean;
	options: ConnectionOptions;
	databaseName: string;
	tableName: string;
	dateField: string;
	daysToKeep: string;


	private axiosRef: AxiosInstance = Axios.create();

	constructor(private readonly configService: ConfigService) {

		const env = this.configService.get();
		console.log('env', env);
		this.databaseName = env.DATABASE_NAME;
		this.tableName = env.TABLE_NAME;
		this.dateField = env.DATE_FIELD;
		this.daysToKeep = env.DAYS_TO_KEEP;

		if (env.DATABASE_HOST.indexOf('http') >= 0) {
			this.isHTTP = true;
			this.axiosRef.defaults.baseURL = env.DATABASE_HOST;
		} else {
			this.isHTTP = false;
			this.options = {
				host: env.DATABASE_HOST,
				port: parseInt(env.DATABASE_PORT),
				uid: env.DATABASE_USER,
				pwd: env.DATABASE_PASSWORD,
			};
		}


	}

	getTableName(tableName: string) {
		return `${this.databaseName}."${tableName}"`;
	}


	exec(query: string): Promise<DatabaseResponse<T>> {

		if (this.isHTTP) {

			return new Promise((resolve) => {
				this.axiosRef.post('/hana', { query }).then(result => {
					resolve(result.data);
				});
			});

		} else {

			const connection = createConnection(this.options);

			return new Promise((resolve) => {

				const disconnect = () => connection.disconnect(() => { return true; });
				const response: DatabaseResponse<T> = {};

				try {
					connection.connect(null, connectionError => {
						if (!connectionError) {
							try {
								connection.exec<T>(query, (execError, results: any) => {
									if (!execError) {
										response.data = results;

										if (results.length > 0 && results[0]['TOTALROWS']) {
											response.count = results[0]['TOTALROWS'];
										}
										else {
											response.count = results.length;
										}

										resolve(response);
									}
									else {
										response.error = { code: 'D00002', innerMessage: execError.message, message: 'Falha na consulta ao banco de dados.' }
										resolve(response);
									}
									disconnect();
									return;
								});
							}
							catch (ex) {
								response.error = { code: 'D00003', innerMessage: connectionError.message, message: ex.message };
								resolve(response);
							}
						}
						else {
							response.error = { code: 'D00001', innerMessage: connectionError.message, message: 'Falha na conexão com o banco de dados.' }
							resolve(response);
						}
					});
				}
				catch (ex) {
					response.error = { code: 'D00001', innerMessage: ex.message, message: 'Falha na conexão com o banco de dados.' }
					resolve(response);
				}
			});

		}
	}

}
