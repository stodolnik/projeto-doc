import { ItemsModule } from './app/items/items.module';
import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { PartnerModule } from './app/partner/partner.module';
import { ProjectsModule } from './app/projects/projects.module';
import { SalesInvoicesModule } from './app/sales-Invoices/sales-invoices.module';
import { PurchaseInvoicesModule } from './app/purchase-invoices/purchase-invoices.module';
import { ServicePartnerModule } from './app/service/parter/partner.module';
import { JournalEntriesModule } from './app/journal-entries/journal-entries.module';
import { ServiceStatusModule } from './app/service/document-status/document-status.module';
import { IncomingPaymentsModule } from './app/incoming-payments/incoming-payment.module';
import { ServiceJournalEntriesModule } from './app/service/journal-entries/journal-entries.module';
import { PingSessionModule } from './app/ping-session/ping-session.module';
import { ServiceLayerModule } from '@alfaerp/service-layer';
import {ConfigService} from './config/config.service'
import { VendorPaymentsModule } from './app/vendor-payments/vendor-payments.module';
import { PurchaseInvoicesInternationalModule } from './app/purchase-invoices-international/purchase-invoices-international.module';

const config = new ConfigService(`./environment/${process.env.NODE_ENV || 'staging'}.json`)

@Module({
  imports: [
    ServiceLayerModule.forRoot({ baseUrl: config._get('SERVICE_LAYER_URL') }),
    ScheduleModule.forRoot(),
    PartnerModule,
    SalesInvoicesModule,
    PurchaseInvoicesModule,
    PurchaseInvoicesInternationalModule,
    VendorPaymentsModule,
    ItemsModule,
    ProjectsModule,
    ServicePartnerModule,
    ServiceStatusModule,
    JournalEntriesModule,
    IncomingPaymentsModule,
    PingSessionModule,
    ServiceJournalEntriesModule
  ]
})

export class ApplicationModule { }
